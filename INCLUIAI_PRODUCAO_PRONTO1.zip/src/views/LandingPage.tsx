import React, { useState, useEffect } from 'react';
import { 
  Brain, ShieldCheck, Users, Sparkles, FileText, ArrowRight, 
  CheckCircle, Lock, Star, Phone, Play, ChevronRight, School,
  Stethoscope, User as UserIcon, Check, X, Zap, Clock, Cloud
} from 'lucide-react';
import { PlanTier, SiteConfig } from '../types';
import { PaymentService } from '../services/paymentService';
import { AdminService } from '../services/adminService';

interface Props {
  onLogin: () => void;
  onRegister: () => void; 
  onAudit: () => void;
}

export const LandingPage: React.FC<Props> = ({ onLogin, onRegister, onAudit }) => {
  const [config, setConfig] = useState<SiteConfig | null>(null);

  useEffect(() => {
      // Load Dynamic Config
      AdminService.getSiteConfig().then(setConfig);
  }, []);
  
  const handleCheckout = async (plan: PlanTier) => {
      const url = await PaymentService.getCheckoutUrl(plan, {});
      window.location.href = url;
  };

  const handleNavClick = (e: React.MouseEvent, id: string) => {
      e.preventDefault();
      const element = document.getElementById(id);
      if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
      }
  };

  // Fallback defaults if config fails
  const headline = config?.headline || "Documentos educacionais com validade técnica, rastreabilidade e segurança jurídica.";
  const subheadline = config?.subheadline || "PEI, PAEE, relatórios e diagnósticos alinhados à BNCC, com histórico auditável, QR Code verificável e controle institucional completo.";
  const pricePro = config?.pricing.pro_monthly || 89.00; // promo
  const priceProAnnual = config?.pricing.pro_annual || 69.00; // promo
  const priceMaster = config?.pricing.master_monthly || 127.00; // promo
  const priceMasterAnnual = config?.pricing.master_annual || 99.00; // promo

  return (
    <div className="min-h-screen bg-white font-sans selection:bg-brand-100 selection:text-brand-900">
         {/* NAVBAR */}
         <header className="fixed w-full bg-white/90 backdrop-blur-xl z-50 border-b border-gray-100 transition-all duration-300">
          <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-gradient-to-br from-brand-600 to-brand-400 p-2 rounded-xl shadow-lg shadow-brand-200">
                <FileText className="text-white h-6 w-6" />
              </div>
              <span className="text-2xl font-extrabold text-gray-900 tracking-tight">IncluiAI</span>
            </div>
            <nav className="hidden md:flex gap-8 items-center font-medium text-sm text-gray-600">
              <a href="#features" onClick={(e) => handleNavClick(e, 'features')} className="hover:text-brand-600 transition">Recursos</a>
              <a href="#pricing" onClick={(e) => handleNavClick(e, 'pricing')} className="hover:text-brand-600 transition">Planos</a>
              <button onClick={onAudit} className="hover:text-brand-600 flex items-center gap-1"><ShieldCheck size={16}/> Validar Doc</button>
              <div className="h-6 w-px bg-gray-200 mx-2"></div>
              <button onClick={onLogin} className="text-brand-600 font-bold hover:underline">Área do Cliente</button>
            </nav>
          </div>
        </header>

        <main>
          {/* 1. HERO SECTION (UPDATED LAYOUT 50/50) */}
          <section className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden bg-gradient-to-b from-white via-brand-50/30 to-white">
            <div className="max-w-7xl mx-auto px-6">
                <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
                    
                    {/* Left: Text */}
                    <div className="flex-1 text-center lg:text-left z-10 order-2 lg:order-1">
                        <div className="inline-flex items-center gap-2 bg-white border border-brand-100 text-brand-700 px-4 py-1.5 rounded-full text-xs font-bold mb-6 shadow-sm">
                           <ShieldCheck size={14} /> Decreto nº 12.686/2025 Compliance
                        </div>
                        
                        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight mb-6 leading-[1.1]">
                           {headline}
                        </h1>
                        
                        <p className="text-lg text-gray-600 mb-8 leading-relaxed max-w-xl mx-auto lg:mx-0">
                           {subheadline}
                        </p>
                        
                        <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                           <button onClick={onLogin} className="bg-brand-600 text-white px-8 py-4 rounded-xl text-lg font-bold shadow-xl shadow-brand-200 hover:bg-brand-700 transition flex items-center justify-center gap-2 group transform hover:-translate-y-1 w-full sm:w-auto">
                             Começar Agora <ArrowRight size={20} className="group-hover:translate-x-1 transition"/>
                           </button>
                           <a href="#pricing" onClick={(e) => handleNavClick(e, 'pricing')} className="bg-white text-gray-800 border border-gray-200 px-8 py-4 rounded-xl text-lg font-bold hover:bg-gray-50 transition shadow-sm w-full sm:w-auto flex items-center justify-center">
                              Ver Planos
                           </a>
                        </div>

                         <div className="mt-8 grid grid-cols-2 gap-4 text-sm font-bold text-gray-500 uppercase tracking-wider max-w-sm mx-auto lg:mx-0">
                            <div className="flex items-center gap-2 justify-center lg:justify-start"><CheckCircle size={16} className="text-brand-500"/> Geração de PEI</div>
                            <div className="flex items-center gap-2 justify-center lg:justify-start"><CheckCircle size={16} className="text-brand-500"/> Código Auditável</div>
                        </div>
                    </div>

                    {/* Right: System Mockup */}
                    <div className="flex-1 relative w-full max-w-lg lg:max-w-none order-1 lg:order-2">
                        {/* Mockup da tela do sistema */}
                        <div className="relative rounded-2xl shadow-2xl overflow-hidden border border-gray-200 bg-white">
                            {/* Barra do "navegador" */}
                            <div className="bg-gray-100 border-b border-gray-200 px-4 py-2 flex items-center gap-2">
                                <div className="flex gap-1.5"><div className="w-3 h-3 rounded-full bg-red-400"/><div className="w-3 h-3 rounded-full bg-yellow-400"/><div className="w-3 h-3 rounded-full bg-green-400"/></div>
                                <div className="flex-1 bg-white rounded-md border border-gray-200 px-3 py-1 text-xs text-gray-400 flex items-center gap-1">
                                    <Lock size={10}/> app.incluiai.com/alunos/pei
                                </div>
                            </div>
                            {/* Conteúdo da tela */}
                            <div className="bg-white p-4 space-y-3">
                                {/* Cabeçalho do documento */}
                                <div className="bg-brand-600 rounded-lg px-4 py-3 flex items-center justify-between">
                                    <div>
                                        <p className="text-white font-bold text-sm">PEI — Plano Educacional Individualizado</p>
                                        <p className="text-brand-200 text-xs">Aluno: Gabriel Oliveira · 2º Ano · Turno Matutino</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-brand-200 text-[10px]">Código Auditável</p>
                                        <p className="text-white font-mono text-xs font-bold">PEI-A3F9C821</p>
                                    </div>
                                </div>
                                {/* Campos do PEI */}
                                <div className="grid grid-cols-2 gap-2">
                                    {[
                                        { label: "BNCC Vinculada", val: "EF01LP01, EF01MA01" },
                                        { label: "Nível de Suporte", val: "Nível 2 — Substancial" },
                                        { label: "CID", val: "F84.0 — TEA" },
                                        { label: "Profissional AEE", val: "Prof.ª Mariana Costa" },
                                    ].map(f => (
                                        <div key={f.label} className="border border-gray-100 rounded-lg p-2 bg-gray-50">
                                            <p className="text-[9px] text-brand-600 font-bold uppercase">{f.label}</p>
                                            <p className="text-xs text-gray-800 font-semibold mt-0.5">{f.val}</p>
                                        </div>
                                    ))}
                                </div>
                                {/* Mini gráfico */}
                                <div className="border border-gray-100 rounded-lg p-3 bg-gray-50">
                                    <p className="text-[9px] text-gray-500 font-bold uppercase mb-2">Evolução — Últimos 4 Meses</p>
                                    <div className="flex items-end gap-1 h-10">
                                        {[2, 3, 2, 4, 3, 4, 5].map((v, i) => (
                                            <div key={i} className="flex-1 bg-brand-600 rounded-t-sm opacity-90" style={{ height: `${(v/5)*100}%` }}/>
                                        ))}
                                    </div>
                                </div>
                                {/* Rodapé auditável */}
                                <div className="border-t border-dashed border-gray-200 pt-2 flex items-center justify-between">
                                    <div className="flex items-center gap-1.5">
                                        <ShieldCheck size={12} className="text-green-600"/>
                                        <span className="text-[10px] text-green-700 font-bold">Documento auditável e rastreável</span>
                                    </div>
                                    <span className="text-[9px] text-gray-400 font-mono">incluiai.com/validar/PEI-A3F9C821</span>
                                </div>
                            </div>
                        </div>
                        {/* Floating Badge */}
                        <div className="hidden sm:flex absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border border-gray-100 items-center gap-3 z-20">
                             <div className="bg-green-100 p-2 rounded-full text-green-600"><Check size={20}/></div>
                             <div>
                                 <p className="text-xs text-gray-500 font-bold uppercase">Documentos Gerados</p>
                                 <p className="text-xl font-bold text-gray-800">+ 12.000</p>
                             </div>
                        </div>
                        {/* Badge auditoria flutuante */}
                        <div className="hidden sm:flex absolute -top-4 -right-4 bg-white p-3 rounded-xl shadow-xl border border-brand-100 items-center gap-2 z-20">
                             <ShieldCheck size={16} className="text-brand-600"/>
                             <div>
                                 <p className="text-[10px] text-gray-500 font-bold">QR + Hash SHA-256</p>
                                 <p className="text-xs font-bold text-gray-800">Segurança Jurídica</p>
                             </div>
                        </div>
                    </div>

                </div>
            </div>
          </section>

          {/* 2. PAIN & SOLUTION */}
          <section className="py-20 bg-gray-50">
            <div className="max-w-7xl mx-auto px-6">
                <div className="grid md:grid-cols-2 gap-16 items-center">
                    <div>
                        <h2 className="text-3xl font-bold text-gray-900 mb-6">O custo da desorganização é alto</h2>
                        <div className="space-y-6">
                            <div className="flex gap-4">
                                <div className="bg-red-100 text-red-600 p-3 rounded-lg h-fit"><Clock size={24}/></div>
                                <div>
                                    <h4 className="font-bold text-gray-800">Horas perdidas</h4>
                                    <p className="text-gray-600">Montar documentos manualmente consome tempo precioso de planejamento.</p>
                                </div>
                            </div>
                            <div className="flex gap-4">
                                <div className="bg-red-100 text-red-600 p-3 rounded-lg h-fit"><ShieldCheck size={24}/></div>
                                <div>
                                    <h4 className="font-bold text-gray-800">Risco Jurídico</h4>
                                    <p className="text-gray-600">Documentos sem padronização ou rastreabilidade expõem a instituição.</p>
                                </div>
                            </div>
                            <div className="flex gap-4">
                                <div className="bg-red-100 text-red-600 p-3 rounded-lg h-fit"><FileText size={24}/></div>
                                <div>
                                    <h4 className="font-bold text-gray-800">Informações Espalhadas</h4>
                                    <p className="text-gray-600">Dificuldade em acompanhar a evolução real do aluno com dados fragmentados.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-200">
                        <div className="mb-6">
                            <span className="bg-brand-100 text-brand-700 px-3 py-1 rounded-full text-xs font-bold uppercase">A Solução IncluiAI</span>
                        </div>
                        <h2 className="text-3xl font-bold text-gray-900 mb-6">Centralize, Padronize e Proteja.</h2>
                        <p className="text-gray-600 mb-8 leading-relaxed">
                            A única plataforma que une Inteligência Artificial com segurança jurídica.
                            Gere documentos com padrão técnico superior, tenha rastreabilidade total de cada edição e mantenha o histórico do aluno organizado.
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-brand-50 p-4 rounded-xl border border-brand-100 text-center">
                                <span className="block text-2xl font-bold text-brand-700 mb-1">-80%</span>
                                <span className="text-xs text-gray-600 uppercase font-bold">Tempo Operacional</span>
                            </div>
                            <div className="bg-brand-50 p-4 rounded-xl border border-brand-100 text-center">
                                <span className="block text-2xl font-bold text-brand-700 mb-1">100%</span>
                                <span className="text-xs text-gray-600 uppercase font-bold">Auditável</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>

          {/* 3. SYSTEM ADVANTAGES */}
          <section id="features" className="py-24 bg-white border-b border-gray-100">
            <div className="max-w-7xl mx-auto px-6">
                <div className="text-center mb-16 max-w-3xl mx-auto">
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 tracking-tight">Muito além de um gerador de documentos.</h2>
                    <p className="text-lg text-gray-600">Uma plataforma pensada para segurança, padronização e autoridade profissional.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {/* Card 1 */}
                    <div className="p-8 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 group">
                        <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
                            <ShieldCheck size={28} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">Sistema Auditável</h3>
                        <p className="text-gray-600 leading-relaxed text-sm">Cada documento recebe código único de autenticação e rastreabilidade, garantindo validade jurídica e segurança.</p>
                    </div>

                    {/* Card 2 */}
                    <div className="p-8 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 group">
                        <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
                            <Lock size={28} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">Conformidade com LGPD</h3>
                        <p className="text-gray-600 leading-relaxed text-sm">Dados isolados por usuário, controle de acesso rigoroso e armazenamento seguro, protegendo informações sensíveis.</p>
                    </div>

                    {/* Card 3 */}
                    <div className="p-8 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 group">
                        <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
                            <Brain size={28} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">IA Estruturada</h3>
                        <p className="text-gray-600 leading-relaxed text-sm">Geração baseada em prompts técnicos específicos para o contexto educacional, garantindo linguagem técnica adequada.</p>
                    </div>

                    {/* Card 4 */}
                    <div className="p-8 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 group">
                        <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
                            <FileText size={28} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">Padronização Profissional</h3>
                        <p className="text-gray-600 leading-relaxed text-sm">Modelos formais para PEI, relatórios e estudos de caso que elevam a qualidade da documentação escolar.</p>
                    </div>

                    {/* Card 5 */}
                    <div className="p-8 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 group">
                        <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
                            <Zap size={28} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">Economia de Tempo</h3>
                        <p className="text-gray-600 leading-relaxed text-sm">Documentos completos em minutos com preenchimento inteligente, permitindo foco no aluno.</p>
                    </div>

                    {/* Card 6 */}
                    <div className="p-8 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 group">
                        <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
                            <Cloud size={28} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">Armazenamento Seguro</h3>
                        <p className="text-gray-600 leading-relaxed text-sm">Documentos salvos na nuvem com organização automática por aluno, acessíveis de qualquer lugar.</p>
                    </div>
                </div>
            </div>
          </section>

          {/* 6. PRICING SECTION */}
          <section id="pricing" className="py-24 bg-gray-900 text-white relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
            <div className="max-w-7xl mx-auto px-6 relative z-10">
              <div className="text-center mb-16">
                 <h2 className="text-4xl font-bold mb-4">Planos Profissionais</h2>
                 <p className="text-gray-400 text-lg">Escolha a estrutura ideal para sua atuação.</p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8 items-start max-w-5xl mx-auto">
                
                {/* PLANO PRO */}
                <div className="p-6 rounded-3xl border border-gray-600 bg-gray-800 relative hover:border-gray-500 transition shadow-lg flex flex-col h-full">
                  <div className="mb-6">
                      <h3 className="text-xl font-bold text-white mb-2">Plano Pro</h3>
                      <p className="text-gray-400 text-sm">Para professores e autônomos</p>
                  </div>

                  <ul className="space-y-3 mb-8 text-sm text-gray-300 font-medium flex-1">
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-500 shrink-0"/> <strong>200 créditos IA/mês</strong></li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-500 shrink-0"/> <strong>Até 20 alunos</strong></li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-500 shrink-0"/> Upload de Laudos</li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-500 shrink-0"/> Documentos Educacionais</li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-500 shrink-0"/> Código Auditável em tudo</li>
                  </ul>

                  {/* ANUAL BOX - PRO */}
                  <div className="relative bg-gray-700/50 rounded-xl p-5 border-2 border-brand-500 mb-4 shadow-xl">
                      <div className="absolute -top-3 right-4 bg-brand-600 text-white text-[10px] uppercase font-bold px-3 py-1 rounded-full shadow-md">
                          Mais Vantajoso
                      </div>
                      <p className="text-gray-300 text-xs font-bold uppercase mb-1">Plano Anual</p>
                      <div className="flex items-end gap-2 mb-1">
                          <span className="text-4xl font-bold text-white">R$ {priceProAnnual.toFixed(2).replace('.', ',')}</span>
                          <span className="text-sm text-gray-400 mb-1">/mês</span>
                      </div>
                      <p className="text-[10px] text-brand-300 font-bold mb-4">Economia anual de R$ {((pricePro - priceProAnnual)*12).toFixed(0)}</p>
                      <p className="text-[10px] text-gray-400 mb-4 leading-tight">
                          Cobrança recorrente mensal.<br/>Compromisso mínimo de 12 meses.
                      </p>
                      <button onClick={() => handleCheckout(PlanTier.PRO)} className="w-full py-3 bg-brand-600 text-white rounded-lg font-bold hover:bg-brand-700 transition shadow-lg">
                          Assinar Anual
                      </button>
                  </div>

                  {/* MENSAL BOX - PRO */}
                  <div className="bg-gray-800 rounded-xl p-4 border border-gray-600 flex justify-between items-center">
                      <div>
                          <p className="text-gray-300 text-xs font-bold uppercase">Plano Mensal</p>
                          <p className="text-xl font-bold text-white">R$ {pricePro.toFixed(2).replace('.', ',')}<span className="text-xs text-gray-400 font-normal">/mês</span></p>
                      </div>
                      <button onClick={() => handleCheckout(PlanTier.PRO)} className="px-4 py-2 border border-gray-500 text-gray-300 rounded-lg text-sm font-bold hover:bg-gray-700 transition">
                          Assinar Mensal
                      </button>
                  </div>
                </div>

                {/* PLANO MASTER */}
                <div className="p-6 rounded-3xl border border-gray-600 bg-gray-800 relative shadow-2xl flex flex-col h-full transform md:-translate-y-2">
                  <div className="mb-6">
                      <h3 className="text-xl font-bold text-white mb-2">Plano Master</h3>
                      <p className="text-gray-400 text-sm">Para Clínicas e Escolas</p>
                  </div>
                  
                  <ul className="space-y-3 mb-8 text-sm text-gray-300 flex-1">
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-400 shrink-0"/> <strong>400 créditos IA/mês</strong></li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-400 shrink-0"/> <strong>Até 40 alunos</strong></li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-400 shrink-0"/> Controle de Atendimento</li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-400 shrink-0"/> Relatórios Evolutivos Avançados</li>
                    <li className="flex gap-3"><CheckCircle size={18} className="text-brand-400 shrink-0"/> Gestão Ampliada</li>
                  </ul>

                  {/* ANUAL BOX - MASTER */}
                  <div className="relative bg-gray-700/50 rounded-xl p-5 border-2 border-purple-500 mb-4 shadow-xl">
                      <div className="absolute -top-3 right-4 bg-purple-600 text-white text-[10px] uppercase font-bold px-3 py-1 rounded-full shadow-md">
                          Mais Vantajoso
                      </div>
                      <p className="text-gray-300 text-xs font-bold uppercase mb-1">Plano Anual</p>
                      <div className="flex items-end gap-2 mb-1">
                          <span className="text-4xl font-bold text-white">R$ {priceMasterAnnual.toFixed(2).replace('.', ',')}</span>
                          <span className="text-sm text-gray-400 mb-1">/mês</span>
                      </div>
                      <p className="text-[10px] text-purple-300 font-bold mb-4">Economia anual de R$ {((priceMaster - priceMasterAnnual)*12).toFixed(0)}</p>
                      <p className="text-[10px] text-gray-400 mb-4 leading-tight">
                          Cobrança recorrente mensal.<br/>Compromisso mínimo de 12 meses.
                      </p>
                      <button onClick={() => handleCheckout(PlanTier.PREMIUM)} className="w-full py-3 bg-purple-600 text-white rounded-lg font-bold hover:bg-purple-700 transition shadow-lg">
                          Assinar Anual
                      </button>
                  </div>

                  {/* MENSAL BOX - MASTER */}
                  <div className="bg-gray-800 rounded-xl p-4 border border-gray-600 flex justify-between items-center">
                      <div>
                          <p className="text-gray-300 text-xs font-bold uppercase">Plano Mensal</p>
                          <p className="text-xl font-bold text-white">R$ {priceMaster.toFixed(2).replace('.', ',')}<span className="text-xs text-gray-400 font-normal">/mês</span></p>
                      </div>
                      <button onClick={() => handleCheckout(PlanTier.PREMIUM)} className="px-4 py-2 border border-gray-500 text-gray-300 rounded-lg text-sm font-bold hover:bg-gray-700 transition">
                          Assinar Mensal
                      </button>
                  </div>
                </div>

              </div>
              
              <div className="mt-12 text-center max-w-2xl mx-auto">
                  <p className="text-xs text-gray-500 mb-6">
                      * Cobrança recorrente mensal no cartão de crédito. No plano anual, há compromisso mínimo de 12 meses, com multa em caso de cancelamento antecipado.
                  </p>
                  <div className="inline-block bg-gray-800 rounded-lg p-4 border border-gray-700">
                      <p className="text-sm text-gray-400 mb-2 font-bold">Pacote Adicional</p>
                      <p className="text-white font-bold">+10 Alunos por <span className="text-brand-400">R$ {config?.pricing.extra_student.toFixed(2) || '29'}/mês</span></p>
                  </div>
                  <div className="mt-8">
                     <a href="https://wa.me/5511999999999" target="_blank" className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition border-b border-gray-700 hover:border-white pb-1">
                          Precisa de mais? Fale no WhatsApp <ArrowRight size={14}/>
                     </a>
                  </div>
              </div>
            </div>
          </section>

          <footer className="bg-white border-t border-gray-100 py-12">
            <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center">
              <div className="flex items-center gap-2 mb-4 md:mb-0">
                <Brain className="text-brand-600" size={24}/>
                <span className="font-bold text-xl text-gray-900">IncluiAI</span>
              </div>
              <div className="flex gap-4 text-gray-500 text-sm items-center">
                   <span className="flex items-center gap-1"><Lock size={12}/> Site Seguro</span>
                   <span className="flex items-center gap-1"><Phone size={12}/> Suporte: {config?.contactPhone || '(11) 99999-9999'}</span>
                   <span>CNPJ: 00.000.000/0001-00</span>
              </div>
            </div>
          </footer>
        </main>
    </div>
  );
};