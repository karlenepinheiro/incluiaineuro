import React, { useState } from 'react';
import { Brain, Copy } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (email: string, pass: string) => void;
  onGuest: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onGuest }) => {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');

  const fillLogin = (e: string, p: string) => {
      setEmail(e);
      setPass(p);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 bg-white rounded-3xl shadow-2xl overflow-hidden">
        
        {/* Left Side - Form */}
        <div className="p-8 md:p-12 flex flex-col justify-center">
            <div className="flex items-center gap-2 mb-8">
                <div className="bg-brand-600 p-2 rounded-lg"><Brain className="text-white h-6 w-6" /></div>
                <span className="text-2xl font-bold text-gray-800">IncluiAI</span>
            </div>
            
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Bem-vindo de volta</h2>
            <p className="text-gray-500 mb-8">Acesse sua conta para continuar.</p>

            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Email</label>
                    <input type="email" value={email} onChange={e=>setEmail(e.target.value)} className="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-brand-500 outline-none transition" />
                </div>
                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Senha</label>
                    <input type="password" value={pass} onChange={e=>setPass(e.target.value)} className="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-brand-500 outline-none transition" />
                </div>
                <button onClick={() => onLogin(email, pass)} className="w-full bg-brand-600 text-white rounded-xl py-3 font-bold hover:bg-brand-700 transition shadow-lg shadow-brand-200">
                    Entrar na Plataforma
                </button>
            </div>
        </div>

        {/* Right Side - Credentials */}
        <div className="bg-gray-900 p-8 md:p-12 flex flex-col justify-center text-white">
            <h3 className="text-xl font-bold mb-6 text-brand-300">Ambiente de Teste</h3>
            <p className="text-gray-400 text-sm mb-6">Clique nos cartões abaixo para preencher automaticamente:</p>
            
            <div className="space-y-3">
                <button onClick={() => fillLogin('free@incluiai.com', '123')} className="w-full bg-gray-800 p-4 rounded-xl text-left hover:bg-gray-700 transition border border-gray-700 group">
                    <div className="flex justify-between items-center">
                        <span className="font-bold text-white">Plano Grátis</span>
                        <Copy size={14} className="opacity-0 group-hover:opacity-100 transition"/>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">free@incluiai.com</div>
                </button>

                <button onClick={() => fillLogin('pro@incluiai.com', '123')} className="w-full bg-gray-800 p-4 rounded-xl text-left hover:bg-gray-700 transition border border-brand-500 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 bg-brand-600 text-white text-[10px] px-2 py-0.5 rounded-bl-lg font-bold">RECOMENDADO</div>
                    <div className="flex justify-between items-center">
                        <span className="font-bold text-brand-300">Plano Profissional</span>
                         <Copy size={14} className="opacity-0 group-hover:opacity-100 transition"/>
                    </div>
                    <div className="text-xs text-gray-400 mt-1">pro@incluiai.com</div>
                </button>

                <button onClick={() => fillLogin('master@incluiai.com', '123')} className="w-full bg-gray-800 p-4 rounded-xl text-left hover:bg-gray-700 transition border border-gray-700 group">
                    <div className="flex justify-between items-center">
                        <span className="font-bold text-purple-300">Plano Master</span>
                        <Copy size={14} className="opacity-0 group-hover:opacity-100 transition"/>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">master@incluiai.com</div>
                </button>
                
                <button onClick={() => fillLogin('admin@incluiai.com', '123')} className="w-full bg-gray-800 p-4 rounded-xl text-left hover:bg-gray-700 transition border border-gray-700 group mt-4">
                    <div className="flex justify-between items-center">
                        <span className="font-bold text-red-300">ADMIN (CEO)</span>
                        <Copy size={14} className="opacity-0 group-hover:opacity-100 transition"/>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">admin@incluiai.com</div>
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
