-- ============================================================================
-- INCLUIAI — Schema de Produção
-- ============================================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- TENANTS
CREATE TABLE IF NOT EXISTS tenants (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('PROFESSIONAL', 'CLINIC', 'SCHOOL')),
  cnpj TEXT,
  student_limit_base INT DEFAULT 5,
  student_limit_extra INT DEFAULT 0,
  ai_credit_limit INT DEFAULT 10,
  creditos_ia_restantes INT DEFAULT 10,
  status_assinatura TEXT DEFAULT 'ACTIVE' CHECK (status_assinatura IN ('ACTIVE','PENDING','OVERDUE','CANCELED')),
  plano_ativo TEXT DEFAULT 'FREE',
  data_renovacao_plano TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- USERS (profile = auth.users)
CREATE TABLE IF NOT EXISTS users (
  id UUID REFERENCES auth.users NOT NULL PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id) NOT NULL,
  nome TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL DEFAULT 'DOCENTE' CHECK (role IN ('RESPONSAVEL_TECNICO','DOCENTE','AEE','CLINICO','GESTOR','COORDENADOR','CEO')),
  plan TEXT NOT NULL DEFAULT 'FREE',
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Trigger: profile automático no signup
CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE new_tenant_id UUID;
BEGIN
  INSERT INTO tenants (name, type) VALUES (NEW.email, 'PROFESSIONAL') RETURNING id INTO new_tenant_id;
  INSERT INTO users (id, tenant_id, nome, email, role, plan)
  VALUES (NEW.id, new_tenant_id, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1)), NEW.email, 'DOCENTE', 'FREE');
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- updated_at helper
CREATE OR REPLACE FUNCTION update_updated_at() RETURNS TRIGGER LANGUAGE plpgsql AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$;

-- STUDENTS
CREATE TABLE IF NOT EXISTS students (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id) NOT NULL,
  name TEXT NOT NULL,
  tipo_aluno TEXT DEFAULT 'com_laudo' CHECK (tipo_aluno IN ('com_laudo','em_triagem')),
  birth_date DATE, gender TEXT, grade TEXT, shift TEXT,
  guardian_name TEXT, guardian_phone TEXT, guardian_email TEXT,
  school_id TEXT, regent_teacher TEXT, aee_teacher TEXT, coordinator TEXT,
  diagnosis TEXT[] DEFAULT '{}', cid TEXT[] DEFAULT '{}',
  support_level TEXT, medication TEXT, professionals TEXT[] DEFAULT '{}',
  school_history TEXT DEFAULT '', family_context TEXT DEFAULT '',
  abilities TEXT[] DEFAULT '{}', difficulties TEXT[] DEFAULT '{}',
  strategies TEXT[] DEFAULT '{}', communication TEXT[] DEFAULT '{}',
  observations TEXT DEFAULT '', data JSONB DEFAULT '{}',
  photo_url TEXT, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
DROP TRIGGER IF EXISTS students_updated_at ON students;
CREATE TRIGGER students_updated_at BEFORE UPDATE ON students FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- DOCUMENTS
CREATE TABLE IF NOT EXISTS documents (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id) NOT NULL,
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  student_name TEXT, type TEXT NOT NULL,
  status TEXT DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','FINAL')),
  source_id UUID, structured_data JSONB DEFAULT '{"sections":[]}',
  audit_code TEXT UNIQUE, content_hash TEXT,
  generated_by TEXT, last_edited_by TEXT,
  signatures JSONB DEFAULT '{}', versions JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(), last_edited_at TIMESTAMPTZ DEFAULT NOW()
);
DROP TRIGGER IF EXISTS documents_updated_at ON documents;
CREATE TRIGGER documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- COMPLEMENTARY FORMS (fichas complementares)
CREATE TABLE IF NOT EXISTS complementary_forms (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id) NOT NULL,
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  student_name TEXT,
  tipo TEXT NOT NULL CHECK (tipo IN ('obs_regente','escuta_familia','analise_aee','decisao_institucional','acompanhamento_evolucao')),
  titulo TEXT NOT NULL, status TEXT DEFAULT 'rascunho' CHECK (status IN ('rascunho','finalizado')),
  fields JSONB DEFAULT '{}', audit_code TEXT UNIQUE, content_hash TEXT,
  created_by TEXT, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
DROP TRIGGER IF EXISTS forms_updated_at ON complementary_forms;
CREATE TRIGGER forms_updated_at BEFORE UPDATE ON complementary_forms FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tenant_id UUID, user_id UUID, user_name TEXT,
  action TEXT NOT NULL, entity_type TEXT, entity_id UUID,
  details JSONB DEFAULT '{}', ip_address TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
);

-- SUBSCRIPTIONS
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id) UNIQUE NOT NULL,
  plan TEXT NOT NULL DEFAULT 'FREE',
  status TEXT DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','PENDING','OVERDUE','CANCELED')),
  cycle TEXT DEFAULT 'MENSAL' CHECK (cycle IN ('MENSAL','ANUAL')),
  price_cents INT, next_billing TIMESTAMPTZ,
  provider TEXT DEFAULT 'kiwify', provider_sub_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- CREDITS
CREATE TABLE IF NOT EXISTS credits_wallet (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id) UNIQUE NOT NULL,
  balance INT DEFAULT 10, total_earned INT DEFAULT 10, total_spent INT DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS credits_ledger (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id) NOT NULL,
  amount INT NOT NULL,
  operation TEXT NOT NULL CHECK (operation IN ('RENEWAL','MANUAL_GRANT','CONSUMPTION','PURCHASE')),
  description TEXT, ref_id UUID, created_by UUID, created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ADMIN
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('super_admin','financeiro','operacional','viewer')),
  active BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- RLS
-- ============================================================================
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE complementary_forms ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE credits_wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE credits_ledger ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION my_tenant_id() RETURNS UUID LANGUAGE sql STABLE AS $$ SELECT tenant_id FROM users WHERE id = auth.uid(); $$;

DROP POLICY IF EXISTS "tenant_own" ON tenants;         CREATE POLICY "tenant_own"         ON tenants             FOR ALL USING (id = my_tenant_id());
DROP POLICY IF EXISTS "users_tenant" ON users;         CREATE POLICY "users_tenant"        ON users               FOR ALL USING (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "students_tenant" ON students;   CREATE POLICY "students_tenant"     ON students            FOR ALL USING (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "docs_tenant" ON documents;      CREATE POLICY "docs_tenant"         ON documents           FOR ALL USING (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "forms_tenant" ON complementary_forms; CREATE POLICY "forms_tenant"   ON complementary_forms FOR ALL USING (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "audit_read" ON audit_logs;      CREATE POLICY "audit_read"          ON audit_logs          FOR SELECT USING (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "audit_insert" ON audit_logs;    CREATE POLICY "audit_insert"        ON audit_logs          FOR INSERT WITH CHECK (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "sub_tenant" ON subscriptions;   CREATE POLICY "sub_tenant"          ON subscriptions       FOR ALL USING (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "wallet_tenant" ON credits_wallet;   CREATE POLICY "wallet_tenant"   ON credits_wallet      FOR ALL USING (tenant_id = my_tenant_id());
DROP POLICY IF EXISTS "ledger_tenant" ON credits_ledger;   CREATE POLICY "ledger_tenant"   ON credits_ledger      FOR ALL USING (tenant_id = my_tenant_id());

-- ÍNDICES
CREATE INDEX IF NOT EXISTS idx_students_tenant   ON students (tenant_id);
CREATE INDEX IF NOT EXISTS idx_students_tipo     ON students (tipo_aluno);
CREATE INDEX IF NOT EXISTS idx_docs_tenant       ON documents (tenant_id);
CREATE INDEX IF NOT EXISTS idx_docs_student      ON documents (student_id);
CREATE INDEX IF NOT EXISTS idx_docs_audit        ON documents (audit_code);
CREATE INDEX IF NOT EXISTS idx_forms_student     ON complementary_forms (student_id);
CREATE INDEX IF NOT EXISTS idx_audit_entity      ON audit_logs (entity_id, entity_type);

-- VIEW PÚBLICA DE VALIDAÇÃO (sem autenticação)
CREATE OR REPLACE VIEW public.document_validation AS
  SELECT audit_code, type, status, student_name, generated_by, created_at, last_edited_at, content_hash, 'documento' AS entity_type FROM documents WHERE status = 'FINAL'
  UNION ALL
  SELECT audit_code, titulo AS type, status, student_name, created_by AS generated_by, created_at, updated_at AS last_edited_at, content_hash, 'ficha' AS entity_type FROM complementary_forms WHERE status = 'finalizado';

GRANT SELECT ON public.document_validation TO anon;

-- =========================
-- MIGRAÇÕES RECOMENDADAS (produção)
-- =========================
-- 1) Persistência do aceite LGPD (1º acesso)
ALTER TABLE public.users
  ADD COLUMN IF NOT EXISTS lgpd_accepted boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS lgpd_accepted_at timestamptz,
  ADD COLUMN IF NOT EXISTS lgpd_term_version text;

-- 2) Configuração de escolas/equipe por tenant (json)
ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS school_configs jsonb NOT NULL DEFAULT '[]'::jsonb;

-- 3) Opcional: e-mail do responsável (caso você queira persistir)
ALTER TABLE public.students
  ADD COLUMN IF NOT EXISTS guardian_email text;
