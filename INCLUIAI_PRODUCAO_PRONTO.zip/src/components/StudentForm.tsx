import React, { useState, useEffect } from 'react';
import { Student, SchoolConfig, PlanTier, getPlanLimits, StudentType } from '../types';
import { Save, ArrowLeft, Upload, FileText, Trash2, Plus, AlertCircle, Lock, Stethoscope, BookOpen, Users, HelpCircle, X, Paperclip, Sparkles } from 'lucide-react';
import { MultiSelect } from './MultiSelect';
import { SmartTextarea } from './SmartTextarea'; 
import { StorageService } from '../services/storageService';

const DIAGNOSIS_LIBRARY = [
    "TEA (Transtorno do Espectro Autista)", "TDAH (Transtorno de Déficit de Atenção e Hiperatividade)", 
    "Dislexia", "Discalculia", "TOD (Transtorno Opositivo Desafiador)", 
    "Transtorno de Ansiedade", "Deficiência Intelectual", "Paralisia Cerebral", 
    "Síndrome de Down", "Transtorno de Linguagem", "Altas Habilidades / Superdotação", 
    "Epilepsia", "Surdez / Deficiência Auditiva", "Baixa Visão / Deficiência Visual", 
    "Transtorno do Processamento Sensorial", "Síndrome de Asperger (TEA Nível 1)", 
    "Atraso Global do Desenvolvimento"
];

const SKILLS_LIBRARY = [
    "Boa memória visual", "Comunicação funcional", "Interesse por leitura", 
    "Coordenação motora preservada", "Autonomia parcial", "Interação social adequada", 
    "Raciocínio lógico", "Criatividade", "Atenção sustentada (em hiperfoco)", 
    "Organização de materiais", "Boa compreensão verbal", "Participação ativa em sala", 
    "Interesse em tecnologia", "Resolução de problemas simples", "Persistência em tarefas", 
    "Gosto por música/artes", "Reconhecimento de letras/números", "Vocabulário expressivo"
];

const DIFFICULTIES_LIBRARY = [
    "Déficit de atenção", "Impulsividade", "Dificuldade de leitura/decodificação", 
    "Dificuldade matemática", "Baixa tolerância à frustração", "Dificuldade social/interação", 
    "Rigidez comportamental", "Ansiedade em situações novas", "Dificuldade motora fina", 
    "Atraso na linguagem", "Problemas de memória de curto prazo", "Dificuldade de organização", 
    "Resistência a mudanças de rotina", "Dificuldade de interpretação textual", 
    "Dificuldade de concentração prolongada", "Sensibilidade sensorial (ruídos/luz)", 
    "Dificuldade em seguir regras coletivas"
];

const PROFESSIONALS_LIBRARY = [
    "Psicopedagogo", "Psicólogo", "Fonoaudiólogo", "Neuropediatra", 
    "Terapeuta Ocupacional", "Professor de AEE", "Coordenador Pedagógico", 
    "Diretor Escolar", "Médico Psiquiatra", "Assistente Social", 
    "Professor Regente", "Psicólogo Escolar", "Mediador Escolar", 
    "Neuropsicólogo", "Orientador Educacional", "Nutricionista", "Fisioterapeuta"
];

interface Props {
  initialData?: Student | null;
  onSave: (student: Student) => void;
  onCancel: () => void;
  regentName: string;
  availableSchools: SchoolConfig[];
  userPlan: PlanTier; 
}

export const StudentForm: React.FC<Props> = ({ initialData, onSave, onCancel, regentName, availableSchools = [], userPlan }) => {
  const defaultSchoolId = availableSchools && availableSchools.length > 0 ? availableSchools[0].id : '';

  const [formData, setFormData] = useState<Student>({
    id: initialData?.id || crypto.randomUUID(),
    name: initialData?.name || '',
    birthDate: initialData?.birthDate || '',
    gender: initialData?.gender || '',
    guardianName: initialData?.guardianName || '',
    guardianPhone: initialData?.guardianPhone || '',
    guardianEmail: initialData?.guardianEmail || '',
    schoolId: initialData?.schoolId || defaultSchoolId,
    grade: initialData?.grade || '',
    shift: initialData?.shift || '',
    regentTeacher: initialData?.regentTeacher || regentName,
    aeeTeacher: initialData?.aeeTeacher || '',
    coordinator: initialData?.coordinator || '',
    diagnosis: initialData?.diagnosis || [],
    cid: initialData?.cid || [], 
    supportLevel: initialData?.supportLevel || 'Nível 1',
    // Simplificação do fluxo: todo aluno cadastrado aqui é tratado como "com laudo".
    // (Triagem pode ser um módulo separado no futuro.)
    tipo_aluno: 'com_laudo',
    medication: initialData?.medication || '',
    professionals: initialData?.professionals || [],
    abilities: initialData?.abilities || [], 
    difficulties: initialData?.difficulties || [], 
    strategies: initialData?.strategies || [],
    communication: initialData?.communication || [],
    observations: initialData?.observations || '',
    schoolHistory: initialData?.schoolHistory || '',
    familyContext: initialData?.familyContext || '',
    history: initialData?.history || '', 
    photoUrl: initialData?.photoUrl || '',
    registrationDate: initialData?.registrationDate || new Date().toISOString(),
    documents: initialData?.documents || []
  });

  const [cidInput, setCidInput] = useState('');
  const [cidList, setCidList] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const canUpload = getPlanLimits(userPlan)?.uploads ?? false;

  // Get current school config to list professionals
  const currentSchool = availableSchools.find(s => s.id === formData.schoolId);
  const schoolTeam = currentSchool?.team || [];

  const regents = schoolTeam.filter(m => m.role === 'Professor Regente');
  const aees = schoolTeam.filter(m => m.role === 'AEE');
  const coords = schoolTeam.filter(m => ['Coordenador', 'Pedagogo', 'Gestor'].includes(m.role));

  // Auto-preencher campos de equipe ao selecionar a escola.
  useEffect(() => {
    if (!currentSchool) return;

    const firstRegent = regents[0]?.name || '';
    const firstAee = aees[0]?.name || '';
    const firstCoord = coords[0]?.name || '';

    setFormData(prev => ({
      ...prev,
      regentTeacher: prev.regentTeacher || firstRegent || regentName || '',
      aeeTeacher: prev.aeeTeacher || firstAee,
      coordinator: prev.coordinator || firstCoord,
      tipo_aluno: 'com_laudo',
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formData.schoolId]);

  useEffect(() => {
    if (initialData) {
      let normalizedCid: string[] = [];
      if (Array.isArray(initialData.cid)) {
          normalizedCid = initialData.cid;
      } else if (typeof initialData.cid === 'string' && initialData.cid.trim() !== '') {
          normalizedCid = [initialData.cid];
      }
      setCidList(normalizedCid);

      setFormData(prev => ({
        ...prev,
        ...initialData,
        diagnosis: initialData.diagnosis || [],
        professionals: initialData.professionals || [],
        abilities: initialData.abilities || [],
        difficulties: initialData.difficulties || [],
        strategies: initialData.strategies || [],
        communication: initialData.communication || [],
        documents: initialData.documents || [],
        cid: normalizedCid
      }));
    }
  }, [initialData]);

  useEffect(() => {
      setFormData(prev => ({ ...prev, cid: cidList }));
  }, [cidList]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddCid = () => {
      if (cidInput.trim() && !cidList.includes(cidInput.trim().toUpperCase())) {
          setCidList([...cidList, cidInput.trim().toUpperCase()]);
          setCidInput('');
      }
  };

  const handleRemoveCid = (cidToRemove: string) => {
      setCidList(cidList.filter(c => c !== cidToRemove));
  };

  const handleLaudoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (!canUpload) {
          alert("Recurso disponível a partir do plano Pro. Faça upgrade para desbloquear.");
          e.target.value = ''; 
          return;
      }
      const file = e.target.files?.[0];
      if (!file) return;

      setIsUploading(true);
      try {
          const cleanName = file.name.replace(/[^a-zA-Z0-9.]/g, '_');
          const path = `${formData.id}/${Date.now()}_${cleanName}`;
          
          const url = await StorageService.uploadFile(file, 'laudos', path);
          
          if (url) {
              const newDoc = {
                  name: file.name,
                  date: new Date().toLocaleDateString(),
                  type: 'Laudo' as const,
                  url: url 
              };
              setFormData(prev => ({
                  ...prev,
                  documents: [...(prev.documents || []), newDoc]
              }));
              alert("Laudo anexado! A IA usará este documento para analisar o caso.");
          } else {
              throw new Error("Falha ao processar arquivo.");
          }
      } catch (error) {
          console.error(error);
          alert("Erro no upload. Tente novamente.");
      } finally {
          setIsUploading(false);
          e.target.value = ''; 
      }
  };

  const handleRemoveDoc = (index: number) => {
      if (confirm("Remover este anexo? A exclusão é permanente.")) {
          const newDocs = [...(formData.documents || [])];
          newDocs.splice(index, 1);
          setFormData(prev => ({ ...prev, documents: newDocs }));
      }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.schoolId) {
        alert("Preencha os campos obrigatórios (Nome e Escola).");
        return;
    }
    onSave(formData);
  };

  const Tooltip = ({text}: {text: string}) => (
      <div className="group relative inline-block ml-1">
          <HelpCircle size={12} className="text-gray-400 cursor-help"/>
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block w-48 bg-gray-800 text-white text-xs rounded p-2 z-10">
              {text}
          </div>
      </div>
  );

  const isModoTriagem = formData.tipo_aluno === 'em_triagem';

  return (
    <div className="max-w-5xl mx-auto pb-20">
      
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
            <button onClick={onCancel} className="text-gray-500 hover:text-gray-700"><ArrowLeft size={24} /></button>
            <div>
                <h2 className="text-2xl font-bold text-gray-800">{initialData ? 'Editar Aluno' : 'Novo Cadastro'}</h2>
                <p className="text-sm text-gray-500">Preencha os dados completos para gerar documentos automáticos.</p>
            </div>
        </div>
      </div>

      {/* Banner de modo */}
      <div className={`mb-4 p-4 rounded-xl border flex items-center gap-3 ${isModoTriagem ? 'bg-yellow-50 border-yellow-200' : 'bg-blue-50 border-blue-200'}`}>
        <span className="text-2xl">{isModoTriagem ? '🔍' : '📋'}</span>
        <div className="flex-1">
          <p className={`font-bold text-sm ${isModoTriagem ? 'text-yellow-800' : 'text-blue-800'}`}>
            {isModoTriagem ? 'Modo: Aluno em Triagem/Observação' : 'Modo: Aluno Neurodivergente (com Laudo)'}
          </p>
          <p className={`text-xs mt-0.5 ${isModoTriagem ? 'text-yellow-700' : 'text-blue-700'}`}>
            {isModoTriagem
              ? 'Dados clínicos (CID, diagnóstico, medicação) estão ocultos. Podem ser adicionados futuramente após laudo.'
              : 'Formulário completo com dados clínicos, diagnóstico e medicação.'}
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 space-y-8">
        
        {/* Identificação */}
        <div className="flex flex-col md:flex-row gap-8 items-start">
            <div className="flex flex-col items-center space-y-3">
                <div className="w-32 h-32 bg-gray-100 rounded-full border-4 border-white shadow-md overflow-hidden flex items-center justify-center relative group">
                     {formData.photoUrl ? <img src={formData.photoUrl} className="w-full h-full object-cover" /> : <span className="text-gray-400 text-xs">Foto</span>}
                     <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer">
                        <Upload className="text-white" size={24} />
                        <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" onChange={handlePhotoUpload} />
                     </div>
                </div>
            </div>
            <div className="flex-1 w-full grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                    <label className="label">Nome Completo *</label>
                    <input required name="name" value={formData.name} onChange={handleChange} className="input-field" placeholder="Nome do aluno" />
                    <p className="text-[10px] text-gray-400 mt-1">Clique aqui e insira o nome conforme certidão.</p>
                </div>
                <div><label className="label">Data de Nascimento *</label><input required type="date" name="birthDate" value={formData.birthDate} onChange={handleChange} className="input-field" /></div>
                <div><label className="label">Gênero</label><select name="gender" value={formData.gender} onChange={handleChange} className="input-field"><option value="">Selecione</option><option value="M">Masculino</option><option value="F">Feminino</option></select></div>
                <div><label className="label">Responsável Legal</label><input name="guardianName" value={formData.guardianName} onChange={handleChange} className="input-field" /></div>
                <div><label className="label">Telefone/WhatsApp</label><input name="guardianPhone" value={formData.guardianPhone} onChange={handleChange} className="input-field" /></div>
            </div>
        </div>

        {/* Dados Escolares & Vínculos */}
        <section>
          <h3 className="section-title"><BookOpen size={20} className="text-brand-600"/> Dados Escolares & Equipe</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="label">Escola *</label>
              <select name="schoolId" value={formData.schoolId} onChange={(e) => setFormData(prev => ({...prev, schoolId: e.target.value}))} className="input-field">
                  {availableSchools.length === 0 && <option value="">Nenhuma escola cadastrada</option>}
                  {availableSchools.map(s => <option key={s.id} value={s.id}>{s.schoolName}</option>)}
              </select>
            </div>
            
            <div><label className="label">Série/Ano</label><input name="grade" value={formData.grade} onChange={handleChange} className="input-field" /></div>
            <div><label className="label">Turno</label><select name="shift" value={formData.shift} onChange={handleChange} className="input-field"><option value="">Selecione</option><option value="Matutino">Matutino</option><option value="Vespertino">Vespertino</option><option value="Integral">Integral</option></select></div>
            
            {/* Professor Regente Vínculo */}
            <div>
                <label className="label">Professor Regente</label>
                <input 
                    list="regents" 
                    name="regentTeacher" 
                    value={formData.regentTeacher} 
                    onChange={handleChange} 
                    className="input-field" 
                    placeholder="Selecione ou digite..."
                />
                <datalist id="regents">
                    {regents.map(r => <option key={r.id} value={r.name}/>)}
                </datalist>
            </div>

            {/* AEE Vínculo */}
            <div>
                <label className="label">Prof. AEE / Especialista</label>
                <input 
                    list="aees" 
                    name="aeeTeacher" 
                    value={formData.aeeTeacher} 
                    onChange={handleChange} 
                    className="input-field" 
                    placeholder="Selecione ou digite..."
                />
                <datalist id="aees">
                    {aees.map(r => <option key={r.id} value={r.name}/>)}
                </datalist>
            </div>

            {/* Coordenação Vínculo */}
            <div>
                <label className="label">Coordenação / Gestão</label>
                <input 
                    list="coords" 
                    name="coordinator" 
                    value={formData.coordinator} 
                    onChange={handleChange} 
                    className="input-field" 
                    placeholder="Selecione ou digite..."
                />
                <datalist id="coords">
                    {coords.map(r => <option key={r.id} value={r.name}/>)}
                </datalist>
            </div>

          </div>
        </section>

        {/* Dados Clínicos — oculto para triagem */}
        {!isModoTriagem && (
        <section>
          <h3 className="section-title"><Stethoscope size={20} className="text-brand-600"/> Dados Clínicos e de Saúde</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-3">
                <MultiSelect 
                    label="Diagnóstico(s)" 
                    options={DIAGNOSIS_LIBRARY} 
                    selected={formData.diagnosis} 
                    onChange={(v) => setFormData({...formData, diagnosis: v})} 
                    placeholder="Selecione ou digite..."
                />
            </div>
            
            <div>
                <label className="label">CID (Código) <Tooltip text="Código Internacional de Doenças. Ex: F84.0"/></label>
                <div className="flex gap-2 mb-2">
                    <input 
                        value={cidInput} 
                        onChange={e => setCidInput(e.target.value)} 
                        className="input-field uppercase" 
                        placeholder="Ex: F84.0" 
                        onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddCid())}
                    />
                    <button type="button" onClick={handleAddCid} className="bg-brand-600 text-white px-3 rounded-md hover:bg-brand-700 transition">
                        <Plus size={18}/>
                    </button>
                </div>
                <div className="flex flex-wrap gap-1">
                    {cidList.map((cid, idx) => (
                        <span key={idx} className="bg-gray-200 text-gray-800 text-xs px-2 py-1 rounded-full flex items-center gap-1">
                            {cid}
                            <button type="button" onClick={() => handleRemoveCid(cid)} className="hover:text-red-600"><X size={12}/></button>
                        </span>
                    ))}
                </div>
            </div>

            {/* Tipo de aluno removido do formulário: todo cadastro aqui é "Aluno com Laudo". */}
            <div><label className="label">Nível de Suporte</label><select name="supportLevel" value={formData.supportLevel} onChange={handleChange} className="input-field"><option>Nível 1</option><option>Nível 2</option><option>Nível 3</option></select></div>
            <div className="md:col-span-3"><label className="label">Medicação em uso</label><input name="medication" value={formData.medication} onChange={handleChange} className="input-field" placeholder="Nome, dosagem e horário (se houver na escola)" /></div>
            <div className="md:col-span-3">
                <MultiSelect 
                    label="Profissionais Externos" 
                    options={PROFESSIONALS_LIBRARY} 
                    selected={formData.professionals} 
                    onChange={(v) => setFormData({...formData, professionals: v})} 
                    placeholder="Selecione ou digite..."
                />
            </div>

            {/* Upload de Laudos */}
            <div className="md:col-span-3 bg-gray-50 p-4 rounded-lg border border-dashed border-gray-300">
                <label className="label flex items-center gap-2 mb-2">
                    <Paperclip size={16}/> Documentos, Laudos e Relatórios
                </label>
                <div className="flex items-center gap-4 mb-4">
                    <label className={`cursor-pointer bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-bold shadow-sm hover:bg-gray-50 flex items-center gap-2 ${!canUpload ? 'opacity-50 cursor-not-allowed' : ''}`}>
                         <Upload size={16}/> {isUploading ? 'Enviando...' : 'Anexar Documento'}
                         <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png" onChange={handleLaudoUpload} disabled={isUploading} />
                    </label>
                    {!canUpload && <span className="text-xs text-orange-600 font-bold bg-orange-50 px-2 py-1 rounded flex items-center gap-1"><Lock size={10}/> Recurso PRO/Master</span>}
                </div>
                
                <p className="text-xs text-gray-500 mb-3">
                    <Sparkles size={12} className="inline text-brand-500 mr-1"/>
                    A IA analisará estes documentos para gerar sugestões precisas nos relatórios e PEI.
                </p>

                <div className="space-y-2">
                    {formData.documents?.map((doc, idx) => (
                        <div key={idx} className="flex justify-between items-center bg-white p-2 rounded border border-gray-200 text-sm">
                            <div className="flex items-center gap-2">
                                <FileText size={16} className="text-brand-500"/>
                                <span className="text-gray-700 font-medium">{doc.name}</span>
                                <span className="text-xs text-gray-400">({doc.date})</span>
                            </div>
                            <div className="flex gap-2">
                                <a href={doc.url} target="_blank" rel="noreferrer" className="text-brand-600 text-xs hover:underline flex items-center gap-1 font-bold">Ver</a>
                                <button type="button" onClick={() => handleRemoveDoc(idx)} className="text-red-400 hover:text-red-600"><Trash2 size={14}/></button>
                            </div>
                        </div>
                    ))}
                    {(!formData.documents || formData.documents.length === 0) && <p className="text-xs text-gray-400 italic">Nenhum documento anexado.</p>}
                </div>
            </div>

          </div>
        </section>
        )} {/* fim !isModoTriagem */}

        {/* Histórico e Contexto */}
        <section>
          <h3 className="section-title"><Users size={20} className="text-brand-600"/> Contexto e Histórico</h3>
          <div className="space-y-6">
             {isModoTriagem && (
               <div className="bg-yellow-50 border border-yellow-100 rounded-xl p-4">
                 <label className="label mb-2 text-yellow-800">Com quem vive / Composição familiar</label>
                 <SmartTextarea value={formData.familyContext} onChange={(v) => setFormData({...formData, familyContext: v})} placeholder="Ex: mora com mãe e avó; pai ausente; família extensa próxima..." context="social" />
               </div>
             )}
             <div>
                <label className="label mb-2">Histórico Escolar Prégresso</label>
                <SmartTextarea value={formData.schoolHistory} onChange={(v) => setFormData({...formData, schoolHistory: v})} placeholder="Relate brevemente a trajetória escolar anterior (repetências, trocas de escola...)" context="general" />
                <p className="text-[10px] text-gray-400 mt-1">Use o microfone para ditar o histórico.</p>
             </div>
             {!isModoTriagem && (
             <div>
                <label className="label mb-2">Contexto Familiar</label>
                <SmartTextarea value={formData.familyContext} onChange={(v) => setFormData({...formData, familyContext: v})} placeholder="Dinâmica familiar, quem cuida, apoio em casa..." context="social" />
             </div>
             )}
             <div>
                <label className="label mb-2">Observações Gerais {isModoTriagem ? '/ Observações Iniciais' : ''}</label>
                <SmartTextarea value={formData.observations} onChange={(v) => setFormData({...formData, observations: v})} placeholder={isModoTriagem ? "Descreva o que motivou a triagem, comportamentos observados, queixas..." : "Outras informações relevantes..."} context="general" />
             </div>
          </div>
        </section>

        {/* Habilidades e Dificuldades */}
        <section>
            <h3 className="section-title"><AlertCircle size={20} className="text-brand-600"/> Perfil Pedagógico</h3>
            <div className="space-y-4">
                <MultiSelect 
                    label="Habilidades / Potencialidades" 
                    options={SKILLS_LIBRARY} 
                    selected={formData.abilities} 
                    onChange={v => setFormData({...formData, abilities: v})} 
                />
                <MultiSelect 
                    label="Dificuldades / Barreiras" 
                    options={DIFFICULTIES_LIBRARY} 
                    selected={formData.difficulties} 
                    onChange={v => setFormData({...formData, difficulties: v})} 
                />
            </div>
        </section>

        <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
          <button type="button" onClick={onCancel} className="btn-secondary">Cancelar</button>
          <button type="submit" className="btn-primary">Salvar Aluno</button>
        </div>
      </form>
      <style>{`
        .label { display: block; font-size: 0.875rem; font-weight: 600; color: #374151; margin-bottom: 0.25rem; }
        .input-field { width: 100%; border-radius: 0.5rem; border: 1px solid #d1d5db; padding: 0.625rem; outline: none; transition: border-color 0.2s; }
        .input-field:focus { border-color: #0d9488; ring: 2px; ring-color: #0d9488; }
        .section-title { font-size: 1.125rem; font-weight: 700; color: #1f2937; border-bottom: 1px solid #f3f4f6; padding-bottom: 0.5rem; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem; }
        .btn-primary { background-color: #0f766e; color: white; padding: 0.625rem 1.5rem; border-radius: 0.5rem; font-weight: 700; display: flex; align-items: center; gap: 0.5rem; transition: background-color 0.2s; }
        .btn-primary:hover { background-color: #115e59; }
        .btn-secondary { border: 1px solid #d1d5db; color: #374151; padding: 0.625rem 1.5rem; border-radius: 0.5rem; font-weight: 600; background-color: white; transition: background-color 0.2s; }
        .btn-secondary:hover { background-color: #f9fafb; }
      `}</style>
    </div>
  );
};