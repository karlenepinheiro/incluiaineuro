import React, { useEffect, useMemo, useState } from 'react';
import { AddOnProduct, TenantSummary, User, SchoolConfig, PlanTier, TeamMember } from '../types';
import { Plus, Trash2, School, User as UserIcon, CreditCard, Star, Mail, Settings, Sparkles, BadgeCheck, AlertTriangle, ShoppingCart } from 'lucide-react';
import { PaymentService, DEFAULT_ADDONS } from '../services/paymentService';
import { databaseService } from '../services/databaseService';

interface SettingsViewProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ user, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'team' | 'finance'>('profile');
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [schools, setSchools] = useState<SchoolConfig[]>(user.schoolConfigs);
  const [newSchool, setNewSchool] = useState<Partial<SchoolConfig>>({ schoolName: '' });
  
  // Team Edit State
  const [editingSchoolId, setEditingSchoolId] = useState<string | null>(null);
  const [newMember, setNewMember] = useState<Partial<TeamMember>>({ role: 'Professor Regente' });

  // MOCK DATA for invites (merged with real user logic ideally)
  const [invites] = useState([
      { id: 1, email: 'fono@clinica.com', status: 'Pendente', date: '12/05/2024' },
      { id: 2, email: 'coord@escola.com', status: 'Aceito', date: '10/05/2024' }
  ]);

  const handleSaveProfile = () => {
    onUpdateUser({ ...user, name, email, schoolConfigs: schools });
    alert("Configurações salvas com sucesso!");
  };

  const [tenantSummary, setTenantSummary] = useState<TenantSummary | null>(null);
  const [financeBusy, setFinanceBusy] = useState(false);
  const [financeError, setFinanceError] = useState<string | null>(null);

  const totalStudentLimit = useMemo(() => {
    if (!tenantSummary) return null;
    return (tenantSummary.studentLimitBase || 0) + (tenantSummary.studentLimitExtra || 0);
  }, [tenantSummary]);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setFinanceError(null);
        const summary = await databaseService.getTenantSummary(user.id);
        if (alive) setTenantSummary(summary);
      } catch (e: any) {
        if (alive) setFinanceError(e?.message || 'Falha ao carregar dados financeiros');
      }
    })();
    return () => {
      alive = false;
    };
  }, [user.id]);

  const addSchool = () => {
    if (!newSchool.schoolName) return alert("Nome obrigatório");
    const s: SchoolConfig = { 
        id: crypto.randomUUID(), 
        schoolName: newSchool.schoolName!, 
        managerName: '', 
        aeeRepresentative: '', 
        contact: '',
        team: [] // Initialize empty team
    };
    const updated = [...schools, s];
    setSchools(updated);
    onUpdateUser({ ...user, schoolConfigs: updated });
    setNewSchool({ schoolName: '' });
  };

  const addTeamMember = (schoolId: string) => {
      if (!newMember.name) return alert("Nome do profissional é obrigatório");
      
      const updatedSchools = schools.map(s => {
          if (s.id === schoolId) {
              const member: TeamMember = {
                  id: crypto.randomUUID(),
                  name: newMember.name!,
                  email: newMember.email || '',
                  phone: newMember.phone || '',
                  role: newMember.role as any
              };
              return { ...s, team: [...(s.team || []), member] };
          }
          return s;
      });
      
      setSchools(updatedSchools);
      onUpdateUser({ ...user, schoolConfigs: updatedSchools });
      setNewMember({ role: 'Professor Regente', name: '', email: '', phone: '' });
  };

  const removeTeamMember = (schoolId: string, memberId: string) => {
      const updatedSchools = schools.map(s => {
          if (s.id === schoolId) {
              return { ...s, team: (s.team || []).filter(m => m.id !== memberId) };
          }
          return s;
      });
      setSchools(updatedSchools);
      onUpdateUser({ ...user, schoolConfigs: updatedSchools });
  };

  const handleUpgrade = async (targetPlan: PlanTier) => {
      const url = await PaymentService.getCheckoutUrl(targetPlan, user);
      window.location.href = url;
  };

  const openCustomerPortal = async () => {
    try {
      setFinanceBusy(true);
      const url = await PaymentService.manageSubscription(user.id);
      window.open(url, '_blank');
    } catch (e: any) {
      alert(e?.message || 'Não foi possível abrir o portal de cobrança.');
    } finally {
      setFinanceBusy(false);
    }
  };

  const buyAddOn = async (product: AddOnProduct) => {
    if (!tenantSummary) return;
    try {
      setFinanceBusy(true);
      await databaseService.createPurchaseIntent({
        tenantId: tenantSummary.tenantId,
        userId: user.id,
        kind: product.kind,
        sku: product.sku,
        quantity: product.quantity,
        priceCents: product.priceCents,
      });
      const url = await PaymentService.getAddOnCheckoutUrl(product.sku, user, {
        qty: String(product.quantity),
        kind: product.kind,
      });
      window.open(url, '_blank');
    } catch (e: any) {
      alert(e?.message || 'Não foi possível abrir o checkout do pacote.');
    } finally {
      setFinanceBusy(false);
    }
  };

  const isOverdue = tenantSummary?.subscriptionStatus === 'OVERDUE' || tenantSummary?.subscriptionStatus === 'PENDING';

  return (
    <div className="max-w-5xl mx-auto pb-20">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Configurações</h2>
      <div className="flex gap-4 mb-8 border-b border-gray-200 overflow-x-auto">
          <button onClick={() => setActiveTab('profile')} className={`pb-3 px-2 font-bold text-sm whitespace-nowrap ${activeTab === 'profile' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>Perfil</button>
          <button onClick={() => setActiveTab('team')} className={`pb-3 px-2 font-bold text-sm whitespace-nowrap ${activeTab === 'team' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>Equipe & Escolas</button>
          <button onClick={() => setActiveTab('finance')} className={`pb-3 px-2 font-bold text-sm whitespace-nowrap ${activeTab === 'finance' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>Financeiro</button>
      </div>

      {activeTab === 'profile' && (
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
              <h3 className="text-lg font-bold mb-4 flex gap-2 items-center"><UserIcon size={20}/> Seus Dados</h3>
              <div className="space-y-4 max-w-md">
                  <input value={name} onChange={e => setName(e.target.value)} className="w-full border p-2 rounded" placeholder="Nome"/>
                  <input value={email} onChange={e => setEmail(e.target.value)} className="w-full border p-2 rounded" placeholder="Email"/>
                  <button onClick={handleSaveProfile} className="bg-brand-600 text-white px-4 py-2 rounded font-bold">Salvar</button>
              </div>
          </div>
      )}

      {activeTab === 'team' && (
          <div className="space-y-8">
              {/* School List */}
              <div>
                  <h3 className="text-lg font-bold mb-4 flex gap-2 items-center text-gray-800"><School size={20}/> Gestão de Escolas e Equipes</h3>
                  <div className="grid gap-6">
                      {schools.map(s => (
                          <div key={s.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                              <div className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
                                  <div className="flex items-center gap-3">
                                      <School className="text-brand-600"/>
                                      <h4 className="font-bold text-gray-800">{s.schoolName}</h4>
                                  </div>
                                  <div className="flex gap-2">
                                      <button onClick={() => setEditingSchoolId(editingSchoolId === s.id ? null : s.id)} className="text-sm text-brand-600 font-bold border border-brand-200 bg-white px-3 py-1 rounded hover:bg-brand-50">
                                          {editingSchoolId === s.id ? 'Fechar Equipe' : 'Gerenciar Equipe'}
                                      </button>
                                      <button onClick={() => setSchools(schools.filter(x => x.id !== s.id))} className="text-red-500 hover:bg-red-50 p-1 rounded"><Trash2 size={16}/></button>
                                  </div>
                              </div>
                              
                              {/* Team Management Section */}
                              {editingSchoolId === s.id && (
                                  <div className="p-4 bg-white">
                                      <h5 className="text-xs font-bold text-gray-500 uppercase mb-3">Equipe Multidisciplinar Cadastrada</h5>
                                      
                                      {/* Add Member Form */}
                                      <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-6 bg-blue-50 p-3 rounded-lg border border-blue-100">
                                          <select className="border p-2 rounded text-sm" value={newMember.role} onChange={e => setNewMember({...newMember, role: e.target.value as any})}>
                                              <option>Professor Regente</option>
                                              <option>AEE</option>
                                              <option>Coordenador</option>
                                              <option>Pedagogo</option>
                                              <option>Gestor</option>
                                              <option>Outros</option>
                                          </select>
                                          <input className="border p-2 rounded text-sm" placeholder="Nome Completo *" value={newMember.name || ''} onChange={e => setNewMember({...newMember, name: e.target.value})}/>
                                          <input className="border p-2 rounded text-sm" placeholder="Email (Opcional)" value={newMember.email || ''} onChange={e => setNewMember({...newMember, email: e.target.value})}/>
                                          <button onClick={() => addTeamMember(s.id)} className="bg-blue-600 text-white rounded text-sm font-bold hover:bg-blue-700 flex items-center justify-center gap-1">
                                              <Plus size={14}/> Adicionar
                                          </button>
                                      </div>

                                      {/* Member List */}
                                      <div className="space-y-2">
                                          {(s.team || []).length === 0 && <p className="text-sm text-gray-400 italic">Nenhum profissional cadastrado.</p>}
                                          {(s.team || []).map(member => (
                                              <div key={member.id} className="flex justify-between items-center border-b border-gray-100 pb-2 last:border-0">
                                                  <div className="flex items-center gap-3">
                                                      <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 font-bold text-xs">
                                                          {member.name.charAt(0)}
                                                      </div>
                                                      <div>
                                                          <p className="text-sm font-bold text-gray-800">{member.name}</p>
                                                          <p className="text-xs text-gray-500">{member.role} {member.email && `• ${member.email}`}</p>
                                                      </div>
                                                  </div>
                                                  <button onClick={() => removeTeamMember(s.id, member.id)} className="text-red-400 hover:text-red-600"><Trash2 size={14}/></button>
                                              </div>
                                          ))}
                                      </div>
                                  </div>
                              )}
                          </div>
                      ))}
                  </div>
                  
                  {/* Add School */}
                  <div className="flex gap-2 mt-6 max-w-md">
                      <input value={newSchool.schoolName} onChange={e => setNewSchool({schoolName: e.target.value})} className="border p-2 rounded flex-1" placeholder="Nome da Nova Escola"/>
                      <button onClick={addSchool} className="bg-gray-800 text-white px-4 py-2 rounded font-bold hover:bg-gray-900">Adicionar Escola</button>
                  </div>
              </div>

              {/* Invites Overview */}
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
                  <h3 className="text-lg font-bold mb-4 flex gap-2 items-center"><Mail size={20}/> Convites Recentes</h3>
                  <table className="w-full text-sm text-left">
                      <thead><tr className="border-b"><th className="pb-2">Email</th><th className="pb-2">Status</th><th className="pb-2">Data</th></tr></thead>
                      <tbody>
                          {invites.map(i => (
                              <tr key={i.id} className="border-b last:border-0">
                                  <td className="py-2">{i.email}</td>
                                  <td className="py-2"><span className={`px-2 rounded text-xs font-bold ${i.status === 'Aceito' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-800'}`}>{i.status}</span></td>
                                  <td className="py-2">{i.date}</td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

      {activeTab === 'finance' && (
          <div className="space-y-6">

            {/* HERO CARD */}
            <div className="bg-gradient-to-br from-white to-brand-50 p-8 rounded-2xl shadow-sm border border-gray-200">
              <div className="flex items-start justify-between gap-6 flex-wrap">
                <div>
                  <h3 className="text-xl font-extrabold text-gray-900 flex items-center gap-2">
                    <CreditCard size={20} className="text-brand-600" /> Financeiro
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">Controle da assinatura, créditos e limites.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    disabled={financeBusy}
                    onClick={openCustomerPortal}
                    className="border border-gray-300 bg-white text-gray-700 px-4 py-2 rounded-xl font-bold hover:bg-gray-50 flex items-center gap-2 disabled:opacity-60"
                  >
                    <Settings size={16} /> Gerenciar cobranças
                  </button>
                  {user.plan === PlanTier.FREE && (
                    <button
                      disabled={financeBusy}
                      onClick={() => handleUpgrade(PlanTier.PRO)}
                      className="bg-brand-600 text-white px-4 py-2 rounded-xl font-bold shadow hover:bg-brand-700 flex items-center gap-2 disabled:opacity-60"
                    >
                      <Star size={16} /> Virar PRO
                    </button>
                  )}
                </div>
              </div>

              {financeError && (
                <div className="mt-4 p-3 rounded-xl bg-red-50 border border-red-100 text-sm text-red-700">
                  {financeError}
                </div>
              )}

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-white border border-gray-200">
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase font-extrabold text-gray-500">Status</span>
                    {isOverdue ? (
                      <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full bg-yellow-100 text-yellow-800">
                        <AlertTriangle size={14} /> Pendente
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full bg-green-100 text-green-700">
                        <BadgeCheck size={14} /> Ativo
                      </span>
                    )}
                  </div>
                  <div className="mt-3 text-2xl font-extrabold text-gray-900">
                    {tenantSummary?.planTier ? tenantSummary.planTier : user.plan}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Renovação do plano: {tenantSummary?.renewalDatePlan ? new Date(tenantSummary.renewalDatePlan).toLocaleDateString() : '—'}</p>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-gray-200">
                  <span className="text-xs uppercase font-extrabold text-gray-500">Créditos IA</span>
                  <div className="mt-2 text-3xl font-extrabold text-gray-900">
                    {tenantSummary ? tenantSummary.aiCreditsRemaining : '—'}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Renovação de créditos: {tenantSummary?.renewalDateCredits ? new Date(tenantSummary.renewalDateCredits).toLocaleDateString() : '—'}</p>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-gray-200">
                  <span className="text-xs uppercase font-extrabold text-gray-500">Alunos ativos</span>
                  <div className="mt-2 text-3xl font-extrabold text-gray-900">
                    {tenantSummary ? `${tenantSummary.studentsActive}/${totalStudentLimit ?? '—'}` : '—'}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Base: {tenantSummary?.studentLimitBase ?? '—'} • Extras: {tenantSummary?.studentLimitExtra ?? '—'}</p>
                </div>
              </div>

              {isOverdue && (
                <div className="mt-4 p-4 rounded-2xl bg-yellow-50 border border-yellow-100 flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <p className="font-extrabold text-yellow-900">Pagamento pendente</p>
                    <p className="text-sm text-yellow-800">Para manter acesso completo, regularize sua assinatura.</p>
                  </div>
                  <button
                    disabled={financeBusy}
                    onClick={openCustomerPortal}
                    className="bg-yellow-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-yellow-700 flex items-center gap-2 disabled:opacity-60"
                  >
                    <CreditCard size={16} /> Pagar agora
                  </button>
                </div>
              )}
            </div>

            {/* ADD-ONS */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                  <h4 className="text-lg font-extrabold text-gray-900 flex items-center gap-2">
                    <ShoppingCart size={18} className="text-brand-600" /> Pacotes extras
                  </h4>
                  <p className="text-sm text-gray-600 mt-1">Compre créditos IA e/ou amplie limite de alunos sem trocar de plano.</p>
                </div>
                <div className="text-xs text-gray-500">* Checkout abre em nova aba (Kiwify)</div>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                {DEFAULT_ADDONS.map(p => (
                  <div key={p.sku} className={`p-4 rounded-2xl border ${p.recommended ? 'border-brand-200 bg-brand-50' : 'border-gray-200 bg-white'}`}>
                    <div className="flex items-center justify-between">
                      <div className="font-extrabold text-gray-900">{p.title}</div>
                      {p.recommended && (
                        <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full bg-brand-600 text-white">
                          <Sparkles size={14} /> Recomendado
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{p.description}</p>
                    <div className="mt-3 text-2xl font-extrabold text-gray-900">
                      {(p.priceCents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </div>
                    <button
                      disabled={financeBusy || !tenantSummary}
                      onClick={() => buyAddOn(p)}
                      className="mt-4 w-full bg-gray-900 text-white py-3 rounded-xl font-bold hover:bg-black flex items-center justify-center gap-2 disabled:opacity-60"
                    >
                      <ShoppingCart size={16} /> Comprar
                    </button>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 rounded-2xl bg-gray-50 border border-gray-200">
                <p className="text-sm text-gray-700">
                  <span className="font-bold">Dica:</span> Se você for usar o sistema em grupo, o mais rápido é comprar <b>alunos extras</b>.
                  Se for uso individual, normalmente <b>créditos IA</b> resolvem.
                </p>
              </div>
            </div>

          </div>
      )}
    </div>
  );
};