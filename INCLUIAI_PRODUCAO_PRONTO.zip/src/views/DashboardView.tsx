import React, { useEffect, useMemo, useState } from 'react';
import { Users, FileText, AlertCircle, Zap } from 'lucide-react';
import { Student, Protocol } from '../types';

interface DashboardViewProps {
  /** Nome do usuário logado (para saudação correta). */
  userName?: string;

  students: Student[];
  protocols: Protocol[];

  /** ✅ Fonte única (do banco): plans.max_students */
  planMaxStudents?: number;

  /** ✅ Fonte única (do banco): plans.monthly_credits (teto mensal) */
  planMonthlyCredits?: number;

  /**
   * ✅ Fonte única (do banco): credits_wallet.credits_avail (saldo atual disponível)
   * IMPORTANTE: NÃO use credits_wallet.balance (pode estar legado/bugado).
   */
  creditsAvailable?: number;

  /** ✅ Fonte única (do banco): credits_wallet.reset_at */
  creditsResetAt?: string | null;
}

type MeterMode = 'gauge' | 'bar';

function clamp(n: number, a = 0, b = 100) {
  return Math.max(a, Math.min(b, n));
}

function formatPct(n: number) {
  const v = clamp(n, 0, 100);
  return `${Math.round(v)}%`;
}

function greetingByHour(date = new Date()) {
  const h = date.getHours();
  if (h < 12) return 'Bom dia';
  if (h < 18) return 'Boa tarde';
  return 'Boa noite';
}

function BarMeter({ valuePct }: { valuePct: number }) {
  const v = clamp(valuePct);
  return (
    <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
      <div
        className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-700 ease-out"
        style={{ width: `${v}%` }}
      />
    </div>
  );
}

function GaugeMeter({ valuePct }: { valuePct: number }) {
  const v = clamp(valuePct);
  const r = 44;
  const c = Math.PI * r;
  const dash = (v / 100) * c;
  const gap = c - dash;

  return (
    <div className="flex items-center gap-4">
      <svg width="110" height="65" viewBox="0 0 110 65">
        <path
          d="M10,55 A45,45 0 0 1 100,55"
          fill="none"
          stroke="#E5E7EB"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path
          d="M10,55 A45,45 0 0 1 100,55"
          fill="none"
          stroke="url(#g)"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${gap}`}
          className="transition-all duration-700 ease-out"
        />
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="110" y2="0">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#8B5CF6" />
          </linearGradient>
        </defs>
      </svg>
      <div className="text-2xl font-semibold text-gray-900">{formatPct(v)}</div>
    </div>
  );
}

function MeterCard({
  title,
  subtitle,
  valuePct,
  mode,
  onToggle,
  footer
}: {
  title: string;
  subtitle: string;
  valuePct: number;
  mode: MeterMode;
  onToggle: () => void;
  footer?: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-[fadeUp_.45s_ease-out]">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm font-semibold text-gray-700">{title}</div>
          <div className="text-xs text-gray-500 mt-1">{subtitle}</div>
        </div>
        <button
          onClick={onToggle}
          className="text-xs px-3 py-1 rounded-full border border-gray-200 hover:bg-gray-50 transition"
          title="Alternar visual"
        >
          {mode === 'gauge' ? 'Velocímetro' : 'Barra'}
        </button>
      </div>

      <div className="mt-5">
        {mode === 'gauge' ? <GaugeMeter valuePct={valuePct} /> : <BarMeter valuePct={valuePct} />}
      </div>

      {footer ? <div className="mt-4 text-xs text-gray-500">{footer}</div> : null}
    </div>
  );
}

function fmtDateBR(iso?: string | null) {
  if (!iso) return null;
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return null;
  return d.toLocaleDateString('pt-BR');
}

export function DashboardView({
  userName,
  students,
  protocols,
  planMaxStudents,
  planMonthlyCredits,
  creditsAvailable,
  creditsResetAt
}: DashboardViewProps) {
  const [modeStudents, setModeStudents] = useState<MeterMode>('gauge');
  const [modeCredits, setModeCredits] = useState<MeterMode>('bar');

  useEffect(() => {
    const styleId = 'dash-anim';
    if (document.getElementById(styleId)) return;
    const style = document.createElement('style');
    style.id = styleId;
    style.innerHTML = `
      @keyframes fadeUp { from { opacity: 0; transform: translateY(8px);} to { opacity: 1; transform: translateY(0);} }
    `;
    document.head.appendChild(style);
  }, []);

  const kpis = useMemo(() => {
    const total = protocols.length;
    const finals = protocols.filter(p => p.status === 'FINAL').length;
    const drafts = protocols.filter(p => p.status === 'DRAFT').length;
    const pending = drafts;

    const byType = protocols.reduce<Record<string, number>>((acc, p) => {
      acc[String(p.type)] = (acc[String(p.type)] || 0) + 1;
      return acc;
    }, {});

    return { total, finals, drafts, pending, byType };
  }, [protocols]);

  // ✅ Fonte única: limites vindos do banco (com fallback seguro)
  const maxStudents = Number.isFinite(planMaxStudents as number) ? (planMaxStudents as number) : 0;
  const monthlyCredits = Number.isFinite(planMonthlyCredits as number) ? (planMonthlyCredits as number) : 0;
  const available = Number.isFinite(creditsAvailable as number) ? (creditsAvailable as number) : 0;

  const studentsPct = useMemo(() => {
    if (!maxStudents || maxStudents <= 0) return 0;
    return (students.length / maxStudents) * 100;
  }, [students.length, maxStudents]);

  // ✅ créditos usados = (teto mensal - disponíveis), clamp para não dar negativo
  const creditsUsed = useMemo(() => {
    if (!monthlyCredits || monthlyCredits <= 0) return 0;
    return Math.max(0, monthlyCredits - available);
  }, [monthlyCredits, available]);

  const creditsPct = useMemo(() => {
    if (!monthlyCredits || monthlyCredits <= 0) return 0;
    return (creditsUsed / monthlyCredits) * 100;
  }, [creditsUsed, monthlyCredits]);

  const typeBars = useMemo(() => {
    const entries = Object.entries(kpis.byType)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6);
    const max = Math.max(1, ...entries.map(([, v]) => v));
    return entries.map(([name, value]) => ({ name, value, pct: (value / max) * 100 }));
  }, [kpis.byType]);

  const resetBR = fmtDateBR(creditsResetAt);
  const greet = greetingByHour();
  const safeName = (userName ?? '').trim() || 'Professora';

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-[fadeUp_.45s_ease-out]">
        <h1 className="text-2xl font-bold text-gray-900">
          {greet}, {safeName}! ☀️
        </h1>
        <p className="text-gray-600 mt-1">
          Um painel rápido com o que importa hoje — alunos, documentos e créditos.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MeterCard
          title="Limite de alunos"
          subtitle={maxStudents > 0 ? `${students.length} / ${maxStudents} alunos ativos` : `${students.length} alunos ativos`}
          valuePct={studentsPct}
          mode={modeStudents}
          onToggle={() => setModeStudents(m => (m === 'gauge' ? 'bar' : 'gauge'))}
        />

        <MeterCard
          title="Créditos IA"
          subtitle={
            monthlyCredits > 0
              ? `${available} disponíveis • Plano: ${monthlyCredits}/mês`
              : `${available} disponíveis`
          }
          valuePct={creditsPct}
          mode={modeCredits}
          onToggle={() => setModeCredits(m => (m === 'gauge' ? 'bar' : 'gauge'))}
          footer={
            resetBR ? (
              <span>
                Renova em: <span className="font-semibold text-gray-700">{resetBR}</span>
              </span>
            ) : null
          }
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-[fadeUp_.45s_ease-out]">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center">
              <FileText className="w-5 h-5 text-emerald-600" />
            </div>
            <div className="text-xs px-2 py-1 rounded-full bg-emerald-50 text-emerald-700 font-medium">FINAL</div>
          </div>
          <div className="text-3xl font-bold mt-4">{kpis.finals}</div>
          <div className="text-sm text-gray-600 mt-1">Documentos finalizados</div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-[fadeUp_.45s_ease-out]">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center">
              <Users className="w-5 h-5 text-orange-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mt-4">{students.length}</div>
          <div className="text-sm text-gray-600 mt-1">Alunos cadastrados</div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-[fadeUp_.45s_ease-out]">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mt-4">{kpis.pending}</div>
          <div className="text-sm text-gray-600 mt-1">Pendências (rascunhos)</div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-[fadeUp_.45s_ease-out]">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center">
              <Zap className="w-5 h-5 text-purple-600" />
            </div>
          </div>
          <div className="text-3xl font-bold mt-4">{kpis.total}</div>
          <div className="text-sm text-gray-600 mt-1">Documentos gerados</div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-[fadeUp_.45s_ease-out]">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold text-gray-800">Distribuição por tipo de documento</div>
            <div className="text-xs text-gray-500 mt-1">Top 6 tipos (barra animada)</div>
          </div>
        </div>

        <div className="mt-5 space-y-3">
          {typeBars.length === 0 && (
            <div className="text-sm text-gray-500">Ainda não há documentos para analisar.</div>
          )}
          {typeBars.map((b) => (
            <div key={b.name} className="flex items-center gap-3">
              <div className="w-44 text-xs text-gray-600 truncate">{b.name}</div>
              <div className="flex-1">
                <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-500 transition-all duration-700 ease-out"
                    style={{ width: `${b.pct}%` }}
                  />
                </div>
              </div>
              <div className="w-10 text-xs text-gray-700 text-right">{b.value}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}