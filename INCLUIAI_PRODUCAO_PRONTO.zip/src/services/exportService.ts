// exportService.ts — PDF REAL com jsPDF (sem window.print)
import { Student, StudentEvolution, DocField } from "../types";
import QRCode from 'qrcode';

// ─── Carrega jsPDF dinamicamente (CDN) ────────────────────────────────────────
async function loadJsPDF(): Promise<any> {
  if ((window as any).jspdf?.jsPDF) return (window as any).jspdf.jsPDF;

  await new Promise<void>((resolve, reject) => {
    const script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Falha ao carregar jsPDF"));
    document.head.appendChild(script);
  });

  return (window as any).jspdf.jsPDF;
}

// ─── Constantes visuais ────────────────────────────────────────────────────────
const BRAND = { r: 88, g: 28, b: 235 };
const BRAND_LIGHT = { r: 237, g: 233, b: 254 };
const DARK = { r: 17, g: 24, b: 39 };
const GRAY = { r: 107, g: 114, b: 128 };


async function buildQrDataUrl(auditCode: string): Promise<string | undefined> {
  try {
    const origin = (typeof window !== 'undefined' && window.location?.origin) ? window.location.origin : 'https://incluiai.com';
    const url = `${origin}/validar/${auditCode}`;
    return await QRCode.toDataURL(url, { margin: 0, width: 256 });
  } catch (e) {
    console.warn('QR Code generation failed', e);
    return undefined;
  }
}

function makeAuditCode(prefix: string, id: string): string {
  let hash = 0;
  const str = id + Date.now().toString();
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return `${prefix}-${Math.abs(hash).toString(16).toUpperCase().padStart(8, "0").slice(0, 8)}`;
}

function addWrappedText(doc: any, text: string, x: number, y: number, maxWidth: number, lineHeight: number): number {
  const lines = doc.splitTextToSize(text || "—", maxWidth);
  doc.text(lines, x, y);
  return y + lines.length * lineHeight;
}

function addDocHeader(doc: any, title: string, subtitle: string, studentName: string, auditCode: string) {
  const W = doc.internal.pageSize.getWidth();
  doc.setFillColor(BRAND.r, BRAND.g, BRAND.b);
  doc.rect(0, 0, W, 22, "F");

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(255, 255, 255);
  doc.text("IncluiAI", 14, 14);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text("Plataforma Educacional Inclusiva", 36, 14);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(title, W - 14, 10, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(subtitle, W - 14, 16, { align: "right" });

  doc.setFillColor(248, 250, 252);
  doc.rect(0, 22, W, 14, "F");
  doc.setTextColor(DARK.r, DARK.g, DARK.b);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text(studentName, 14, 31);

  doc.setFont("courier", "normal");
  doc.setFontSize(7);
  doc.setTextColor(GRAY.r, GRAY.g, GRAY.b);
  doc.text(`Código: ${auditCode}`, W - 14, 31, { align: "right" });

  doc.setDrawColor(BRAND.r, BRAND.g, BRAND.b);
  doc.setLineWidth(0.4);
  doc.line(0, 36, W, 36);
}

function addDocFooter(doc: any, auditCode: string, emittedBy: string, qrDataUrl?: string) {
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();

  doc.setFillColor(248, 250, 252);
  doc.rect(0, H - 18, W, 18, "F");

  doc.setDrawColor(BRAND.r, BRAND.g, BRAND.b);
  doc.setLineWidth(0.3);
  doc.line(0, H - 18, W, H - 18);

  const dateStr = new Date().toLocaleDateString("pt-BR", {
    day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit",
  } as any);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(6.5);
  doc.setTextColor(GRAY.r, GRAY.g, GRAY.b);
  doc.text(`Gerado em ${dateStr} por ${emittedBy}`, 14, H - 10);

  doc.setFont("courier", "bold");
  doc.setFontSize(7);
  doc.text(`Código Auditável: ${auditCode}`, W / 2, H - 10, { align: "center" });

  doc.setFont("helvetica", "normal");
  doc.setFontSize(6.5);
  doc.text("incluiai.com/validar/" + auditCode, W - 14, H - 10, { align: "right" });

  doc.text(
    `Página ${doc.internal.getCurrentPageInfo().pageNumber} de ${doc.internal.getNumberOfPages()}`,
    W / 2, H - 4, { align: "center" }
  );
}

function addFooterAllPages(doc: any, auditCode: string, emittedBy: string, qrDataUrl?: string) {
  const pages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    addDocFooter(doc, auditCode, emittedBy, qrDataUrl);
  }
}

function renderField(doc: any, label: string, value: string, x: number, y: number, maxW: number, lineH = 4.5): number {
  const H = doc.internal.pageSize.getHeight();
  if (y > H - 30) { doc.addPage(); y = 44; }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(7.5);
  doc.setTextColor(BRAND.r, BRAND.g, BRAND.b);
  if (label) { doc.text(label.toUpperCase(), x, y); y += 4; }

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(DARK.r, DARK.g, DARK.b);
  y = addWrappedText(doc, value || "—", x, y, maxW, lineH);
  return y + 3;
}

// ─── CANVAS HELPERS ────────────────────────────────────────────────────────────
async function generateRadarCanvas(scores: number[], criteria: { name: string }[]): Promise<string> {
  const size = 480;
  const canvas = document.createElement("canvas");
  canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, size, size);

  const cx = size / 2, cy = size / 2, r = 180;
  const n = criteria.length;
  const step = (Math.PI * 2) / n;

  ctx.strokeStyle = "#e5e7eb"; ctx.lineWidth = 1;
  [0.2, 0.4, 0.6, 0.8, 1].forEach(scale => {
    ctx.beginPath(); ctx.arc(cx, cy, r * scale, 0, Math.PI * 2); ctx.stroke();
  });

  criteria.forEach((_, i) => {
    const angle = i * step - Math.PI / 2;
    ctx.beginPath(); ctx.moveTo(cx, cy);
    ctx.lineTo(cx + r * Math.cos(angle), cy + r * Math.sin(angle));
    ctx.strokeStyle = "#e5e7eb"; ctx.lineWidth = 1; ctx.stroke();

    const lx = cx + (r + 24) * Math.cos(angle);
    const ly = cy + (r + 24) * Math.sin(angle);
    ctx.font = "bold 11px Arial"; ctx.fillStyle = "#374151";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(criteria[i].name.split(" ")[0], lx, ly);
  });

  ctx.beginPath();
  scores.forEach((val, i) => {
    const angle = i * step - Math.PI / 2;
    const rv = (val / 5) * r;
    const px = cx + rv * Math.cos(angle), py = cy + rv * Math.sin(angle);
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  });
  ctx.closePath();
  ctx.fillStyle = "rgba(88, 28, 235, 0.18)"; ctx.fill();
  ctx.strokeStyle = "rgba(88, 28, 235, 0.85)"; ctx.lineWidth = 2.5; ctx.stroke();

  scores.forEach((val, i) => {
    const angle = i * step - Math.PI / 2;
    const rv = (val / 5) * r;
    ctx.beginPath(); ctx.arc(cx + rv * Math.cos(angle), cy + rv * Math.sin(angle), 5, 0, Math.PI * 2);
    ctx.fillStyle = "rgb(88, 28, 235)"; ctx.fill();
  });

  return canvas.toDataURL("image/png");
}

async function generateBarCanvas(scores: number[], criteria: { name: string }[]): Promise<string> {
  const W = 900, H = 340;
  const canvas = document.createElement("canvas");
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#f9fafb"; ctx.fillRect(0, 0, W, H);
  const pad = { l: 40, r: 20, t: 20, b: 60 };
  const chartW = W - pad.l - pad.r, chartH = H - pad.t - pad.b;
  const barW = chartW / scores.length - 8;

  [1, 2, 3, 4, 5].forEach(v => {
    const gy = pad.t + chartH - (v / 5) * chartH;
    ctx.beginPath(); ctx.moveTo(pad.l, gy); ctx.lineTo(W - pad.r, gy);
    ctx.strokeStyle = "#e5e7eb"; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = "11px Arial"; ctx.fillStyle = "#9ca3af"; ctx.textAlign = "right";
    ctx.fillText(String(v), pad.l - 4, gy + 4);
  });

  scores.forEach((val, i) => {
    const x = pad.l + i * (chartW / scores.length) + 4;
    const barH = (val / 5) * chartH;
    const y = pad.t + chartH - barH;

    const grad = ctx.createLinearGradient(x, y, x, pad.t + chartH);
    grad.addColorStop(0, "rgba(88, 28, 235, 0.9)");
    grad.addColorStop(1, "rgba(167, 139, 250, 0.7)");
    ctx.fillStyle = grad;
    (ctx as any).roundRect ? (ctx as any).roundRect(x, y, barW, barH, [4, 4, 0, 0]) : ctx.rect(x, y, barW, barH);
    ctx.fill();

    ctx.font = "bold 13px Arial"; ctx.fillStyle = "#1f2937"; ctx.textAlign = "center";
    ctx.fillText(String(val), x + barW / 2, y - 6);

    const label = criteria[i].name.split(" ").slice(0, 2).join(" ");
    ctx.font = "10px Arial"; ctx.fillStyle = "#6b7280";
    ctx.fillText(label, x + barW / 2, pad.t + chartH + 18);
  });

  return canvas.toDataURL("image/png");
}

async function generateLineCanvas(evolutions: StudentEvolution[], criteria: { name: string }[]): Promise<string> {
  if (evolutions.length < 2) return "";
  const W = 900, H = 300;
  const canvas = document.createElement("canvas");
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#f9fafb"; ctx.fillRect(0, 0, W, H);
  const pad = { l: 40, r: 20, t: 20, b: 50 };
  const chartW = W - pad.l - pad.r, chartH = H - pad.t - pad.b;

  const sorted = [...evolutions].sort((a, b) =>
    new Date((a as any).date || (a as any).createdAt || "").getTime() -
    new Date((b as any).date || (b as any).createdAt || "").getTime()
  );

  const colors = ["#5b21b6","#7c3aed","#a78bfa","#c4b5fd","#2563eb"];

  [1,2,3,4,5].forEach(v => {
    const gy = pad.t + chartH - ((v - 1) / 4) * chartH;
    ctx.beginPath(); ctx.moveTo(pad.l, gy); ctx.lineTo(W - pad.r, gy);
    ctx.strokeStyle = "#e5e7eb"; ctx.lineWidth = 1; ctx.stroke();
    ctx.font = "11px Arial"; ctx.fillStyle = "#9ca3af"; ctx.textAlign = "right";
    ctx.fillText(String(v), pad.l - 4, gy + 4);
  });

  sorted.forEach((ev, i) => {
    const x = pad.l + (i / (sorted.length - 1)) * chartW;
    const d = new Date((ev as any).date || (ev as any).createdAt || "");
    const label = isNaN(d.getTime()) ? `#${i + 1}` : d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
    ctx.font = "9px Arial"; ctx.fillStyle = "#6b7280"; ctx.textAlign = "center";
    ctx.fillText(label, x, pad.t + chartH + 15);
  });

  criteria.slice(0, 5).forEach((c, ci) => {
    ctx.beginPath(); ctx.strokeStyle = colors[ci]; ctx.lineWidth = 2;
    sorted.forEach((ev, i) => {
      const val = ev.scores?.[ci] ?? 1;
      const x = pad.l + (i / Math.max(1, sorted.length - 1)) * chartW;
      const y = pad.t + chartH - ((val - 1) / 4) * chartH;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();

    const lx = pad.l + ci * (chartW / 5);
    ctx.fillStyle = colors[ci]; ctx.fillRect(lx, pad.t + chartH + 28, 12, 8);
    ctx.font = "9px Arial"; ctx.fillStyle = "#374151"; ctx.textAlign = "left";
    ctx.fillText(c.name.split(" ")[0], lx + 14, pad.t + chartH + 36);
  });

  return canvas.toDataURL("image/png");
}

// ─── EXPORT SERVICE ────────────────────────────────────────────────────────────
export const ExportService = {
  async generateStudentProfilePDF(student: Student, emittedBy = "Sistema") {
    const jsPDF = await loadJsPDF();
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const W = doc.internal.pageSize.getWidth();
    const M = 14;
    const maxW = W - M * 2;
    const auditCode = makeAuditCode("FICHA", student.id);
    const halfW = maxW / 2 - 3;
    const col1x = M, col2x = M + halfW + 6;

    addDocHeader(doc, "FICHA DO ALUNO", "Documentação Educacional Inclusiva", student.name, auditCode);
    let y = 44;

    // Avatar + info básica
    doc.setFillColor(BRAND_LIGHT.r, BRAND_LIGHT.g, BRAND_LIGHT.b);
    doc.roundedRect(M, y, maxW, 38, 3, 3, "F");

    doc.setFillColor(BRAND.r, BRAND.g, BRAND.b);
    doc.circle(M + 18, y + 19, 14, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(16);
    doc.setTextColor(255, 255, 255);
    const initials = student.name.split(" ").map((n: string) => n[0]).slice(0, 2).join("").toUpperCase();
    doc.text(initials, M + 18, y + 22, { align: "center" });

    doc.setTextColor(DARK.r, DARK.g, DARK.b);
    doc.setFont("helvetica", "bold"); doc.setFontSize(13);
    doc.text(student.name, M + 36, y + 10);

    doc.setFont("helvetica", "normal"); doc.setFontSize(8.5);
    doc.setTextColor(GRAY.r, GRAY.g, GRAY.b);
    const age = student.birthDate
      ? Math.floor((Date.now() - new Date(student.birthDate).getTime()) / (365.25 * 24 * 60 * 60 * 1000))
      : "—";

    const col1Info = [
      `Nascimento: ${student.birthDate ? new Date(student.birthDate + "T00:00:00").toLocaleDateString("pt-BR") : "—"}`,
      `Idade: ${age} anos | Gênero: ${student.gender || "—"}`,
      `Série: ${student.grade || "—"} | Turno: ${student.shift || "—"}`,
    ];
    const col2Info = [
      `Nível de Suporte: ${student.supportLevel || "—"}`,
      `CID: ${Array.isArray(student.cid) ? student.cid.join(", ") : student.cid || "—"}`,
      `Medicação: ${student.medication || "—"}`,
    ];

    col1Info.forEach((line, i) => doc.text(line, M + 36, y + 18 + i * 5.5));
    col2Info.forEach((line, i) => doc.text(line, M + 36 + maxW / 2 - 20, y + 18 + i * 5.5));
    y += 44;

    // Diagnósticos
    const diagText = (student.diagnosis || []).join(", ");
    if (diagText) {
      y = renderField(doc, "Diagnósticos", diagText, M, y, maxW);
    }

    // Seção responsável
    doc.setFillColor(BRAND.r, BRAND.g, BRAND.b); doc.rect(M, y, maxW, 6, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(8); doc.setTextColor(255, 255, 255);
    doc.text("RESPONSÁVEL / EQUIPE PEDAGÓGICA", M + 2, y + 4.2); y += 9;

    let yL = y, yR = y;
    yL = renderField(doc, "Responsável", student.guardianName, col1x, yL, halfW);
    yL = renderField(doc, "Telefone", student.guardianPhone, col1x, yL, halfW);
    yL = renderField(doc, "E-mail", student.guardianEmail || "—", col1x, yL, halfW);
    yR = renderField(doc, "Professor Regente", student.regentTeacher, col2x, yR, halfW);
    yR = renderField(doc, "Professor AEE", student.aeeTeacher || "—", col2x, yR, halfW);
    yR = renderField(doc, "Coordenador", student.coordinator || "—", col2x, yR, halfW);
    yR = renderField(doc, "Profissionais Externos", (student.professionals || []).join(", "), col2x, yR, halfW);
    y = Math.max(yL, yR) + 2;

    // Contexto
    doc.setFillColor(BRAND.r, BRAND.g, BRAND.b); doc.rect(M, y, maxW, 6, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(8); doc.setTextColor(255, 255, 255);
    doc.text("CONTEXTO ESCOLAR E FAMILIAR", M + 2, y + 4.2); y += 9;

    y = renderField(doc, "Histórico Escolar", student.schoolHistory, M, y, maxW);
    y = renderField(doc, "Contexto Familiar", student.familyContext, M, y, maxW);

    // Perfil funcional
    doc.setFillColor(BRAND.r, BRAND.g, BRAND.b); doc.rect(M, y, maxW, 6, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(8); doc.setTextColor(255, 255, 255);
    doc.text("PERFIL FUNCIONAL", M + 2, y + 4.2); y += 9;

    yL = y; yR = y;
    yL = renderField(doc, "Habilidades", (student.abilities || []).map(a => `• ${a}`).join("\n"), col1x, yL, halfW);
    yL = renderField(doc, "Estratégias Eficazes", (student.strategies || []).map(s => `• ${s}`).join("\n"), col1x, yL, halfW);
    yR = renderField(doc, "Dificuldades", (student.difficulties || []).map(d => `• ${d}`).join("\n"), col2x, yR, halfW);
    yR = renderField(doc, "Comunicação", (student.communication || []).join(", "), col2x, yR, halfW);
    y = Math.max(yL, yR) + 2;

    if (student.observations) {
      doc.setFillColor(BRAND.r, BRAND.g, BRAND.b); doc.rect(M, y, maxW, 6, "F");
      doc.setFont("helvetica", "bold"); doc.setFontSize(8); doc.setTextColor(255, 255, 255);
      doc.text("OBSERVAÇÕES GERAIS", M + 2, y + 4.2); y += 9;
      y = renderField(doc, "", student.observations, M, y, maxW);
    }

    // Assinaturas
    const H = doc.internal.pageSize.getHeight();
    if (y > H - 50) { doc.addPage(); addDocHeader(doc, "FICHA DO ALUNO", "", student.name, auditCode); y = 44; }
    y += 8;
    doc.setFont("helvetica", "bold"); doc.setFontSize(8); doc.setTextColor(DARK.r, DARK.g, DARK.b);
    doc.text("ASSINATURAS", M, y); y += 6;

    const sigFields = ["Professor Regente", "Professor AEE", "Coordenação", "Responsável"];
    sigFields.forEach((sig, i) => {
      const sx = M + i * (maxW / 4);
      doc.setDrawColor(GRAY.r, GRAY.g, GRAY.b); doc.setLineWidth(0.3);
      doc.line(sx, y + 14, sx + maxW / 4 - 4, y + 14);
      doc.setFont("helvetica", "normal"); doc.setFontSize(7); doc.setTextColor(GRAY.r, GRAY.g, GRAY.b);
      doc.text(sig, sx + (maxW / 4 - 4) / 2, y + 18, { align: "center" });
    });

    const qrDataUrl = await buildQrDataUrl(auditCode);
    addFooterAllPages(doc, auditCode, emittedBy, qrDataUrl);
    doc.save(`Ficha_${student.name.replace(/\s+/g, "_")}.pdf`);
  },

  async exportEvolutionReportPDF(params: {
    student: Student;
    scores: number[];
    observation: string;
    criteria: { name: string; desc: string }[];
    customFields?: DocField[];
    auditCode?: string;
    createdBy?: string;
    createdAt?: string;
    allEvolutions?: StudentEvolution[];
  }) {
    const { student, scores, observation, criteria, customFields = [], auditCode: existingCode, createdBy = "Sistema", createdAt, allEvolutions = [] } = params;

    const jsPDF = await loadJsPDF();
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const W = doc.internal.pageSize.getWidth();
    const M = 14;
    const maxW = W - M * 2;
    const auditCode = existingCode || makeAuditCode("EVO", student.id + Date.now());

    addDocHeader(doc, "RELATÓRIO EVOLUTIVO", "Acompanhamento de Desenvolvimento", student.name, auditCode);
    let y = 44;

    // Data / autor
    doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(GRAY.r, GRAY.g, GRAY.b);
    const emitDate = createdAt ? new Date(createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" } as any)
      : new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" } as any);
    doc.text(`Emissão: ${emitDate}  |  Profissional: ${createdBy}`, M, y);
    y += 8;

    // ── GRÁFICO RADAR ────────────────────────────────────────────────────
    try {
      const radarB64 = await generateRadarCanvas(scores, criteria);
      const imgSize = 74;
      doc.addImage(radarB64, "PNG", M, y, imgSize, imgSize);

      // legenda lateral
      let ly = y + 4;
      doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(DARK.r, DARK.g, DARK.b);
      doc.text("Mapa de Evolução (Radar)", M + imgSize + 6, ly); ly += 7;

      criteria.forEach((c, i) => {
        const pct = Math.round((scores[i] / 5) * 100);
        // barra mini
        doc.setFillColor(230, 230, 250); doc.rect(M + imgSize + 6, ly - 3, 50, 4, "F");
        doc.setFillColor(BRAND.r, BRAND.g, BRAND.b); doc.rect(M + imgSize + 6, ly - 3, 50 * (scores[i] / 5), 4, "F");

        doc.setFont("helvetica", "normal"); doc.setFontSize(6.5); doc.setTextColor(DARK.r, DARK.g, DARK.b);
        doc.text(`${c.name}`, M + imgSize + 6, ly + 4);
        doc.setFont("helvetica", "bold");
        doc.text(`${scores[i]}/5 (${pct}%)`, M + imgSize + 6 + 52, ly + 4);
        ly += 7.5;
      });
      y += imgSize + 6;
    } catch (_) {
      criteria.forEach((c, i) => {
        doc.setFont("helvetica", "normal"); doc.setFontSize(8.5); doc.setTextColor(DARK.r, DARK.g, DARK.b);
        doc.text(`${c.name}: ${scores[i]}/5`, M, y); y += 5;
      });
      y += 4;
    }

    // ── GRÁFICO DE BARRAS (nova página) ────────────────────────────────
    try {
      const barB64 = await generateBarCanvas(scores, criteria);
      doc.addPage();
      addDocHeader(doc, "RELATÓRIO EVOLUTIVO", "Gráfico de Desempenho", student.name, auditCode);
      let y2 = 44;
      doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(DARK.r, DARK.g, DARK.b);
      doc.text("Desempenho por Critério (Barras)", M, y2); y2 += 5;
      doc.addImage(barB64, "PNG", M, y2, maxW, 62); y2 += 68;

      // Linha do tempo
      if (allEvolutions.length > 1) {
        try {
          const lineB64 = await generateLineCanvas(allEvolutions, criteria);
          if (lineB64) {
            doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(DARK.r, DARK.g, DARK.b);
            doc.text("Evolução Histórica (Critérios 1–5)", M, y2 + 4); y2 += 10;
            doc.addImage(lineB64, "PNG", M, y2, maxW, 58);
          }
        } catch (_) {}
      }
    } catch (_) {}

    // ── PARECER DESCRITIVO ─────────────────────────────────────────────────
    const Hpage = doc.internal.pageSize.getHeight();
    if (y > Hpage - 60) { doc.addPage(); addDocHeader(doc, "RELATÓRIO EVOLUTIVO", "Parecer", student.name, auditCode); y = 44; }

    doc.setFillColor(BRAND.r, BRAND.g, BRAND.b); doc.rect(M, y, maxW, 6, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(8); doc.setTextColor(255, 255, 255);
    doc.text("PARECER DESCRITIVO", M + 2, y + 4.2); y += 9;
    doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(DARK.r, DARK.g, DARK.b);
    y = addWrappedText(doc, observation || "—", M, y, maxW, 5); y += 4;

    // Campos personalizados
    customFields.forEach(field => {
      const Hp = doc.internal.pageSize.getHeight();
      if (y > Hp - 30) { doc.addPage(); addDocHeader(doc, "RELATÓRIO EVOLUTIVO", "", student.name, auditCode); y = 44; }
      doc.setFillColor(245, 243, 255); doc.roundedRect(M, y, maxW, 6, 2, 2, "F");
      doc.setFont("helvetica", "bold"); doc.setFontSize(7.5); doc.setTextColor(BRAND.r, BRAND.g, BRAND.b);
      doc.text(field.label.toUpperCase(), M + 3, y + 4.3); y += 8;

      if (field.type === "scale") {
        doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(DARK.r, DARK.g, DARK.b);
        doc.text(`Pontuação: ${field.value} / ${field.maxScale || 5}`, M, y); y += 7;
      } else {
        doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(DARK.r, DARK.g, DARK.b);
        y = addWrappedText(doc, String(field.value || "—"), M, y, maxW, 5); y += 3;
      }
    });

    const qrDataUrl = await buildQrDataUrl(auditCode);
    addFooterAllPages(doc, auditCode, createdBy, qrDataUrl);
    doc.save(`Relatorio_Evolutivo_${student.name.replace(/\s+/g, "_")}.pdf`);
  },

  // Compatibilidade com printToPDF (para protocolos estruturados)
  async printToPDF(elementId: string, title: string) {
    const el = document.getElementById(elementId);
    if (!el) { window.print(); return; }

    const clone = el.cloneNode(true) as HTMLElement;
    clone.querySelectorAll("[data-no-print]").forEach(n => n.remove());

    const overlay = document.createElement("div");
    overlay.style.cssText = "position:fixed;inset:0;z-index:999999;background:white;overflow:auto;";

    const style = document.createElement("style");
    style.textContent = `
      @page { size: A4; margin: 20mm; }
      html, body { -webkit-print-color-adjust: exact; print-color-adjust: exact; background: #fff; }
      * { box-sizing: border-box; }
      body { margin: 0; font-family: Arial, sans-serif; color: #111; }
      .print-page { width: 170mm; margin: 0 auto; }
      h1,h2,h3 { break-after: avoid; }
      @media print { body > *:not(#__print_overlay__) { display: none !important; } }
    `;

    const page = document.createElement("div");
    page.className = "print-page";
    page.appendChild(clone);
    overlay.appendChild(page);

    document.head.appendChild(style);
    document.body.appendChild(overlay);

    const originalTitle = document.title;
    document.title = title;
    await new Promise(r => setTimeout(r, 120));
    window.print();

    setTimeout(() => {
      document.title = originalTitle;
      overlay.remove();
      style.remove();
    }, 500);
  },
};
