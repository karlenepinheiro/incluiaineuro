// IncluiLabView.tsx — Laboratório de Atividades Inclusivas
import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  FlaskConical, Zap, Upload, Wand2, FileText, CheckCircle,
  Download, Save, ChevronRight, Brain,
  Camera, Printer, Edit3, Layers,
  BookOpen, Target, List, Lightbulb, Hash, Loader,
  ArrowLeft, Sparkles, Settings, Play, RefreshCw,
  Image as ImageIcon, X, AlertCircle, Coins,
  MessageSquare, SlidersHorizontal, Star
} from 'lucide-react';
import { User, Student } from '../types';
import { AIService } from '../services/aiService';
import { databaseService } from '../services/databaseService';

// ─── Tipos ────────────────────────────────────────────────────────────────────
interface GeneratedActivity {
  title: string;
  objective: string;
  enunciado: string;
  questions: string[];
  visualSuggestions: string[];
  bnccCodes: string[];
}

interface AdaptedActivity {
  original: string;
  adapted: string;
  adaptationType: string;
}

interface RedesignedActivity {
  original: string;
  redesigned: string;
  suggestions: string[];
}

interface ResultImage {
  id: string;
  imageUrl: string;
  description: string;
  prompt: string;
}

type Tab        = 'workflow' | 'scanner' | 'redesign';
type AIModel    = 'gemini' | 'openai';
type AspectRatio = '1:1' | '16:9' | '9:16' | '3:4' | '4:5';
type StepStatus = 'idle' | 'ready' | 'running' | 'done' | 'error';

const ADAPTATION_TYPES = [
  { id: 'autismo', label: 'Autismo (TEA)' },
  { id: 'tdah', label: 'TDAH' },
  { id: 'dislexia', label: 'Dislexia' },
  { id: 'di', label: 'Deficiência Intelectual' },
  { id: 'geral', label: 'Simplificação Geral' },
];

const DISCIPLINES = [
  'Língua Portuguesa', 'Matemática', 'Ciências', 'História', 'Geografia',
  'Arte', 'Educação Física', 'Inglês', 'Educação Especial',
];

const YEARS = [
  '1º Ano EF', '2º Ano EF', '3º Ano EF', '4º Ano EF', '5º Ano EF',
  '6º Ano EF', '7º Ano EF', '8º Ano EF', '9º Ano EF',
  '1º Ano EM', '2º Ano EM', '3º Ano EM',
];

const PROMPT_SUGGESTIONS = [
  'Crie uma versão visual desta atividade com apoio de imagens educativas.',
  'Transforme esta atividade em uma versão visual para alunos com autismo.',
  'Crie ilustrações simples que ajudem a explicar o exercício.',
  'Transforme esta atividade em cartões visuais.',
  'Crie 5 imagens educativas que representem cada pergunta.',
];

const ASPECT_RATIOS: { id: AspectRatio; label: string }[] = [
  { id: '1:1', label: '1:1' },
  { id: '16:9', label: '16:9' },
  { id: '9:16', label: '9:16' },
  { id: '3:4', label: '3:4' },
  { id: '4:5', label: '4:5' },
];

// ─── Cálculo de créditos ──────────────────────────────────────────────────────
function calcCredits(model: AIModel, imageCount: number, isText = false) {
  if (isText) return model === 'openai' ? 2 : 1;
  const perImage = model === 'openai' ? 3 : 2;
  return perImage * imageCount;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function exportAsText(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function formatActivityText(a: GeneratedActivity): string {
  return `ATIVIDADE: ${a.title}
BNCC: ${(a.bnccCodes ?? []).join(', ')}

OBJETIVO PEDAGÓGICO:
${a.objective}

ENUNCIADO:
${a.enunciado}

PERGUNTAS:
${(a.questions ?? []).map((q, i) => `${i + 1}. ${q}`).join('\n')}

SUGESTÕES VISUAIS:
${(a.visualSuggestions ?? []).join('\n')}
`;
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

// ─── Seletor de Modelo ────────────────────────────────────────────────────────
const ModelSelector: React.FC<{
  model: AIModel;
  onChange: (m: AIModel) => void;
  credits: number;
  compact?: boolean;
}> = ({ model, onChange, credits, compact }) => (
  <div className={`flex items-center gap-2 ${compact ? '' : 'bg-white border border-gray-100 rounded-xl px-3 py-2 shadow-sm'}`}>
    {!compact && <Coins size={14} className="text-brand-500 shrink-0" />}
    <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-0.5">
      {(['gemini', 'openai'] as AIModel[]).map(m => (
        <button key={m} onClick={() => onChange(m)}
          className={`px-3 py-1.5 rounded-md text-xs font-bold transition ${model === m ? 'bg-white shadow text-gray-900' : 'text-gray-400 hover:text-gray-700'}`}>
          {m === 'gemini' ? 'Gemini' : 'ChatGPT'}
        </button>
      ))}
    </div>
    <div className="flex items-center gap-1 text-xs font-bold text-brand-600">
      <Coins size={12} /> {credits} crédito{credits !== 1 ? 's' : ''}
    </div>
  </div>
);

// ─── Componente principal ─────────────────────────────────────────────────────
interface IncluiLabViewProps {
  user: User;
  students: Student[];
  defaultTab?: Tab;
}

export const IncluiLabView: React.FC<IncluiLabViewProps> = ({ user, students, defaultTab }) => {
  const [activeTab, setActiveTab] = useState<Tab | null>(defaultTab ?? null);

  useEffect(() => {
    if (defaultTab) setActiveTab(defaultTab);
  }, [defaultTab]);

  const modules = [
    { id: 'workflow' as Tab, icon: Zap,      label: 'AtivaIA',    subtitle: 'Canvas de Atividades', desc: 'Crie fluxos visuais de geração de atividades — envie imagem, escreva o prompt e a IA gera imagens pedagógicas.', iconBg: 'bg-brand-600' },
    { id: 'scanner'  as Tab, icon: Upload,   label: 'EduLensIA',  subtitle: 'Scanner Pedagógico',   desc: 'Envie foto ou PDF de qualquer atividade e adapte instantaneamente para TEA, TDAH, Dislexia ou DI.', iconBg: 'bg-orange-500' },
    { id: 'redesign' as Tab, icon: Sparkles, label: 'NeuroDesign', subtitle: 'Redesenho Inclusivo', desc: 'Cole qualquer texto e transforme com layout pedagógico acessível, pictogramas e organização visual.',  iconBg: 'bg-amber-500'  },
  ];

  // ── HUB ──
  if (!activeTab) {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{ background: 'linear-gradient(160deg,#fff7ed 0%,#ffffff 50%,#ffedd5 100%)' }}>
        <style>{`
          @keyframes lab-fade-up { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
          .lab-card { animation: lab-fade-up .5s ease both; }
          .lab-card:nth-child(1){animation-delay:.05s}
          .lab-card:nth-child(2){animation-delay:.15s}
          .lab-card:nth-child(3){animation-delay:.25s}
          .lab-card:hover{transform:translateY(-4px);box-shadow:0 12px 40px rgba(234,88,12,0.14)}
        `}</style>
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12" style={{ animation: 'lab-fade-up .4s ease both' }}>
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-brand-600 shadow-xl shadow-orange-200 mb-5">
              <FlaskConical className="text-white" size={30} />
            </div>
            <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight mb-2">IncluiLAB</h1>
            <p className="text-base text-gray-500 max-w-md mx-auto">Laboratório de Atividades Inclusivas com Inteligência Artificial</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {modules.map(m => {
              const Icon = m.icon;
              return (
                <button key={m.id} onClick={() => setActiveTab(m.id)}
                  className="lab-card text-left rounded-3xl border border-orange-100 p-7 transition-all duration-300 cursor-pointer group"
                  style={{ background: 'rgba(255,255,255,.75)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', boxShadow: '0 4px 24px rgba(234,88,12,.07)' }}>
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-2xl ${m.iconBg} mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="text-white" size={22} />
                  </div>
                  <div className="mb-1 text-[10px] font-bold text-brand-500 uppercase tracking-widest">{m.subtitle}</div>
                  <h2 className="text-xl font-extrabold text-gray-900 mb-3">{m.label}</h2>
                  <p className="text-sm text-gray-500 leading-relaxed mb-5">{m.desc}</p>
                  <div className="flex items-center gap-1.5 text-brand-600 text-xs font-bold group-hover:gap-3 transition-all duration-300">
                    Acessar <ChevronRight size={14} />
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-10 text-center">
            <span className="inline-flex items-center gap-2 text-xs text-gray-400 bg-white/60 backdrop-blur px-4 py-2 rounded-full border border-orange-100">
              <Brain size={12} className="text-brand-500" /> Gemini + OpenAI — Fallback automático
            </span>
          </div>
        </div>
      </div>
    );
  }

  // ── Sub-page ──
  const current = modules.find(m => m.id === activeTab)!;
  const CurrentIcon = current.icon;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sub-page header */}
      <div className="bg-white border-b border-gray-100 px-4 md:px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center gap-3">
          {!defaultTab && (
            <button onClick={() => setActiveTab(null)}
              className="flex items-center gap-1.5 text-sm font-semibold text-gray-500 hover:text-brand-600 transition px-3 py-2 rounded-xl hover:bg-orange-50">
              <ArrowLeft size={16} /> IncluiLAB
            </button>
          )}
          <div className={`${current.iconBg} p-2.5 rounded-2xl shadow-md shrink-0`}>
            <CurrentIcon className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-gray-900 leading-tight">{current.label}</h1>
            <p className="text-xs text-brand-500 font-semibold">{current.subtitle}</p>
          </div>
          {!defaultTab && (
            <div className="ml-auto hidden sm:flex items-center gap-1 bg-gray-100 rounded-xl p-1">
              {modules.map(m => {
                const Icon = m.icon;
                return (
                  <button key={m.id} onClick={() => setActiveTab(m.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeTab === m.id ? 'bg-brand-600 text-white shadow' : 'text-gray-500 hover:text-brand-600'}`}>
                    <Icon size={13} /> {m.label}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 md:p-6">
        {activeTab === 'workflow' && <WorkflowCanvas user={user} students={students} />}
        {activeTab === 'scanner'  && <ScannerTab user={user} />}
        {activeTab === 'redesign' && <RedesignTab user={user} />}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// CANVAS DE WORKFLOW — AtivaIA
// ═══════════════════════════════════════════════════════════════════════════════
const WorkflowCanvas: React.FC<{ user: User; students: Student[] }> = ({ user, students }) => {
  // Workflow state
  const [uploadFile, setUploadFile]       = useState<File | null>(null);
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [prompt, setPrompt]               = useState('');
  const [model, setModel]                 = useState<AIModel>('gemini');
  const [imageCount, setImageCount]       = useState(5);
  const [aspectRatio, setAspectRatio]     = useState<AspectRatio>('1:1');

  // Execution state
  const [stepStatus, setStepStatus]       = useState<StepStatus[]>(['idle','idle','idle','idle']);
  const [running, setRunning]             = useState(false);
  const [results, setResults]             = useState<ResultImage[]>([]);
  const [log, setLog]                     = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const totalCredits = calcCredits(model, imageCount);

  const updateStep = (idx: number, s: StepStatus) =>
    setStepStatus(prev => prev.map((v, i) => i === idx ? s : v));

  const handleFile = async (f: File) => {
    setUploadFile(f);
    const b64 = await fileToBase64(f);
    setUploadPreview(b64);
    updateStep(0, 'done');
  };

  const reset = () => {
    setStepStatus(['idle','idle','idle','idle']);
    setResults([]);
    setLog('');
    setRunning(false);
  };

  const runWorkflow = async () => {
    if (!prompt.trim()) { alert('Escreva um prompt antes de gerar.'); return; }
    reset();
    setRunning(true);

    try {
      // ── Step 0: Upload ──
      updateStep(0, 'done');
      await sleep(300);

      // ── Step 1: Prompt ──
      updateStep(1, 'running');
      setLog('Analisando instrução e contexto...');
      await sleep(400);

      let imagePrompts: string[] = [];

      if (uploadPreview) {
        // Analyze the uploaded activity image and generate N image prompts
        const analysisRaw = await AIService.generateFromPromptWithImage(
          `Você é um especialista em educação inclusiva.
Analise esta atividade educacional na imagem.
Com base na imagem e na instrução do professor: "${prompt}"

Gere exatamente ${imageCount} prompts de imagem diferentes, em inglês, para criar ilustrações pedagógicas que apoiem esta atividade.
Cada prompt deve ser claro, específico e adequado para alunos com deficiência.
Retorne apenas os prompts separados por ||| (três pipes), sem numeração, sem explicação.`,
          uploadPreview,
          user
        );
        imagePrompts = analysisRaw
          .split('|||')
          .map(p => p.trim())
          .filter(Boolean)
          .slice(0, imageCount);
      }

      if (imagePrompts.length < imageCount) {
        // Fill with defaults derived from the prompt
        while (imagePrompts.length < imageCount) {
          imagePrompts.push(
            `${prompt} - educational illustration number ${imagePrompts.length + 1}, inclusive design, simple, colorful, child-friendly`
          );
        }
      }

      updateStep(1, 'done');

      // ── Step 2: Generator ──
      updateStep(2, 'running');
      const generated: ResultImage[] = [];

      for (let i = 0; i < imagePrompts.length; i++) {
        const imgPrompt = imagePrompts[i];
        setLog(`Gerando imagem ${i + 1} de ${imagePrompts.length}...`);

        let imageUrl = '';
        try {
          imageUrl = await AIService.generateImageFromPrompt(imgPrompt, user);
        } catch {
          imageUrl = '';
        }

        generated.push({
          id: `img-${Date.now()}-${i}`,
          imageUrl,
          description: imgPrompt,
          prompt: imgPrompt,
        });
        setResults([...generated]);
        await sleep(100);
      }

      updateStep(2, 'done');

      // ── Step 3: Result ──
      updateStep(3, 'done');
      setLog('');

    } catch (e: any) {
      setLog('Erro: ' + (e?.message || 'Verifique suas chaves de API.'));
      setStepStatus(prev => prev.map(s => s === 'running' ? 'error' : s));
    } finally {
      setRunning(false);
    }
  };

  const downloadImage = (item: ResultImage) => {
    if (item.imageUrl) {
      const a = document.createElement('a');
      a.href = item.imageUrl;
      a.download = `ativaIA_imagem_${item.id}.png`;
      a.click();
    } else {
      exportAsText(item.description, `ativaIA_descricao_${item.id}.txt`);
    }
  };

  const readyToRun = prompt.trim().length > 0;

  return (
    <>
      <style>{`
        @keyframes wf-dash { to { stroke-dashoffset: -12; } }
        @keyframes wf-pulse { 0%,100%{opacity:.6} 50%{opacity:1} }
        @keyframes wf-spin-slow { to { transform: rotate(360deg); } }
        .wf-connector-line { transition: stroke .3s, opacity .3s; }
        .wf-connector-running { animation: wf-dash .6s linear infinite; }
        .wf-block-running { animation: wf-pulse .9s ease-in-out infinite; }
        .wf-step-done .wf-step-dot { background: #22c55e; }
        .wf-step-running .wf-step-dot { background: #ea580c; animation: wf-pulse .8s ease-in-out infinite; }
        .wf-step-error .wf-step-dot { background: #ef4444; }
        .wf-result-appear { animation: lab-fade-up .4s ease both; }
      `}</style>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-3">
          <ModelSelector model={model} onChange={setModel} credits={totalCredits} />
        </div>
        <div className="flex items-center gap-2">
          {(results.length > 0 || running) && (
            <button onClick={reset}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-gray-200 text-sm font-bold text-gray-500 hover:bg-gray-100 transition">
              <RefreshCw size={14} /> Reiniciar
            </button>
          )}
          <button onClick={runWorkflow} disabled={running || !readyToRun}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-sm font-bold shadow-lg shadow-orange-200 transition disabled:opacity-50 disabled:cursor-not-allowed">
            {running
              ? <><Loader size={15} className="animate-spin" /> Gerando...</>
              : <><Play size={15} /> Executar Fluxo</>}
          </button>
        </div>
      </div>

      {/* Credit notice */}
      {readyToRun && !running && results.length === 0 && (
        <div className="mb-4 flex items-center gap-2 bg-orange-50 border border-orange-100 rounded-xl px-4 py-2.5 text-sm">
          <Coins size={15} className="text-brand-500 shrink-0" />
          <span className="text-gray-600">Esta geração consumirá <strong className="text-brand-700">{totalCredits} créditos</strong> ({model === 'gemini' ? 'Gemini' : 'ChatGPT'} · {imageCount} imagens)</span>
        </div>
      )}

      {/* Canvas Area */}
      <div className="rounded-3xl border border-gray-100 overflow-hidden"
        style={{ background: 'radial-gradient(circle, #e5e7eb 1px, transparent 1px)', backgroundSize: '24px 24px', backgroundColor: '#f9fafb' }}>

        {/* Flow blocks */}
        <div className="p-6 overflow-x-auto">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-start gap-4 min-w-0 lg:min-w-max mx-auto" style={{ maxWidth: '100%' }}>

            {/* ── Block 0: Upload ── */}
            <CanvasBlock
              step={1} title="Enviar Atividade" icon={Upload}
              status={stepStatus[0]}
              description="Imagem ou PDF da atividade">
              <div
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-5 text-center cursor-pointer transition ${uploadFile ? 'border-green-300 bg-green-50' : 'border-orange-200 hover:border-brand-400 hover:bg-orange-50'}`}>
                {uploadPreview ? (
                  <div className="relative">
                    <img src={uploadPreview} alt="preview" className="max-h-28 mx-auto rounded-xl object-contain" />
                    <button onClick={e => { e.stopPropagation(); setUploadFile(null); setUploadPreview(null); updateStep(0,'idle'); }}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600">
                      <X size={12} />
                    </button>
                  </div>
                ) : uploadFile ? (
                  <div className="text-center">
                    <FileText size={28} className="text-brand-500 mx-auto mb-2" />
                    <p className="text-xs font-bold text-brand-600 truncate max-w-[150px] mx-auto">{uploadFile.name}</p>
                  </div>
                ) : (
                  <>
                    <Upload size={26} className="text-gray-300 mx-auto mb-2" />
                    <p className="text-xs font-semibold text-gray-500">Clique para enviar</p>
                    <p className="text-[10px] text-gray-400 mt-1">JPG · PNG · PDF</p>
                  </>
                )}
              </div>
              <input ref={fileInputRef} type="file" accept=".pdf,.jpg,.jpeg,.png" className="hidden"
                onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
              <p className="text-[10px] text-gray-400 mt-2 text-center">Opcional — enriquece o resultado</p>
            </CanvasBlock>

            <CanvasConnector active={stepStatus[0] === 'done'} running={stepStatus[1] === 'running'} />

            {/* ── Block 1: Prompt ── */}
            <CanvasBlock
              step={2} title="Prompt IA" icon={MessageSquare}
              status={stepStatus[1]}
              description="Instrução para a IA">
              <textarea
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder="Descreva o que quer gerar…"
                rows={4}
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300 resize-none"
              />
              <div className="mt-2">
                <p className="text-[10px] font-bold text-gray-400 uppercase mb-1.5">Sugestões</p>
                <div className="space-y-1">
                  {PROMPT_SUGGESTIONS.slice(0, 3).map(s => (
                    <button key={s} onClick={() => setPrompt(s)}
                      className="w-full text-left text-[11px] text-gray-500 hover:text-brand-600 hover:bg-orange-50 px-2 py-1.5 rounded-lg transition leading-tight border border-transparent hover:border-orange-100">
                      <Star size={9} className="inline mr-1 text-brand-400" />{s}
                    </button>
                  ))}
                </div>
              </div>
            </CanvasBlock>

            <CanvasConnector active={stepStatus[1] === 'done'} running={stepStatus[2] === 'running'} />

            {/* ── Block 2: Generator ── */}
            <CanvasBlock
              step={3} title="Gerador de Imagem" icon={SlidersHorizontal}
              status={stepStatus[2]}
              description="Configure as imagens">
              {/* Image count */}
              <div className="mb-4">
                <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1.5">Número de Imagens</label>
                <div className="flex items-center gap-2">
                  <button onClick={() => setImageCount(Math.max(1, imageCount - 1))}
                    className="w-8 h-8 rounded-lg border border-gray-200 flex items-center justify-center font-bold text-gray-600 hover:bg-gray-100 transition text-lg">−</button>
                  <span className="w-10 text-center text-lg font-extrabold text-gray-900">{imageCount}</span>
                  <button onClick={() => setImageCount(Math.min(10, imageCount + 1))}
                    className="w-8 h-8 rounded-lg border border-gray-200 flex items-center justify-center font-bold text-gray-600 hover:bg-gray-100 transition text-lg">+</button>
                </div>
              </div>
              {/* Aspect ratio */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1.5">Proporção</label>
                <div className="flex flex-wrap gap-1.5">
                  {ASPECT_RATIOS.map(r => (
                    <button key={r.id} onClick={() => setAspectRatio(r.id)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition ${aspectRatio === r.id ? 'bg-brand-600 text-white border-brand-600' : 'border-gray-200 text-gray-500 hover:border-brand-300'}`}>
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>
              {/* Credit display */}
              <div className="mt-4 bg-orange-50 rounded-xl px-3 py-2 flex items-center gap-2">
                <Coins size={13} className="text-brand-500" />
                <span className="text-xs font-bold text-brand-700">{calcCredits(model, imageCount)} créditos</span>
                <span className="text-[10px] text-gray-400 ml-auto">{model === 'gemini' ? 'Gemini ×2/img' : 'OpenAI ×3/img'}</span>
              </div>
            </CanvasBlock>

            <CanvasConnector active={stepStatus[2] === 'done'} running={stepStatus[3] === 'running'} />

            {/* ── Block 3: Result ── */}
            <CanvasBlock
              step={4} title="Resultado" icon={ImageIcon}
              status={stepStatus[3]}
              description="Imagens geradas pela IA"
              wide>
              {results.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  {running ? (
                    <>
                      <Loader size={28} className="text-brand-400 animate-spin mb-3" />
                      <p className="text-sm font-semibold text-gray-500">{log || 'Gerando...'}</p>
                    </>
                  ) : (
                    <>
                      <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-3">
                        <ImageIcon size={24} className="text-gray-300" />
                      </div>
                      <p className="text-sm text-gray-400">Configure e clique em <strong>Executar Fluxo</strong></p>
                    </>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  {log && (
                    <div className="flex items-center gap-2 text-xs text-brand-600 font-semibold bg-orange-50 px-3 py-2 rounded-lg">
                      <Loader size={12} className="animate-spin" /> {log}
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    {results.map((item, i) => (
                      <ResultCard key={item.id} item={item} index={i} onDownload={() => downloadImage(item)} onRegenerate={async () => {
                        try {
                          const newUrl = await AIService.generateImageFromPrompt(item.prompt, user);
                          setResults(prev => prev.map(r => r.id === item.id ? { ...r, imageUrl: newUrl } : r));
                        } catch (e: any) { alert(e.message); }
                      }} />
                    ))}
                  </div>
                </div>
              )}
            </CanvasBlock>

          </div>
        </div>

        {/* Status bar */}
        {running && log && (
          <div className="border-t border-gray-200 bg-white px-6 py-2.5 flex items-center gap-2 text-xs text-gray-500 font-semibold">
            <Loader size={12} className="animate-spin text-brand-500" /> {log}
          </div>
        )}
      </div>
    </>
  );
};

// ─── Sub-componentes do Canvas ────────────────────────────────────────────────
const CanvasBlock: React.FC<{
  step: number;
  title: string;
  icon: React.ElementType;
  status: StepStatus;
  description?: string;
  wide?: boolean;
  children: React.ReactNode;
}> = ({ step, title, icon: Icon, status, description, wide, children }) => {
  const borderColor = {
    idle: 'border-gray-200',
    ready: 'border-gray-200',
    running: 'border-brand-400',
    done: 'border-green-300',
    error: 'border-red-300',
  }[status];

  const dotColor = {
    idle: 'bg-gray-300',
    ready: 'bg-gray-300',
    running: 'bg-brand-500',
    done: 'bg-green-500',
    error: 'bg-red-500',
  }[status];

  return (
    <div className={`bg-white rounded-2xl border-2 ${borderColor} shadow-sm p-4 transition-all duration-300 ${wide ? 'lg:w-72' : 'lg:w-56'} w-full shrink-0 ${status === 'running' ? 'wf-block-running' : ''}`}>
      {/* Block header */}
      <div className="flex items-center gap-2 mb-3">
        <div className="flex items-center justify-center w-7 h-7 rounded-xl bg-gray-100 text-gray-500 text-xs font-extrabold shrink-0">
          {step}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-extrabold text-gray-900 truncate">{title}</p>
          {description && <p className="text-[10px] text-gray-400 truncate">{description}</p>}
        </div>
        {/* Status dot */}
        <div className={`w-2 h-2 rounded-full shrink-0 ${dotColor} ${status === 'running' ? 'animate-pulse' : ''}`} />
      </div>
      <div>{children}</div>
    </div>
  );
};

const CanvasConnector: React.FC<{ active: boolean; running: boolean }> = ({ active, running }) => (
  <div className="flex lg:items-center items-center justify-center lg:w-10 lg:h-auto h-8 w-full shrink-0">
    {/* Desktop: horizontal arrow */}
    <svg className="hidden lg:block" width="40" height="24" viewBox="0 0 40 24">
      <line x1="0" y1="12" x2="32" y2="12"
        strokeWidth="2"
        stroke={active ? '#22c55e' : running ? '#ea580c' : '#d1d5db'}
        strokeDasharray={running ? '5 3' : 'none'}
        className={running ? 'wf-connector-running' : ''}
      />
      <polygon points="32,8 40,12 32,16"
        fill={active ? '#22c55e' : running ? '#ea580c' : '#d1d5db'} />
    </svg>
    {/* Mobile: vertical arrow */}
    <svg className="block lg:hidden" width="24" height="32" viewBox="0 0 24 32">
      <line x1="12" y1="0" x2="12" y2="24"
        strokeWidth="2"
        stroke={active ? '#22c55e' : running ? '#ea580c' : '#d1d5db'}
        strokeDasharray={running ? '5 3' : 'none'}
        className={running ? 'wf-connector-running' : ''}
      />
      <polygon points="8,24 12,32 16,24"
        fill={active ? '#22c55e' : running ? '#ea580c' : '#d1d5db'} />
    </svg>
  </div>
);

const ResultCard: React.FC<{
  item: ResultImage;
  index: number;
  onDownload: () => void;
  onRegenerate: () => void;
}> = ({ item, index, onDownload, onRegenerate }) => (
  <div className="wf-result-appear bg-gray-50 rounded-xl overflow-hidden border border-gray-100 group" style={{ animationDelay: `${index * 0.07}s` }}>
    {item.imageUrl ? (
      <img src={item.imageUrl} alt={`Imagem ${index + 1}`} className="w-full h-24 object-cover" />
    ) : (
      <div className="w-full h-24 bg-gradient-to-br from-orange-50 to-amber-50 flex flex-col items-center justify-center p-2">
        <ImageIcon size={18} className="text-brand-300 mb-1" />
        <p className="text-[9px] text-gray-400 text-center leading-tight line-clamp-3">{item.description}</p>
      </div>
    )}
    <div className="flex items-center gap-1 px-2 py-1.5">
      <span className="text-[10px] text-gray-400 flex-1 font-bold">#{index + 1}</span>
      <button onClick={onRegenerate} title="Regenerar"
        className="p-1 hover:bg-gray-200 rounded transition"><RefreshCw size={11} className="text-gray-400" /></button>
      <button onClick={onDownload} title="Baixar"
        className="p-1 hover:bg-gray-200 rounded transition"><Download size={11} className="text-gray-400" /></button>
    </div>
  </div>
);

// ═══════════════════════════════════════════════════════════════════════════════
// EDULEISIA — Scanner Pedagógico
// ═══════════════════════════════════════════════════════════════════════════════
const ScannerTab: React.FC<{ user: User }> = ({ user }) => {
  const [file, setFile]                   = useState<File | null>(null);
  const [preview, setPreview]             = useState<string | null>(null);
  const [adaptationType, setAdaptationType] = useState('autismo');
  const [model, setModel]                 = useState<AIModel>('gemini');
  const [loading, setLoading]             = useState(false);
  const [result, setResult]               = useState<AdaptedActivity | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraRef    = useRef<HTMLInputElement>(null);
  const credits = calcCredits(model, 1, true);

  const handleFileChange = async (f: File) => {
    setFile(f); setResult(null);
    if (f.type.startsWith('image/')) setPreview(await fileToBase64(f));
    else setPreview(null);
  };

  const handleAdapt = async () => {
    if (!file) { alert('Envie um arquivo primeiro.'); return; }
    setLoading(true); setResult(null);
    try {
      const base64 = await fileToBase64(file);
      const adaptLabel = ADAPTATION_TYPES.find(a => a.id === adaptationType)?.label || adaptationType;
      const prompt = `Você é um especialista em educação inclusiva. Analise o conteúdo desta atividade educacional (extraia o texto se for imagem) e crie uma versão adaptada para alunos com ${adaptLabel}.

Regras:
- Simplifique a linguagem sem perder o objetivo pedagógico
- Divida instruções longas em passos numerados curtos
- Para TEA: estruture claramente, evite ambiguidade, use linguagem literal
- Para TDAH: instruções curtas, destaque o essencial
- Para Dislexia: frases curtas, vocabulário simples
- Para DI: linguagem simples, contexto concreto

Retorne SOMENTE um JSON válido:
{"original":"texto extraído","adapted":"versão adaptada completa","adaptationType":"${adaptLabel}"}`;

      const raw = await AIService.generateFromPromptWithImage(prompt, base64, user);
      let parsed: AdaptedActivity;
      try {
        const m = raw.match(/\{[\s\S]*\}/);
        parsed = m ? JSON.parse(m[0]) : { original: '', adapted: raw, adaptationType: adaptLabel };
      } catch { parsed = { original: '', adapted: raw, adaptationType: adaptLabel }; }
      setResult(parsed);
    } catch (e: any) {
      alert('Erro ao adaptar: ' + (e?.message || 'verifique a chave de API.'));
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <h2 className="font-bold text-gray-800 text-lg flex items-center gap-2">
            <Camera size={18} className="text-brand-600" /> Scanner Pedagógico
          </h2>
          <ModelSelector model={model} onChange={setModel} credits={credits} compact />
        </div>

        <div onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-orange-200 rounded-2xl p-8 text-center cursor-pointer hover:border-brand-400 hover:bg-orange-50 transition mb-4">
          {preview ? (
            <img src={preview} alt="preview" className="max-h-40 mx-auto rounded-lg object-contain" />
          ) : (
            <>
              <Upload size={32} className="text-brand-400 mx-auto mb-3" />
              <p className="text-sm font-semibold text-gray-600">Arraste ou clique para enviar</p>
              <p className="text-xs text-gray-400 mt-1">PDF, JPG, PNG aceitos</p>
              {file && <p className="text-xs text-brand-600 font-bold mt-2">{file.name}</p>}
            </>
          )}
        </div>
        <input ref={fileInputRef} type="file" accept=".pdf,.jpg,.jpeg,.png" className="hidden"
          onChange={e => e.target.files?.[0] && handleFileChange(e.target.files[0])} />

        <div className="flex gap-2 mb-5">
          <button onClick={() => cameraRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50">
            <Camera size={15} /> Usar câmera
          </button>
          <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden"
            onChange={e => e.target.files?.[0] && handleFileChange(e.target.files[0])} />
          {file && <span className="flex items-center gap-1 text-xs text-brand-600 font-bold"><CheckCircle size={13} /> {file.name}</span>}
        </div>

        <div className="mb-5">
          <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Tipo de Adaptação</label>
          <div className="flex flex-wrap gap-2">
            {ADAPTATION_TYPES.map(a => (
              <button key={a.id} onClick={() => setAdaptationType(a.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold border-2 transition ${adaptationType === a.id ? 'bg-brand-600 text-white border-brand-600' : 'bg-white text-gray-600 border-gray-200 hover:border-brand-300'}`}>
                {a.label}
              </button>
            ))}
          </div>
        </div>

        {/* Credit notice */}
        <div className="mb-4 flex items-center gap-2 bg-orange-50 border border-orange-100 rounded-xl px-4 py-2 text-xs">
          <Coins size={13} className="text-brand-500 shrink-0" />
          <span className="text-gray-600">Consumirá <strong className="text-brand-700">{credits} crédito{credits !== 1 ? 's' : ''}</strong> — {model === 'gemini' ? 'Gemini' : 'ChatGPT'}</span>
        </div>

        <button onClick={handleAdapt} disabled={loading || !file}
          className="w-full bg-brand-600 hover:bg-brand-700 text-white py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition shadow-lg shadow-orange-200 disabled:opacity-60">
          {loading ? <><Loader size={16} className="animate-spin" /> Adaptando…</> : <><Brain size={16} /> Adaptar Atividade com IA</>}
        </button>
      </div>

      {result && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <FileText size={15} className="text-gray-500" />
              <span className="text-xs font-bold text-gray-500 uppercase">Original</span>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{result.original || '(texto extraído da imagem)'}</p>
          </div>
          <div className="bg-orange-50 rounded-2xl border border-orange-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle size={15} className="text-brand-600" />
              <span className="text-xs font-bold text-brand-700 uppercase">Adaptada — {result.adaptationType}</span>
              <button onClick={() => exportAsText(result.adapted, 'atividade_adaptada.txt')}
                className="ml-auto flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-white border border-orange-200 text-brand-600 font-bold hover:bg-orange-100">
                <Download size={10} /> Exportar
              </button>
            </div>
            <p className="text-sm text-gray-800 leading-relaxed whitespace-pre-wrap">{result.adapted}</p>
          </div>
        </div>
      )}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// NEURODESIGN — Redesenho Inclusivo
// ═══════════════════════════════════════════════════════════════════════════════
const RedesignTab: React.FC<{ user: User }> = ({ user }) => {
  const [inputText, setInputText] = useState('');
  const [model, setModel]         = useState<AIModel>('gemini');
  const [loading, setLoading]     = useState(false);
  const [result, setResult]       = useState<RedesignedActivity | null>(null);
  const credits = calcCredits(model, 1, true);

  const handleRedesign = async () => {
    if (!inputText.trim()) { alert('Cole o conteúdo da atividade que deseja redesenhar.'); return; }
    setLoading(true); setResult(null);
    try {
      const prompt = `Você é um designer instrucional especialista em educação inclusiva.
Receba esta atividade e faça um REDESENHO PEDAGÓGICO INCLUSIVO completo.

ATIVIDADE ORIGINAL:
${inputText}

Aplique:
1. Reorganize o layout (títulos, seções numeradas)
2. Insira apoio visual em texto (📌 Imagem sugerida: ...)
3. Sugira ícones/pictogramas (🔢, 🔤, etc)
4. Melhore a organização para TEA e dislexia
5. Separe instruções em passos numerados
6. Use **negrito** para palavras-chave
7. Adicione "Espaço para resposta:" depois de cada pergunta

Retorne SOMENTE um JSON válido:
{"original":"texto original","redesigned":"atividade redesenhada completa","suggestions":["Sugestão 1","Sugestão 2","Sugestão 3"]}`;

      const raw = await AIService.generateFromPrompt(prompt, user);
      let parsed: RedesignedActivity;
      try {
        const m = raw.match(/\{[\s\S]*\}/);
        parsed = m ? JSON.parse(m[0]) : { original: inputText, redesigned: raw, suggestions: [] };
      } catch { parsed = { original: inputText, redesigned: raw, suggestions: [] }; }
      setResult(parsed);
    } catch (e: any) {
      alert('Erro ao redesenhar: ' + (e?.message || ''));
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <h2 className="font-bold text-gray-800 text-lg flex items-center gap-2">
            <Layers size={18} className="text-brand-600" /> Redesenho Inclusivo
          </h2>
          <ModelSelector model={model} onChange={setModel} credits={credits} compact />
        </div>
        <p className="text-sm text-gray-500 mb-5">Cole qualquer atividade existente e a IA vai redesenhá-la com layout pedagógico acessível.</p>

        <textarea value={inputText} onChange={e => setInputText(e.target.value)}
          placeholder="Cole aqui o texto da atividade que deseja redesenhar…"
          className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300 resize-none"
          rows={8} />

        {/* Credit notice */}
        <div className="mt-3 mb-4 flex items-center gap-2 bg-orange-50 border border-orange-100 rounded-xl px-4 py-2 text-xs">
          <Coins size={13} className="text-brand-500 shrink-0" />
          <span className="text-gray-600">Consumirá <strong className="text-brand-700">{credits} crédito{credits !== 1 ? 's' : ''}</strong> — {model === 'gemini' ? 'Gemini' : 'ChatGPT'}</span>
        </div>

        <button onClick={handleRedesign} disabled={loading}
          className="w-full bg-brand-600 hover:bg-brand-700 text-white py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition shadow-lg shadow-orange-200 disabled:opacity-60">
          {loading ? <><Loader size={16} className="animate-spin" /> Redesenhando…</> : <><Wand2 size={16} /> Redesenhar Atividade com IA</>}
        </button>
      </div>

      {result && (
        <div className="space-y-4">
          {(result.suggestions ?? []).length > 0 && (
            <div className="bg-amber-50 border border-amber-100 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb size={15} className="text-amber-600" />
                <span className="text-xs font-bold text-amber-700 uppercase">Sugestões de Melhoria</span>
              </div>
              <ul className="space-y-1.5">
                {(result.suggestions ?? []).map((s, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-amber-800">
                    <span className="bg-amber-200 text-amber-800 text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-center gap-2 mb-3">
                <FileText size={15} className="text-gray-500" />
                <span className="text-xs font-bold text-gray-500 uppercase">Original</span>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">{result.original}</p>
            </div>
            <div className="bg-orange-50 rounded-2xl border border-orange-100 shadow-sm p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Wand2 size={15} className="text-brand-600" />
                  <span className="text-xs font-bold text-brand-700 uppercase">Redesenhada</span>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => exportAsText(result.redesigned, 'atividade_redesenhada.txt')}
                    className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-white border border-orange-200 text-brand-600 font-bold hover:bg-orange-100">
                    <Download size={10} /> Exportar
                  </button>
                  <button onClick={() => window.print()}
                    className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-white border border-orange-200 text-brand-600 font-bold hover:bg-orange-100">
                    <Printer size={10} /> PDF
                  </button>
                </div>
              </div>
              <div className="text-sm text-gray-800 leading-relaxed whitespace-pre-wrap">{result.redesigned}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
