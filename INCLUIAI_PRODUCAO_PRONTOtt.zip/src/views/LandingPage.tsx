import React, { useState, useEffect, useRef } from 'react';
import {
  Brain, ShieldCheck, Users, Sparkles, FileText, ArrowRight,
  CheckCircle, Lock, Phone, ChevronRight, Cloud,
  Stethoscope, Zap, Clock, FlaskConical
} from 'lucide-react';
import { PlanTier, SiteConfig } from '../types';
import { PaymentService } from '../services/paymentService';
import { AdminService } from '../services/adminService';

interface Props {
  onLogin: () => void;
  onRegister: () => void;
  onAudit: () => void;
}

// ─── scroll-reveal hook ───────────────────────────────────────────────────────
function useReveal<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.15 }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

// ─── component ────────────────────────────────────────────────────────────────
export const LandingPage: React.FC<Props> = ({ onLogin, onRegister, onAudit }) => {
  const [config, setConfig] = useState<SiteConfig | null>(null);

  useEffect(() => { AdminService.getSiteConfig().then(setConfig); }, []);

  const handleCheckout = async (plan: PlanTier) => {
    const url = await PaymentService.getCheckoutUrl(plan, {});
    window.location.href = url;
  };

  const scrollTo = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const pricePro        = config?.pricing.pro_monthly   || 89.00;
  const priceProAnnual  = config?.pricing.pro_annual    || 69.00;
  const priceMaster     = config?.pricing.master_monthly || 127.00;
  const priceMasterAnnual = config?.pricing.master_annual || 99.00;

  // Reveal refs
  const pain   = useReveal<HTMLDivElement>();
  const feats  = useReveal<HTMLDivElement>();
  const lab    = useReveal<HTMLDivElement>();
  const price  = useReveal<HTMLDivElement>();
  const cta    = useReveal<HTMLDivElement>();

  return (
    <div className="min-h-screen bg-white font-sans selection:bg-orange-100 selection:text-orange-900">

      <style>{`
        @keyframes lp-up   { from{opacity:0;transform:translateY(32px)} to{opacity:1;transform:translateY(0)} }
        @keyframes lp-fade { from{opacity:0} to{opacity:1} }
        @keyframes lp-bar  { from{height:0} to{height:var(--h)} }
        @keyframes lp-float-a { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-14px)} }
        @keyframes lp-float-b { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-9px)} }
        @keyframes lp-shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
        @keyframes lp-pulse-dot { 0%,100%{opacity:.4} 50%{opacity:1} }

        .lp-slide-1 { animation: lp-up   0.7s ease 0.0s both; }
        .lp-slide-2 { animation: lp-up   0.7s ease 0.12s both; }
        .lp-slide-3 { animation: lp-up   0.7s ease 0.24s both; }
        .lp-slide-4 { animation: lp-up   0.7s ease 0.36s both; }

        .reveal { opacity:0; transform:translateY(28px); transition: opacity 0.65s ease, transform 0.65s ease; }
        .reveal.on { opacity:1; transform:translateY(0); }
        .reveal-d1 { transition-delay:0.05s; }
        .reveal-d2 { transition-delay:0.15s; }
        .reveal-d3 { transition-delay:0.25s; }
        .reveal-d4 { transition-delay:0.35s; }
        .reveal-d5 { transition-delay:0.45s; }
        .reveal-d6 { transition-delay:0.55s; }

        .lp-float-a { animation: lp-float-a 5s ease-in-out infinite; }
        .lp-float-b { animation: lp-float-b 4s ease-in-out infinite 1s; }

        .cta-btn {
          background: linear-gradient(90deg, #ea580c 0%, #f97316 50%, #ea580c 100%);
          background-size: 200% auto;
          animation: lp-shimmer 3s linear infinite;
        }
        .bar-grow { animation: lp-bar 1s ease both; }
        .dot-1 { animation: lp-pulse-dot 1.4s infinite 0s; }
        .dot-2 { animation: lp-pulse-dot 1.4s infinite .4s; }
        .dot-3 { animation: lp-pulse-dot 1.4s infinite .8s; }

        .feat-card:hover .feat-icon { background: #ea580c; color: white; }
        .feat-card:hover { box-shadow: 0 8px 40px rgba(234,88,12,.10); transform: translateY(-3px); }
        .feat-card { transition: all .3s ease; }
      `}</style>

      {/* ── NAVBAR ── */}
      <header className="fixed w-full bg-white/80 backdrop-blur-2xl z-50 border-b border-gray-100/60">
        <div className="max-w-7xl mx-auto px-6 h-[68px] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="bg-brand-600 p-2 rounded-xl">
              <Brain className="text-white h-5 w-5" />
            </div>
            <span className="text-xl font-extrabold text-gray-900 tracking-tight">IncluiAI</span>
          </div>

          <nav className="hidden md:flex gap-7 items-center text-sm font-medium text-gray-600">
            <a href="#features" onClick={e => scrollTo(e, 'features')} className="hover:text-brand-600 transition">Recursos</a>
            <a href="#lab" onClick={e => scrollTo(e, 'lab')} className="hover:text-brand-600 transition">IncluiLAB</a>
            <a href="#pricing" onClick={e => scrollTo(e, 'pricing')} className="hover:text-brand-600 transition">Planos</a>
            <button onClick={onAudit} className="hover:text-brand-600 flex items-center gap-1.5 transition">
              <ShieldCheck size={15} /> Validar Doc
            </button>
          </nav>

          <div className="flex items-center gap-3">
            <button onClick={onLogin} className="text-sm font-bold text-gray-700 hover:text-brand-600 transition px-3 py-2 rounded-lg hover:bg-orange-50">
              Entrar
            </button>
            <button onClick={onLogin}
              className="cta-btn text-white text-sm font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-orange-200 hover:scale-105 transition-transform">
              Começar Grátis
            </button>
          </div>
        </div>
      </header>

      <main>

        {/* ══ 1. HERO ══ */}
        <section className="pt-32 pb-24 lg:pt-44 lg:pb-36 bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-24">

              {/* Copy */}
              <div className="flex-1 text-center lg:text-left order-2 lg:order-1 max-w-2xl mx-auto lg:mx-0">
                <div className="lp-slide-1 inline-flex items-center gap-2 bg-orange-50 border border-orange-100 text-brand-600 px-4 py-1.5 rounded-full text-xs font-bold mb-7">
                  <Sparkles size={12} /> Decreto nº 12.686/2025 · IA Educacional Certificada
                </div>

                <h1 className="lp-slide-2 text-[2.75rem] sm:text-5xl lg:text-[3.5rem] xl:text-[4rem] font-extrabold tracking-tight leading-[1.07] text-gray-900 mb-6">
                  Documentação inclusiva,<br />
                  <span className="bg-gradient-to-r from-brand-600 to-orange-400 bg-clip-text text-transparent">gerada com IA.</span>
                </h1>

                <p className="lp-slide-3 text-xl text-gray-500 leading-relaxed mb-10 max-w-xl mx-auto lg:mx-0">
                  PEI, PAEE, Estudo de Caso e muito mais — com rastreabilidade, código auditável e segurança jurídica total.
                </p>

                <div className="lp-slide-4 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
                  <button onClick={onLogin}
                    className="cta-btn text-white px-8 py-4 rounded-2xl text-base font-bold shadow-xl shadow-orange-200 flex items-center justify-center gap-2 group hover:scale-105 transition-transform">
                    Começar Agora <ArrowRight size={18} className="group-hover:translate-x-1 transition" />
                  </button>
                  <a href="#pricing" onClick={e => scrollTo(e, 'pricing')}
                    className="border-2 border-gray-200 text-gray-700 px-8 py-4 rounded-2xl text-base font-bold hover:border-brand-400 hover:text-brand-600 transition flex items-center justify-center">
                    Ver Planos
                  </a>
                </div>

                {/* Stats */}
                <div className="lp-slide-4 flex flex-wrap gap-8 justify-center lg:justify-start">
                  {[
                    { val: '+12.000', label: 'Documentos' },
                    { val: '+1.800', label: 'Professores' },
                    { val: '100%', label: 'LGPD Conforme' },
                  ].map(s => (
                    <div key={s.label}>
                      <div className="text-2xl font-extrabold text-gray-900">{s.val}</div>
                      <div className="text-xs text-gray-400 font-semibold uppercase tracking-wide mt-0.5">{s.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dashboard Mockup */}
              <div className="flex-1 w-full max-w-lg order-1 lg:order-2 relative">
                <div className="lp-float-a relative rounded-3xl overflow-hidden border border-gray-100 shadow-2xl shadow-gray-200 bg-white">
                  {/* Browser bar */}
                  <div className="bg-gray-50 border-b border-gray-100 px-4 py-2.5 flex items-center gap-2">
                    <div className="flex gap-1.5">
                      <div className="w-3 h-3 rounded-full bg-red-400/70" />
                      <div className="w-3 h-3 rounded-full bg-yellow-400/70" />
                      <div className="w-3 h-3 rounded-full bg-green-400/70" />
                    </div>
                    <div className="flex-1 bg-white rounded-lg border border-gray-200 px-3 py-1 text-[11px] text-gray-400 flex items-center gap-1.5">
                      <Lock size={9} className="text-green-500" /> app.incluiai.com/pei
                    </div>
                    <div className="flex gap-1">
                      <span className="dot-1 w-1.5 h-1.5 rounded-full bg-brand-400 inline-block" />
                      <span className="dot-2 w-1.5 h-1.5 rounded-full bg-brand-400 inline-block" />
                      <span className="dot-3 w-1.5 h-1.5 rounded-full bg-brand-400 inline-block" />
                    </div>
                  </div>

                  <div className="p-4 space-y-3">
                    {/* PEI header */}
                    <div className="bg-gradient-to-r from-brand-600 to-orange-400 rounded-2xl px-4 py-3 flex items-center justify-between">
                      <div>
                        <p className="text-white font-bold text-sm">PEI — Plano Educacional Individualizado</p>
                        <p className="text-orange-100 text-xs mt-0.5">Gabriel Oliveira · 2º Ano · TEA Nível 2</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-orange-200 text-[9px] uppercase font-bold">Auditável</p>
                        <p className="text-white font-mono text-xs font-bold">PEI-A3F9</p>
                      </div>
                    </div>

                    {/* Info grid */}
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { label: 'BNCC', val: 'EF01LP01' },
                        { label: 'Suporte', val: 'Nível 2' },
                        { label: 'CID', val: 'F84.0 TEA' },
                        { label: 'Prof. AEE', val: 'Mariana C.' },
                      ].map(f => (
                        <div key={f.label} className="bg-gray-50 border border-gray-100 rounded-xl p-2">
                          <p className="text-[9px] text-brand-600 font-bold uppercase">{f.label}</p>
                          <p className="text-xs text-gray-800 font-semibold mt-0.5">{f.val}</p>
                        </div>
                      ))}
                    </div>

                    {/* Bar chart */}
                    <div className="bg-gray-50 border border-gray-100 rounded-xl p-3">
                      <p className="text-[9px] text-gray-400 font-bold uppercase mb-2">Evolução — 6 Meses</p>
                      <div className="flex items-end gap-1.5 h-12">
                        {[35, 55, 42, 70, 60, 85].map((pct, i) => (
                          <div key={i} className="flex-1 rounded-t-md bar-grow"
                            style={{ '--h': `${pct}%`, height: `${pct}%`, background: `linear-gradient(to top, #ea580c, #fb923c)`, animationDelay: `${i * 0.1}s` } as React.CSSProperties} />
                        ))}
                      </div>
                    </div>

                    {/* AI progress */}
                    <div className="flex items-center gap-3 bg-orange-50 border border-orange-100 rounded-xl px-3 py-2">
                      <div className="bg-brand-600 p-1.5 rounded-lg shrink-0">
                        <Brain size={12} className="text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] text-brand-700 font-bold">IA Gerando Objetivos Pedagógicos…</p>
                        <div className="mt-1 h-1 bg-orange-200 rounded-full overflow-hidden">
                          <div className="h-full rounded-full bg-gradient-to-r from-brand-600 to-orange-400"
                            style={{ width: '72%', animation: 'lp-shimmer 2s linear infinite', backgroundSize: '200% auto' }} />
                        </div>
                      </div>
                      <span className="text-[10px] font-bold text-brand-600 shrink-0">72%</span>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-1.5">
                        <ShieldCheck size={11} className="text-green-500" />
                        <span className="text-[10px] text-green-600 font-bold">Auditável · SHA-256</span>
                      </div>
                      <span className="text-[9px] text-gray-400 font-mono">incluiai.com/validar/…</span>
                    </div>
                  </div>
                </div>

                {/* Floating cards */}
                <div className="lp-float-b hidden sm:flex absolute -bottom-5 -left-6 bg-white border border-gray-100 shadow-xl p-3.5 rounded-2xl items-center gap-3 z-10">
                  <div className="bg-green-50 p-2 rounded-xl"><CheckCircle size={18} className="text-green-500" /></div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Documentos</p>
                    <p className="text-lg font-extrabold text-gray-900">+12.000</p>
                  </div>
                </div>

                <div className="lp-float-a hidden sm:flex absolute -top-4 -right-4 bg-white border border-orange-100 shadow-xl p-3 rounded-2xl items-center gap-2 z-10">
                  <div className="bg-orange-50 p-1.5 rounded-xl">
                    <FlaskConical size={14} className="text-brand-600" />
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold">IncluiLAB</p>
                    <p className="text-xs font-bold text-brand-600">Novo módulo ativo</p>
                  </div>
                  <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse shrink-0" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══ 2. DOR & SOLUÇÃO ══ */}
        <section className="py-28 bg-gray-50/70">
          <div ref={pain.ref} className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-20 items-center">
              <div>
                <p className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-3">O Problema</p>
                <h2 className={`text-3xl md:text-4xl font-extrabold text-gray-900 tracking-tight mb-10 reveal ${pain.visible ? 'on' : ''}`}>
                  O custo invisível da desorganização
                </h2>
                <div className="space-y-8">
                  {[
                    { icon: Clock, title: 'Horas perdidas', desc: 'Montar documentos manualmente consome tempo que deveria ser investido nos alunos.', delay: 'reveal-d1' },
                    { icon: ShieldCheck, title: 'Risco Jurídico', desc: 'Documentos sem padronização ou rastreabilidade expõem professores e instituições.', delay: 'reveal-d2' },
                    { icon: FileText, title: 'Dados fragmentados', desc: 'Sem histórico centralizado, acompanhar a evolução real do aluno fica impossível.', delay: 'reveal-d3' },
                  ].map(item => {
                    const Icon = item.icon;
                    return (
                      <div key={item.title} className={`flex gap-5 reveal ${item.delay} ${pain.visible ? 'on' : ''}`}>
                        <div className="bg-red-50 text-red-500 p-3 rounded-xl h-fit shrink-0">
                          <Icon size={22} />
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-900 mb-1">{item.title}</h4>
                          <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className={`bg-white rounded-3xl shadow-xl border border-gray-100 p-8 reveal reveal-d2 ${pain.visible ? 'on' : ''}`}>
                <div className="mb-5">
                  <span className="bg-orange-50 text-brand-600 border border-orange-100 px-3 py-1 rounded-full text-xs font-bold uppercase">A Solução IncluiAI</span>
                </div>
                <h3 className="text-3xl font-extrabold text-gray-900 tracking-tight mb-4">Centralize. Padronize. Proteja.</h3>
                <p className="text-gray-500 mb-8 leading-relaxed">
                  A única plataforma que une Inteligência Artificial com segurança jurídica educacional.
                  Gere documentos com padrão técnico superior, rastreabilidade total e histórico organizado por aluno.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { val: '-80%', label: 'Tempo operacional' },
                    { val: '100%', label: 'Auditável' },
                    { val: '+12k', label: 'Documentos gerados' },
                    { val: 'LGPD', label: 'Conformidade total' },
                  ].map(s => (
                    <div key={s.label} className="bg-orange-50 border border-orange-100 p-4 rounded-2xl text-center">
                      <div className="text-2xl font-extrabold text-brand-700 mb-1">{s.val}</div>
                      <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wide">{s.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══ 3. FEATURES ══ */}
        <section id="features" className="py-28 bg-white">
          <div ref={feats.ref} className="max-w-7xl mx-auto px-6">
            <div className={`text-center mb-16 reveal ${feats.visible ? 'on' : ''}`}>
              <p className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-3">Recursos</p>
              <h2 className="text-3xl md:text-5xl font-extrabold text-gray-900 tracking-tight mb-4">
                Muito além de um gerador.
              </h2>
              <p className="text-xl text-gray-500 max-w-2xl mx-auto">
                Uma plataforma pensada para segurança, padronização e autoridade profissional.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { icon: ShieldCheck, title: 'Sistema Auditável', desc: 'Cada documento recebe código único SHA-256 com rastreabilidade completa de edições.', delay: 'reveal-d1' },
                { icon: Lock, title: 'Conformidade LGPD', desc: 'Dados isolados por tenant, controle de acesso rigoroso e armazenamento criptografado.', delay: 'reveal-d2' },
                { icon: Brain, title: 'IA Especializada', desc: 'Geração baseada em prompts técnicos com linguagem pedagógica certificada para inclusão.', delay: 'reveal-d3' },
                { icon: FileText, title: 'Padronização Profissional', desc: 'Modelos formais para PEI, PAEE, Estudo de Caso e relatórios com normas ABNT.', delay: 'reveal-d4' },
                { icon: Zap, title: 'Economia de Tempo', desc: 'Documentos completos em minutos. Mais foco nos alunos, menos burocracia.', delay: 'reveal-d5' },
                { icon: Cloud, title: 'Armazenamento Seguro', desc: 'Dados na nuvem com organização automática por aluno, acessíveis de qualquer dispositivo.', delay: 'reveal-d6' },
              ].map(f => {
                const Icon = f.icon;
                return (
                  <div key={f.title} className={`feat-card bg-white border border-gray-100 rounded-2xl p-7 reveal ${f.delay} ${feats.visible ? 'on' : ''}`}>
                    <div className="feat-icon w-12 h-12 bg-orange-50 text-brand-600 rounded-xl flex items-center justify-center mb-5 transition-all duration-300">
                      <Icon size={22} />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">{f.title}</h3>
                    <p className="text-sm text-gray-500 leading-relaxed">{f.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ══ 4. INCLUIAB ══ */}
        <section id="lab" className="py-28 overflow-hidden" style={{ background: 'linear-gradient(160deg, #fff7ed 0%, #ffffff 60%, #ffedd5 100%)' }}>
          <div ref={lab.ref} className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col lg:flex-row items-center gap-16">
              <div className="flex-1">
                <p className={`text-xs font-bold text-brand-600 uppercase tracking-widest mb-3 reveal ${lab.visible ? 'on' : ''}`}>IncluiLAB</p>
                <h2 className={`text-3xl md:text-5xl font-extrabold text-gray-900 tracking-tight mb-5 reveal reveal-d1 ${lab.visible ? 'on' : ''}`}>
                  Laboratório de<br />Atividades Inclusivas
                </h2>
                <p className={`text-xl text-gray-500 mb-10 leading-relaxed max-w-lg reveal reveal-d2 ${lab.visible ? 'on' : ''}`}>
                  Três ferramentas de IA para criar, adaptar e redesenhar atividades pedagógicas com acessibilidade total.
                </p>

                <div className="space-y-5">
                  {[
                    { icon: Zap, name: 'AtivaIA', desc: 'Gere atividades pedagógicas completas com objetivos BNCC, enunciados e questões.', delay: 'reveal-d2' },
                    { icon: Users, name: 'EduLensIA', desc: 'Escaneie qualquer atividade e adapte para TEA, TDAH, Dislexia ou DI com um clique.', delay: 'reveal-d3' },
                    { icon: Sparkles, name: 'NeuroDesign', desc: 'Redesenhe textos com layout pedagógico acessível, pictogramas e organização visual.', delay: 'reveal-d4' },
                  ].map(m => {
                    const Icon = m.icon;
                    return (
                      <div key={m.name} className={`flex items-start gap-4 reveal ${m.delay} ${lab.visible ? 'on' : ''}`}>
                        <div className="bg-brand-600 p-2.5 rounded-xl shrink-0 shadow-lg shadow-orange-200">
                          <Icon size={18} className="text-white" />
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-900 mb-0.5">{m.name}</h4>
                          <p className="text-sm text-gray-500">{m.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Lab card grid */}
              <div className={`flex-1 grid grid-cols-1 gap-4 max-w-md w-full reveal reveal-d2 ${lab.visible ? 'on' : ''}`}>
                {[
                  { icon: Zap,      color: 'bg-brand-600',  label: 'AtivaIA',    sub: 'Criador de Atividades' },
                  { icon: Users,    color: 'bg-orange-500', label: 'EduLensIA',  sub: 'Scanner Pedagógico' },
                  { icon: Sparkles, color: 'bg-amber-500',  label: 'NeuroDesign', sub: 'Redesenho Inclusivo' },
                ].map(c => {
                  const Icon = c.icon;
                  return (
                    <div key={c.label}
                      className="bg-white/70 backdrop-blur-xl border border-orange-100 rounded-2xl p-5 flex items-center gap-4 hover:-translate-y-1 transition-transform duration-300 cursor-default"
                      style={{ boxShadow: '0 4px 24px rgba(234,88,12,0.08)' }}>
                      <div className={`${c.color} p-3 rounded-xl shrink-0`}>
                        <Icon size={20} className="text-white" />
                      </div>
                      <div>
                        <p className="font-extrabold text-gray-900">{c.label}</p>
                        <p className="text-xs text-gray-500">{c.sub}</p>
                      </div>
                      <ChevronRight size={16} className="text-gray-300 ml-auto" />
                    </div>
                  );
                })}
                <div className="bg-brand-600 rounded-2xl p-5 text-white text-center"
                  style={{ boxShadow: '0 8px 32px rgba(234,88,12,0.25)' }}>
                  <FlaskConical size={24} className="mx-auto mb-2" />
                  <p className="font-extrabold">IncluiLAB</p>
                  <p className="text-orange-100 text-xs mt-0.5">Disponível em todos os planos pagos</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══ 5. PRICING ══ */}
        <section id="pricing" className="py-28 bg-gray-50">
          <div ref={price.ref} className="max-w-7xl mx-auto px-6">
            <div className={`text-center mb-16 reveal ${price.visible ? 'on' : ''}`}>
              <p className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-3">Planos</p>
              <h2 className="text-3xl md:text-5xl font-extrabold text-gray-900 tracking-tight mb-4">Escolha seu plano</h2>
              <p className="text-xl text-gray-500">Estrutura ideal para cada realidade profissional.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">

              {/* PRO */}
              <div className={`bg-white rounded-3xl border border-gray-100 shadow-sm p-7 flex flex-col reveal reveal-d1 ${price.visible ? 'on' : ''}`}>
                <div className="mb-6">
                  <h3 className="text-2xl font-extrabold text-gray-900 mb-1">Plano Pro</h3>
                  <p className="text-gray-400 text-sm">Para professores e autônomos</p>
                </div>
                <ul className="space-y-3 mb-8 text-sm text-gray-600 flex-1">
                  {['200 créditos IA/mês', 'Até 20 alunos', 'Upload de Laudos', 'Documentos Educacionais', 'Código Auditável'].map(f => (
                    <li key={f} className="flex gap-3 items-center">
                      <CheckCircle size={16} className="text-brand-500 shrink-0" /> {f}
                    </li>
                  ))}
                </ul>

                {/* Annual */}
                <div className="relative bg-orange-50 border-2 border-brand-500 rounded-2xl p-5 mb-4">
                  <div className="absolute -top-3 right-4 bg-brand-600 text-white text-[10px] uppercase font-bold px-3 py-1 rounded-full">
                    Mais Vantajoso
                  </div>
                  <p className="text-gray-500 text-xs font-bold uppercase mb-1">Anual</p>
                  <div className="flex items-end gap-1.5 mb-1">
                    <span className="text-4xl font-extrabold text-gray-900">R$ {priceProAnnual.toFixed(2).replace('.', ',')}</span>
                    <span className="text-sm text-gray-400 mb-1">/mês</span>
                  </div>
                  <p className="text-[11px] text-brand-600 font-bold mb-4">Economia de R$ {((pricePro - priceProAnnual) * 12).toFixed(0)}/ano</p>
                  <button onClick={() => handleCheckout(PlanTier.PRO)}
                    className="w-full py-3 bg-brand-600 text-white rounded-xl font-bold hover:bg-brand-700 transition">
                    Assinar Anual
                  </button>
                </div>

                {/* Monthly */}
                <div className="flex justify-between items-center border border-gray-100 rounded-2xl p-4 bg-gray-50">
                  <div>
                    <p className="text-gray-400 text-xs font-bold uppercase">Mensal</p>
                    <p className="text-xl font-bold text-gray-900">R$ {pricePro.toFixed(2).replace('.', ',')}<span className="text-sm text-gray-400 font-normal">/mês</span></p>
                  </div>
                  <button onClick={() => handleCheckout(PlanTier.PRO)}
                    className="px-4 py-2 border border-gray-200 text-gray-600 rounded-xl text-sm font-bold hover:border-brand-400 hover:text-brand-600 transition">
                    Assinar
                  </button>
                </div>
              </div>

              {/* MASTER */}
              <div className={`bg-gray-900 text-white rounded-3xl p-7 flex flex-col relative overflow-hidden reveal reveal-d2 ${price.visible ? 'on' : ''}`}
                style={{ boxShadow: '0 20px 60px rgba(0,0,0,0.15)' }}>
                <div className="absolute top-0 right-0 w-48 h-48 bg-brand-600 rounded-full blur-[80px] opacity-20 pointer-events-none" />
                <div className="absolute -top-3 right-6 bg-gradient-to-r from-brand-600 to-orange-400 text-white text-[10px] uppercase font-bold px-4 py-1.5 rounded-full shadow-lg">
                  Mais Popular
                </div>
                <div className="mb-6 mt-4">
                  <h3 className="text-2xl font-extrabold mb-1">Plano Master</h3>
                  <p className="text-gray-400 text-sm">Para Clínicas e Escolas</p>
                </div>
                <ul className="space-y-3 mb-8 text-sm text-gray-300 flex-1">
                  {['400 créditos IA/mês', 'Até 40 alunos', 'Controle de Atendimento', 'Relatórios Evolutivos', 'Gestão Ampliada'].map(f => (
                    <li key={f} className="flex gap-3 items-center">
                      <CheckCircle size={16} className="text-brand-400 shrink-0" /> {f}
                    </li>
                  ))}
                </ul>

                {/* Annual */}
                <div className="relative bg-white/10 border-2 border-brand-400 rounded-2xl p-5 mb-4">
                  <div className="absolute -top-3 right-4 bg-brand-500 text-white text-[10px] uppercase font-bold px-3 py-1 rounded-full">
                    Mais Vantajoso
                  </div>
                  <p className="text-gray-400 text-xs font-bold uppercase mb-1">Anual</p>
                  <div className="flex items-end gap-1.5 mb-1">
                    <span className="text-4xl font-extrabold text-white">R$ {priceMasterAnnual.toFixed(2).replace('.', ',')}</span>
                    <span className="text-sm text-gray-400 mb-1">/mês</span>
                  </div>
                  <p className="text-[11px] text-brand-400 font-bold mb-4">Economia de R$ {((priceMaster - priceMasterAnnual) * 12).toFixed(0)}/ano</p>
                  <button onClick={() => handleCheckout(PlanTier.PREMIUM)}
                    className="cta-btn w-full py-3 text-white rounded-xl font-bold">
                    Assinar Anual
                  </button>
                </div>

                {/* Monthly */}
                <div className="flex justify-between items-center border border-white/10 rounded-2xl p-4 bg-white/5">
                  <div>
                    <p className="text-gray-500 text-xs font-bold uppercase">Mensal</p>
                    <p className="text-xl font-bold text-white">R$ {priceMaster.toFixed(2).replace('.', ',')}<span className="text-sm text-gray-500 font-normal">/mês</span></p>
                  </div>
                  <button onClick={() => handleCheckout(PlanTier.PREMIUM)}
                    className="px-4 py-2 border border-white/20 text-gray-300 rounded-xl text-sm font-bold hover:border-brand-400 hover:text-brand-400 transition">
                    Assinar
                  </button>
                </div>
              </div>
            </div>

            <p className={`text-center text-xs text-gray-400 mt-8 reveal reveal-d3 ${price.visible ? 'on' : ''}`}>
              * Cobrança recorrente mensal. Plano anual com compromisso mínimo de 12 meses.
            </p>
          </div>
        </section>

        {/* ══ 6. CTA FINAL ══ */}
        <section className="py-28 bg-white border-t border-gray-100">
          <div ref={cta.ref} className="max-w-3xl mx-auto px-6 text-center">
            <div className={`reveal ${cta.visible ? 'on' : ''}`}>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-brand-600 shadow-xl shadow-orange-200 mb-7">
                <Brain size={28} className="text-white" />
              </div>
              <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 tracking-tight mb-5">
                Comece hoje.<br />
                <span className="bg-gradient-to-r from-brand-600 to-orange-400 bg-clip-text text-transparent">Inclua sempre.</span>
              </h2>
              <p className="text-xl text-gray-500 mb-10 max-w-xl mx-auto leading-relaxed">
                Junte-se a mais de 1.800 professores que já transformaram a documentação inclusiva com IncluiAI.
              </p>
              <button onClick={onLogin}
                className="cta-btn text-white px-10 py-5 rounded-2xl text-lg font-bold shadow-2xl shadow-orange-200 inline-flex items-center gap-3 group hover:scale-105 transition-transform">
                Começar Agora <ArrowRight size={20} className="group-hover:translate-x-1 transition" />
              </button>
            </div>
          </div>
        </section>

      </main>

      {/* ── FOOTER ── */}
      <footer className="bg-gray-50 border-t border-gray-100 py-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="bg-brand-600 p-1.5 rounded-lg">
              <Brain className="text-white h-4 w-4" />
            </div>
            <span className="font-extrabold text-gray-900">IncluiAI</span>
          </div>
          <div className="flex flex-wrap gap-5 text-gray-400 text-sm items-center justify-center">
            <button onClick={onAudit} className="flex items-center gap-1.5 hover:text-brand-600 transition">
              <ShieldCheck size={13} /> Validar Documento
            </button>
            <span className="flex items-center gap-1.5">
              <Phone size={13} /> {config?.contactPhone || '(11) 99999-9999'}
            </span>
            <span className="flex items-center gap-1.5">
              <Lock size={13} /> LGPD Conforme
            </span>
          </div>
        </div>
      </footer>

    </div>
  );
};
