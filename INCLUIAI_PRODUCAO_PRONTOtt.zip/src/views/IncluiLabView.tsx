// IncluiLabView.tsx — Laboratório de Atividades Inclusivas
import React, { useState, useRef, useEffect } from 'react';
import {
  FlaskConical, Zap, Upload, Wand2, FileText, CheckCircle,
  Download, ChevronRight, Brain,
  Camera, Printer, Layers,
  Lightbulb, Loader,
  ArrowLeft, Sparkles, Coins,
} from 'lucide-react';
import { User, Student } from '../types';
import { AIService } from '../services/aiService';
import { WorkflowCanvas as AtivaIACanvas } from '../components/ativaIA/WorkflowCanvas';

// ─── Tipos ────────────────────────────────────────────────────────────────────
interface AdaptedActivity {
  original: string;
  adapted: string;
  adaptationType: string;
}

interface RedesignedActivity {
  original: string;
  redesigned: string;
  suggestions: string[];
}

type Tab     = 'workflow' | 'scanner' | 'redesign';
type AIModel = 'gemini' | 'openai';

const ADAPTATION_TYPES = [
  { id: 'autismo', label: 'Autismo (TEA)' },
  { id: 'tdah', label: 'TDAH' },
  { id: 'dislexia', label: 'Dislexia' },
  { id: 'di', label: 'Deficiência Intelectual' },
  { id: 'geral', label: 'Simplificação Geral' },
];

function calcCredits(model: AIModel, _count: number, isText = false) {
  return isText ? (model === 'openai' ? 2 : 1) : (model === 'openai' ? 3 : 2) * _count;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function exportAsText(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}


// ─── Seletor de Modelo ────────────────────────────────────────────────────────
const ModelSelector: React.FC<{
  model: AIModel;
  onChange: (m: AIModel) => void;
  credits: number;
  compact?: boolean;
}> = ({ model, onChange, credits, compact }) => (
  <div className={`flex items-center gap-2 ${compact ? '' : 'bg-white border border-gray-100 rounded-xl px-3 py-2 shadow-sm'}`}>
    {!compact && <Coins size={14} className="text-brand-500 shrink-0" />}
    <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-0.5">
      {(['gemini', 'openai'] as AIModel[]).map(m => (
        <button key={m} onClick={() => onChange(m)}
          className={`px-3 py-1.5 rounded-md text-xs font-bold transition ${model === m ? 'bg-white shadow text-gray-900' : 'text-gray-400 hover:text-gray-700'}`}>
          {m === 'gemini' ? 'Gemini' : 'ChatGPT'}
        </button>
      ))}
    </div>
    <div className="flex items-center gap-1 text-xs font-bold text-brand-600">
      <Coins size={12} /> {credits} crédito{credits !== 1 ? 's' : ''}
    </div>
  </div>
);

// ─── Componente principal ─────────────────────────────────────────────────────
interface IncluiLabViewProps {
  user: User;
  students: Student[];
  defaultTab?: Tab;
  sidebarOpen?: boolean;
}

export const IncluiLabView: React.FC<IncluiLabViewProps> = ({ user, students, defaultTab, sidebarOpen = true }) => {
  const [activeTab, setActiveTab] = useState<Tab | null>(defaultTab ?? null);

  useEffect(() => {
    if (defaultTab) setActiveTab(defaultTab);
  }, [defaultTab]);

  const modules = [
    { id: 'workflow' as Tab, icon: Zap,      label: 'AtivaIA',    subtitle: 'Canvas de Atividades', desc: 'Crie fluxos visuais de geração de atividades — envie imagem, escreva o prompt e a IA gera imagens pedagógicas.', iconBg: 'bg-brand-600' },
    { id: 'scanner'  as Tab, icon: Upload,   label: 'EduLensIA',  subtitle: 'Scanner Pedagógico',   desc: 'Envie foto ou PDF de qualquer atividade e adapte instantaneamente para TEA, TDAH, Dislexia ou DI.', iconBg: 'bg-orange-500' },
    { id: 'redesign' as Tab, icon: Sparkles, label: 'NeuroDesign', subtitle: 'Redesenho Inclusivo', desc: 'Cole qualquer texto e transforme com layout pedagógico acessível, pictogramas e organização visual.',  iconBg: 'bg-amber-500'  },
  ];

  // ── HUB ──
  if (!activeTab) {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{ background: 'linear-gradient(160deg,#fff7ed 0%,#ffffff 50%,#ffedd5 100%)' }}>
        <style>{`
          @keyframes lab-fade-up { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
          .lab-card { animation: lab-fade-up .5s ease both; }
          .lab-card:nth-child(1){animation-delay:.05s}
          .lab-card:nth-child(2){animation-delay:.15s}
          .lab-card:nth-child(3){animation-delay:.25s}
          .lab-card:hover{transform:translateY(-4px);box-shadow:0 12px 40px rgba(234,88,12,0.14)}
        `}</style>
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12" style={{ animation: 'lab-fade-up .4s ease both' }}>
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-brand-600 shadow-xl shadow-orange-200 mb-5">
              <FlaskConical className="text-white" size={30} />
            </div>
            <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight mb-2">IncluiLAB</h1>
            <p className="text-base text-gray-500 max-w-md mx-auto">Laboratório de Atividades Inclusivas com Inteligência Artificial</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {modules.map(m => {
              const Icon = m.icon;
              return (
                <button key={m.id} onClick={() => setActiveTab(m.id)}
                  className="lab-card text-left rounded-3xl border border-orange-100 p-7 transition-all duration-300 cursor-pointer group"
                  style={{ background: 'rgba(255,255,255,.75)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', boxShadow: '0 4px 24px rgba(234,88,12,.07)' }}>
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-2xl ${m.iconBg} mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="text-white" size={22} />
                  </div>
                  <div className="mb-1 text-[10px] font-bold text-brand-500 uppercase tracking-widest">{m.subtitle}</div>
                  <h2 className="text-xl font-extrabold text-gray-900 mb-3">{m.label}</h2>
                  <p className="text-sm text-gray-500 leading-relaxed mb-5">{m.desc}</p>
                  <div className="flex items-center gap-1.5 text-brand-600 text-xs font-bold group-hover:gap-3 transition-all duration-300">
                    Acessar <ChevronRight size={14} />
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-10 text-center">
            <span className="inline-flex items-center gap-2 text-xs text-gray-400 bg-white/60 backdrop-blur px-4 py-2 rounded-full border border-orange-100">
              <Brain size={12} className="text-brand-500" /> Gemini + OpenAI — Fallback automático
            </span>
          </div>
        </div>
      </div>
    );
  }

  // ── Sub-page ──
  const current = modules.find(m => m.id === activeTab)!;
  const CurrentIcon = current.icon;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sub-page header */}
      <div className="bg-white border-b border-gray-100 px-4 md:px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center gap-3">
          {!defaultTab && (
            <button onClick={() => setActiveTab(null)}
              className="flex items-center gap-1.5 text-sm font-semibold text-gray-500 hover:text-brand-600 transition px-3 py-2 rounded-xl hover:bg-orange-50">
              <ArrowLeft size={16} /> IncluiLAB
            </button>
          )}
          <div className={`${current.iconBg} p-2.5 rounded-2xl shadow-md shrink-0`}>
            <CurrentIcon className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-gray-900 leading-tight">{current.label}</h1>
            <p className="text-xs text-brand-500 font-semibold">{current.subtitle}</p>
          </div>
          {!defaultTab && (
            <div className="ml-auto hidden sm:flex items-center gap-1 bg-gray-100 rounded-xl p-1">
              {modules.map(m => {
                const Icon = m.icon;
                return (
                  <button key={m.id} onClick={() => setActiveTab(m.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${activeTab === m.id ? 'bg-brand-600 text-white shadow' : 'text-gray-500 hover:text-brand-600'}`}>
                    <Icon size={13} /> {m.label}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 md:p-6">
        {activeTab === 'workflow' && <AtivaIACanvas user={user} students={students as any} sidebarOpen={sidebarOpen} />}
        {activeTab === 'scanner'  && <ScannerTab user={user} />}
        {activeTab === 'redesign' && <RedesignTab user={user} />}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// EDULEISIA — Scanner Pedagógico
// ═══════════════════════════════════════════════════════════════════════════════
const ScannerTab: React.FC<{ user: User }> = ({ user }) => {
  const [file, setFile]                   = useState<File | null>(null);
  const [preview, setPreview]             = useState<string | null>(null);
  const [adaptationType, setAdaptationType] = useState('autismo');
  const [model, setModel]                 = useState<AIModel>('gemini');
  const [loading, setLoading]             = useState(false);
  const [result, setResult]               = useState<AdaptedActivity | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraRef    = useRef<HTMLInputElement>(null);
  const credits = calcCredits(model, 1, true);

  const handleFileChange = async (f: File) => {
    setFile(f); setResult(null);
    if (f.type.startsWith('image/')) setPreview(await fileToBase64(f));
    else setPreview(null);
  };

  const handleAdapt = async () => {
    if (!file) { alert('Envie um arquivo primeiro.'); return; }
    setLoading(true); setResult(null);
    try {
      const base64 = await fileToBase64(file);
      const adaptLabel = ADAPTATION_TYPES.find(a => a.id === adaptationType)?.label || adaptationType;
      const prompt = `Você é um especialista em educação inclusiva. Analise o conteúdo desta atividade educacional (extraia o texto se for imagem) e crie uma versão adaptada para alunos com ${adaptLabel}.

Regras:
- Simplifique a linguagem sem perder o objetivo pedagógico
- Divida instruções longas em passos numerados curtos
- Para TEA: estruture claramente, evite ambiguidade, use linguagem literal
- Para TDAH: instruções curtas, destaque o essencial
- Para Dislexia: frases curtas, vocabulário simples
- Para DI: linguagem simples, contexto concreto

Retorne SOMENTE um JSON válido:
{"original":"texto extraído","adapted":"versão adaptada completa","adaptationType":"${adaptLabel}"}`;

      const raw = await AIService.generateFromPromptWithImage(prompt, base64, user);
      let parsed: AdaptedActivity;
      try {
        const m = raw.match(/\{[\s\S]*\}/);
        parsed = m ? JSON.parse(m[0]) : { original: '', adapted: raw, adaptationType: adaptLabel };
      } catch { parsed = { original: '', adapted: raw, adaptationType: adaptLabel }; }
      setResult(parsed);
    } catch (e: any) {
      alert('Erro ao adaptar: ' + (e?.message || 'verifique a chave de API.'));
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <h2 className="font-bold text-gray-800 text-lg flex items-center gap-2">
            <Camera size={18} className="text-brand-600" /> Scanner Pedagógico
          </h2>
          <ModelSelector model={model} onChange={setModel} credits={credits} compact />
        </div>

        <div onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-orange-200 rounded-2xl p-8 text-center cursor-pointer hover:border-brand-400 hover:bg-orange-50 transition mb-4">
          {preview ? (
            <img src={preview} alt="preview" className="max-h-40 mx-auto rounded-lg object-contain" />
          ) : (
            <>
              <Upload size={32} className="text-brand-400 mx-auto mb-3" />
              <p className="text-sm font-semibold text-gray-600">Arraste ou clique para enviar</p>
              <p className="text-xs text-gray-400 mt-1">PDF, JPG, PNG aceitos</p>
              {file && <p className="text-xs text-brand-600 font-bold mt-2">{file.name}</p>}
            </>
          )}
        </div>
        <input ref={fileInputRef} type="file" accept=".pdf,.jpg,.jpeg,.png" className="hidden"
          onChange={e => e.target.files?.[0] && handleFileChange(e.target.files[0])} />

        <div className="flex gap-2 mb-5">
          <button onClick={() => cameraRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50">
            <Camera size={15} /> Usar câmera
          </button>
          <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden"
            onChange={e => e.target.files?.[0] && handleFileChange(e.target.files[0])} />
          {file && <span className="flex items-center gap-1 text-xs text-brand-600 font-bold"><CheckCircle size={13} /> {file.name}</span>}
        </div>

        <div className="mb-5">
          <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Tipo de Adaptação</label>
          <div className="flex flex-wrap gap-2">
            {ADAPTATION_TYPES.map(a => (
              <button key={a.id} onClick={() => setAdaptationType(a.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold border-2 transition ${adaptationType === a.id ? 'bg-brand-600 text-white border-brand-600' : 'bg-white text-gray-600 border-gray-200 hover:border-brand-300'}`}>
                {a.label}
              </button>
            ))}
          </div>
        </div>

        {/* Credit notice */}
        <div className="mb-4 flex items-center gap-2 bg-orange-50 border border-orange-100 rounded-xl px-4 py-2 text-xs">
          <Coins size={13} className="text-brand-500 shrink-0" />
          <span className="text-gray-600">Consumirá <strong className="text-brand-700">{credits} crédito{credits !== 1 ? 's' : ''}</strong> — {model === 'gemini' ? 'Gemini' : 'ChatGPT'}</span>
        </div>

        <button onClick={handleAdapt} disabled={loading || !file}
          className="w-full bg-brand-600 hover:bg-brand-700 text-white py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition shadow-lg shadow-orange-200 disabled:opacity-60">
          {loading ? <><Loader size={16} className="animate-spin" /> Adaptando…</> : <><Brain size={16} /> Adaptar Atividade com IA</>}
        </button>
      </div>

      {result && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <FileText size={15} className="text-gray-500" />
              <span className="text-xs font-bold text-gray-500 uppercase">Original</span>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{result.original || '(texto extraído da imagem)'}</p>
          </div>
          <div className="bg-orange-50 rounded-2xl border border-orange-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle size={15} className="text-brand-600" />
              <span className="text-xs font-bold text-brand-700 uppercase">Adaptada — {result.adaptationType}</span>
              <button onClick={() => exportAsText(result.adapted, 'atividade_adaptada.txt')}
                className="ml-auto flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-white border border-orange-200 text-brand-600 font-bold hover:bg-orange-100">
                <Download size={10} /> Exportar
              </button>
            </div>
            <p className="text-sm text-gray-800 leading-relaxed whitespace-pre-wrap">{result.adapted}</p>
          </div>
        </div>
      )}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// NEURODESIGN — Redesenho Inclusivo
// ═══════════════════════════════════════════════════════════════════════════════
const RedesignTab: React.FC<{ user: User }> = ({ user }) => {
  const [inputText, setInputText] = useState('');
  const [model, setModel]         = useState<AIModel>('gemini');
  const [loading, setLoading]     = useState(false);
  const [result, setResult]       = useState<RedesignedActivity | null>(null);
  const credits = calcCredits(model, 1, true);

  const handleRedesign = async () => {
    if (!inputText.trim()) { alert('Cole o conteúdo da atividade que deseja redesenhar.'); return; }
    setLoading(true); setResult(null);
    try {
      const prompt = `Você é um designer instrucional especialista em educação inclusiva.
Receba esta atividade e faça um REDESENHO PEDAGÓGICO INCLUSIVO completo.

ATIVIDADE ORIGINAL:
${inputText}

Aplique:
1. Reorganize o layout (títulos, seções numeradas)
2. Insira apoio visual em texto (📌 Imagem sugerida: ...)
3. Sugira ícones/pictogramas (🔢, 🔤, etc)
4. Melhore a organização para TEA e dislexia
5. Separe instruções em passos numerados
6. Use **negrito** para palavras-chave
7. Adicione "Espaço para resposta:" depois de cada pergunta

Retorne SOMENTE um JSON válido:
{"original":"texto original","redesigned":"atividade redesenhada completa","suggestions":["Sugestão 1","Sugestão 2","Sugestão 3"]}`;

      const raw = await AIService.generateFromPrompt(prompt, user);
      let parsed: RedesignedActivity;
      try {
        const m = raw.match(/\{[\s\S]*\}/);
        parsed = m ? JSON.parse(m[0]) : { original: inputText, redesigned: raw, suggestions: [] };
      } catch { parsed = { original: inputText, redesigned: raw, suggestions: [] }; }
      setResult(parsed);
    } catch (e: any) {
      alert('Erro ao redesenhar: ' + (e?.message || ''));
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <h2 className="font-bold text-gray-800 text-lg flex items-center gap-2">
            <Layers size={18} className="text-brand-600" /> Redesenho Inclusivo
          </h2>
          <ModelSelector model={model} onChange={setModel} credits={credits} compact />
        </div>
        <p className="text-sm text-gray-500 mb-5">Cole qualquer atividade existente e a IA vai redesenhá-la com layout pedagógico acessível.</p>

        <textarea value={inputText} onChange={e => setInputText(e.target.value)}
          placeholder="Cole aqui o texto da atividade que deseja redesenhar…"
          className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300 resize-none"
          rows={8} />

        {/* Credit notice */}
        <div className="mt-3 mb-4 flex items-center gap-2 bg-orange-50 border border-orange-100 rounded-xl px-4 py-2 text-xs">
          <Coins size={13} className="text-brand-500 shrink-0" />
          <span className="text-gray-600">Consumirá <strong className="text-brand-700">{credits} crédito{credits !== 1 ? 's' : ''}</strong> — {model === 'gemini' ? 'Gemini' : 'ChatGPT'}</span>
        </div>

        <button onClick={handleRedesign} disabled={loading}
          className="w-full bg-brand-600 hover:bg-brand-700 text-white py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition shadow-lg shadow-orange-200 disabled:opacity-60">
          {loading ? <><Loader size={16} className="animate-spin" /> Redesenhando…</> : <><Wand2 size={16} /> Redesenhar Atividade com IA</>}
        </button>
      </div>

      {result && (
        <div className="space-y-4">
          {(result.suggestions ?? []).length > 0 && (
            <div className="bg-amber-50 border border-amber-100 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb size={15} className="text-amber-600" />
                <span className="text-xs font-bold text-amber-700 uppercase">Sugestões de Melhoria</span>
              </div>
              <ul className="space-y-1.5">
                {(result.suggestions ?? []).map((s, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-amber-800">
                    <span className="bg-amber-200 text-amber-800 text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-center gap-2 mb-3">
                <FileText size={15} className="text-gray-500" />
                <span className="text-xs font-bold text-gray-500 uppercase">Original</span>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">{result.original}</p>
            </div>
            <div className="bg-orange-50 rounded-2xl border border-orange-100 shadow-sm p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Wand2 size={15} className="text-brand-600" />
                  <span className="text-xs font-bold text-brand-700 uppercase">Redesenhada</span>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => exportAsText(result.redesigned, 'atividade_redesenhada.txt')}
                    className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-white border border-orange-200 text-brand-600 font-bold hover:bg-orange-100">
                    <Download size={10} /> Exportar
                  </button>
                  <button onClick={() => window.print()}
                    className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-white border border-orange-200 text-brand-600 font-bold hover:bg-orange-100">
                    <Printer size={10} /> PDF
                  </button>
                </div>
              </div>
              <div className="text-sm text-gray-800 leading-relaxed whitespace-pre-wrap">{result.redesigned}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
