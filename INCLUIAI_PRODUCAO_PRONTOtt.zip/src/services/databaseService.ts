import { supabase } from './supabase';
import {
  DocumentType,
  PlanTier,
  TenantType,
  UserRole,
  resolvePlanTier,
  type Protocol,
  type Student,
  type TenantSummary,
  type User,
} from '../types';

type UUID = string;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function requireAuthUserId(): Promise<UUID> {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  const id = data.user?.id;
  if (!id) throw new Error('Usuário não autenticado.');
  return id;
}

async function getTenantIdForUser(userId?: UUID): Promise<UUID> {
  const uid = userId ?? (await requireAuthUserId());
  const { data, error } = await supabase.from('users').select('tenant_id').eq('id', uid).single();
  if (error) throw error;
  if (!data?.tenant_id) throw new Error('Tenant não encontrado para o usuário.');
  return data.tenant_id as UUID;
}

function mapDbRoleToUi(role: string | null | undefined): UserRole {
  switch ((role ?? '').toUpperCase()) {
    case 'AEE':
      return UserRole.AEE;
    case 'CLINICO':
      return UserRole.CLINICIAN;
    case 'GESTOR':
      return UserRole.MANAGER;
    case 'COORDENADOR':
      return UserRole.COORDINATOR;
    case 'RESPONSAVEL_TECNICO':
      return UserRole.TECHNICAL_RESP;
    case 'CEO':
      return UserRole.CEO;
    case 'DOCENTE':
    default:
      return UserRole.TEACHER;
  }
}

function mapTenantType(type: string | null | undefined): TenantType {
  const t = (type ?? '').toUpperCase();
  if (t === 'CLINIC') return TenantType.CLINIC;
  if (t === 'SCHOOL') return TenantType.SCHOOL;
  return TenantType.PROFESSIONAL;
}

function mapDocTypeToUi(type: string): DocumentType {
  const key = String(type ?? '').toUpperCase();
  switch (key) {
    case 'ESTUDO_CASO':
      return DocumentType.ESTUDO_CASO;
    case 'PEI':
      return DocumentType.PEI;
    case 'PAEE':
      return DocumentType.PAEE;
    case 'PDI':
      return DocumentType.PDI;
    default:
      return (type as any) as DocumentType;
  }
}

function mapDocStatus(status: string | null | undefined) {
  const s = String(status ?? '').toUpperCase();
  return s === 'FINAL' ? 'FINAL' : 'DRAFT';
}

// ---------------------------------------------------------------------------
// INTERNAL HELPERS (missing in your file)
// ---------------------------------------------------------------------------

async function getActiveSubscriptionForTenant(tenantId: string) {
  const { data } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('tenant_id', tenantId)
    .in('status', ['ACTIVE', 'TRIALING', 'PENDING'])
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  return data ?? null;
}

async function getPlanEffectiveByName(planName: string) {
  const { data } = await supabase
    .from('plans')
    .select('*')
    .eq('name', String(planName).toUpperCase())
    .maybeSingle();

  return data ?? null;
}

async function tryGetCreditsWalletBalance(tenantId: string) {
  // Prefer credits_avail (novo). Fallback para balance (legado).
  // Essa tabela pode ter RLS/colunas diferentes por ambiente.
  // Nunca deixe erro aqui derrubar o app.
  try {
    const { data, error } = await supabase
      .from('credits_wallet')
      .select('credits_avail, balance')
      .eq('tenant_id', tenantId)
      .maybeSingle();
    if (error) return null;
    const avail = Number((data as any)?.credits_avail);
    if (Number.isFinite(avail)) return avail;
    const bal = Number((data as any)?.balance);
    if (Number.isFinite(bal)) return bal;
    return null;
  } catch {
    return null;
  }
}

async function getLandingSingleton() {
  const { data } = await supabase
    .from('landing_settings')
    .select('*')
    .eq('singleton_key', 'default')
    .maybeSingle();

  return data ?? null;
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------

export const databaseService = {
  // =========================
  // USER / PROFILE
  // =========================
  async getUserProfile(userId?: UUID): Promise<User | null> {
    const uid = userId ?? (await requireAuthUserId());

    // Alguns ambientes têm colunas extras (LGPD). Tentamos com elas e fazemos fallback.
    let userRow: any = null;
    {
      const attempt = await supabase
        .from('users')
        .select('id, tenant_id, nome, email, role, plan, active, lgpd_accepted, lgpd_accepted_at, lgpd_term_version')
        .eq('id', uid)
        .maybeSingle();
      if (!attempt.error) {
        userRow = attempt.data;
      } else {
        const fallback = await supabase
          .from('users')
          .select('id, tenant_id, nome, email, role, plan, active')
          .eq('id', uid)
          .single();
        if (fallback.error) throw fallback.error;
        userRow = fallback.data;
      }
    }

    if (!userRow) return null;

    // tenants pode ter school_configs; tenta e faz fallback.
    let tenantRow: any = null;
    {
      const attempt = await supabase
        .from('tenants')
        .select('id, name, type, status_assinatura, creditos_ia_restantes, school_configs')
        .eq('id', userRow.tenant_id)
        .maybeSingle();
      if (!attempt.error) {
        tenantRow = attempt.data;
      } else {
        const fallback = await supabase
          .from('tenants')
          .select('id, name, type, status_assinatura, creditos_ia_restantes')
          .eq('id', userRow.tenant_id)
          .single();
        if (fallback.error) throw fallback.error;
        tenantRow = fallback.data;
      }
    }

    const { data: subRow } = await supabase
      .from('subscriptions')
      .select('status, plan, created_at, next_billing')
      .eq('tenant_id', userRow.tenant_id)
      .in('status', ['ACTIVE', 'TRIALING', 'PENDING'])
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const planTier = resolvePlanTier(subRow?.plan ?? userRow.plan) as PlanTier;
    const subscriptionStatus = (subRow?.status ?? (tenantRow as any)?.status_assinatura ?? 'ACTIVE') as any;

    const profile: User = {
      id: userRow.id,
      tenant_id: userRow.tenant_id,
      name: userRow.nome,
      email: userRow.email,
      role: mapDbRoleToUi(userRow.role),
      plan: planTier,
      tenantType: mapTenantType((tenantRow as any)?.type),
      isAdmin: String(userRow.role ?? '').toUpperCase() === 'CEO',
      active: !!userRow.active,
      subscriptionStatus,
      schoolConfigs: Array.isArray((tenantRow as any)?.school_configs) ? ((tenantRow as any).school_configs as any) : [],
      aiUsage: [],
    };

    // LGPD: prioriza banco; fallback localStorage; senão, exige aceite (accepted=false).
    const dbAccepted = (userRow as any)?.lgpd_accepted;
    if (typeof dbAccepted === 'boolean') {
      (profile as any).lgpdConsent = {
        accepted: dbAccepted,
        acceptedAt: (userRow as any)?.lgpd_accepted_at ?? null,
        termVersion: (userRow as any)?.lgpd_term_version ?? null,
      };
    } else {
      let localAccepted: any = null;
      try {
        const raw = localStorage.getItem(`lgpdAccepted:${profile.id}`);
        localAccepted = raw ? JSON.parse(raw) : null;
      } catch {}
      (profile as any).lgpdConsent = {
        accepted: !!localAccepted?.accepted,
        acceptedAt: localAccepted?.acceptedAt ?? null,
        termVersion: localAccepted?.termVersion ?? null,
      };
    }
    // Compat: alguns lugares usam "plan_tier".
    (profile as any).plan_tier = (profile as any).plan_tier ?? userRow.plan;
    // Credits (se você quiser mostrar na UI)
    (profile as any).aiCreditsRemaining = (tenantRow as any)?.creditos_ia_restantes ?? 0;

    return profile;
  },

  // =========================
  // STUDENTS
  // =========================
  async saveStudent(student: any) {
    const tenantId = student?.tenant_id ?? (await getTenantIdForUser());

    // Persistência tolerante a esquemas: a tabela `students` é snake_case.
    // A UI trabalha em camelCase. Aqui mapeamos e colocamos campos “extras” dentro de `data` (JSONB)
    // para evitar erros de coluna inexistente (schema cache) e não perder anexos.
    const mergedData = {
      ...(student?.data ?? {}),
      // escola selecionada no formulário (UI-only). Nem todo schema tem coluna `school_id`.
      schoolId: student?.schoolId ?? student?.school_id ?? student?.school ?? null,
      // anexos/laudos/relatórios (MASTER)
      documents: student?.documents ?? (student?.data?.documents ?? []),
      // análises IA (UI)
      documentAnalyses: student?.documentAnalyses ?? (student?.data?.documentAnalyses ?? []),
      // fichas complementares (UI)
      fichasComplementares: student?.fichasComplementares ?? (student?.data?.fichasComplementares ?? []),
    };

    const payload: any = {
      ...student,
      tenant_id: tenantId,
      // aliases comuns usados na UI
      birth_date: student?.birth_date ?? student?.birthDate ?? null,
      guardian_name: student?.guardian_name ?? student?.guardianName ?? null,
      guardian_phone: student?.guardian_phone ?? student?.guardianPhone ?? null,
      guardian_email: student?.guardian_email ?? student?.guardianEmail ?? null,
      regent_teacher: student?.regent_teacher ?? student?.regentTeacher ?? null,
      aee_teacher: student?.aee_teacher ?? student?.aeeTeacher ?? null,

      // ✅ foto: coluna real no banco é `photo_url`
      photo_url: student?.photo_url ?? student?.photoUrl ?? null,

      // ✅ histórico: coluna real no banco é `school_history`
      school_history: student?.school_history ?? student?.schoolHistory ?? student?.history ?? '',

      // ✅ extras no JSONB
      data: mergedData,
    };

    delete payload.birthDate;
    delete payload.guardianName;
    delete payload.guardianPhone;
    delete payload.guardianEmail;
    delete payload.regentTeacher;
    delete payload.aeeTeacher;

    // remove camelCase que derruba o PostgREST (schema cache)
    delete payload.photoUrl;
    delete payload.schoolHistory;
    delete payload.history;
    delete payload.registrationDate;
    delete payload.schoolId;
    delete payload.school;
    delete payload.school_id;

    // IMPORTANTE: não salvamos `documents/documentAnalyses/fichasComplementares` como colunas;
    // elas vão dentro de `data` (JSONB) para compatibilidade.
    delete payload.documents;
    delete payload.documentAnalyses;
    delete payload.fichasComplementares;

    const upsertOnce = async (p: any) => {
      const { data, error } = await supabase.from('students').upsert(p).select().single();
      if (error) throw error;
      return data;
    };

    // Retry genérico: remove coluna inexistente e reenvia.
    const upsertWithMissingColumnRetry = async (p: any) => {
      try {
        return await upsertOnce(p);
      } catch (e: any) {
        const msg = String(e?.message ?? '');
        const m = msg.match(/Could not find the '(.+?)' column/i);
        if (m?.[1]) {
          const badCol = m[1];
          const retry = { ...p };
          retry.data = { ...(retry.data ?? {}), [badCol]: (p as any)?.[badCol] ?? null };
          delete (retry as any)[badCol];
          return await upsertOnce(retry);
        }
        throw e;
      }
    };

    try {
      return await upsertWithMissingColumnRetry(payload);
    } catch (e: any) {
      const msg = String(e?.message ?? '');
      if (msg.includes('guardianEmail') || msg.includes('guardian_email')) {
        const retry = { ...payload };
        delete retry.guardian_email;
        return await upsertWithMissingColumnRetry(retry);
      }

      // alguns ambientes antigos podem não ter `photo_url` ainda
      if (msg.toLowerCase().includes('photo_url') || msg.toLowerCase().includes('photourl')) {
        const retry = { ...payload };
        delete retry.photo_url;
        return await upsertWithMissingColumnRetry(retry);
      }

      // alguns ambientes antigos podem não ter `school_history`
      if (msg.toLowerCase().includes('school_history') || msg.toLowerCase().includes('schoolhistory')) {
        const retry = { ...payload };
        delete retry.school_history;
        return await upsertWithMissingColumnRetry(retry);
      }
      throw e;
    }
  },

  // =========================
  // USER PATCHES
  // =========================
  async updateUserProfile(userId: string, patch: { name?: string; email?: string }) {
    const safe: any = {};
    if (typeof patch.name === 'string') safe.nome = patch.name;
    if (typeof patch.email === 'string') safe.email = patch.email;
    if (Object.keys(safe).length === 0) return;
    const { error } = await supabase.from('users').update(safe).eq('id', userId);
    if (error) throw error;
  },

  async saveSchoolConfigs(userId: string, schools: any[]) {
    const tenantId = await getTenantIdForUser(userId);
    try {
      const { error } = await supabase
        .from('tenants')
        .update({ school_configs: schools, updated_at: new Date().toISOString() } as any)
        .eq('id', tenantId);
      if (error) throw error;
    } catch {
      // ambiente ainda sem coluna: não quebra o app
    }
  },

  async acceptLGPD(userId: string, payload?: { termVersion?: string }) {
    const acceptedAt = new Date().toISOString();
    const termVersion = payload?.termVersion ?? 'v1.0';
    try {
      const { error } = await supabase
        .from('users')
        .update({ lgpd_accepted: true, lgpd_accepted_at: acceptedAt, lgpd_term_version: termVersion } as any)
        .eq('id', userId);
      if (error) throw error;
    } catch {
      try {
        localStorage.setItem(
          `lgpdAccepted:${userId}`,
          JSON.stringify({ accepted: true, acceptedAt, termVersion })
        );
      } catch {}
    }
  },

  async getStudents(userId?: UUID): Promise<Student[]> {
    const tenantId = await getTenantIdForUser(userId);
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .eq('tenant_id', tenantId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data ?? []) as any;
  },

  async deleteStudent(studentId: string) {
    const { error } = await supabase.from('students').delete().eq('id', studentId);
    if (error) throw error;
    return true;
  },

  // =========================
  // DOCUMENTS / PROTOCOLS
  // =========================
  async saveDocument(doc: any) {
    const tenantId = doc?.tenant_id ?? (await getTenantIdForUser(doc?.userId));
    const payload: any = {
      ...doc,
      tenant_id: tenantId,
      student_id: doc.studentId ?? doc.student_id,
      student_name: doc.studentName ?? doc.student_name,
      type: (doc.type ?? doc.documentType ?? '').toString().toUpperCase(),
      status: (doc.status ?? 'DRAFT').toString().toUpperCase(),
      source_id: doc.source_id ?? doc.sourceId ?? null,
      structured_data: doc.structuredData ?? doc.structured_data ?? { sections: [] },
      versions: doc.versions ?? [],
      signatures: doc.signatures ?? {},
      audit_code: doc.auditCode ?? doc.audit_code ?? null,
      last_edited_at: new Date().toISOString(),
      last_edited_by: doc.lastEditedBy ?? doc.last_edited_by ?? null,
      generated_by: doc.generatedBy ?? doc.generated_by ?? null,
    };

    delete payload.studentId;
    delete payload.studentName;
    delete payload.documentType;
    delete payload.structuredData;
    delete payload.auditCode;
    delete payload.lastEditedBy;
    delete payload.generatedBy;
    delete payload.sourceId;
    delete payload.userId;

    const q = payload.id ? supabase.from('documents').upsert(payload) : supabase.from('documents').insert(payload);
    const { data, error } = await q.select().single();
    if (error) throw error;
    return data;
  },

  async getDocumentsByStudent(studentId: string) {
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('student_id', studentId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  async getProtocols(userId?: UUID): Promise<Protocol[]> {
    const tenantId = await getTenantIdForUser(userId);
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('tenant_id', tenantId)
      .order('created_at', { ascending: false });
    if (error) throw error;

    const rows = data ?? [];
    return rows.map((r: any) => {
      const proto: Protocol = {
        id: r.id,
        tenant_id: r.tenant_id,
        studentId: r.student_id,
        studentName: r.student_name ?? '',
        type: mapDocTypeToUi(r.type),
        status: mapDocStatus(r.status) as any,
        source_id: r.source_id ?? null,
        content: r.content ?? '',
        isStructured: true,
        structuredData: r.structured_data ?? { sections: [] },
        versions: r.versions ?? [],
        lastEditedAt: r.last_edited_at ?? r.updated_at ?? r.created_at,
        lastEditedBy: r.last_edited_by ?? r.generated_by ?? '',
        createdAt: r.created_at,
        generatedBy: r.generated_by ?? '',
        auditCode: r.audit_code ?? '',
        signatures: r.signatures ?? { regent: '', coordinator: '', aee: '', manager: '' },
      };
      return proto;
    });
  },

  // =========================
  // BILLING / LIMITS
  // =========================
  async getTenantSummary(userId: string): Promise<TenantSummary> {
    const tenantId = await getTenantIdForUser(userId);

    const { data: tenant, error: tErr } = await supabase
      .from('tenants')
      .select('id, name, type, status_assinatura, creditos_ia_restantes, data_renovacao_plano')
      .eq('id', tenantId)
      .single();
    if (tErr) throw tErr;

    const { count: studentsCount, error: sErr } = await supabase
      .from('students')
      .select('*', { count: 'exact', head: true })
      .eq('tenant_id', tenantId);
    if (sErr) throw sErr;

    const sub = await getActiveSubscriptionForTenant(tenantId);
    const planTier = resolvePlanTier((sub as any)?.plan ?? 'FREE');
    const subscriptionStatus = ((sub as any)?.status ?? (tenant as any)?.status_assinatura ?? 'ACTIVE') as any;

    // Plano efetivo (limites/recursos) vem do banco
    const planEff = await getPlanEffectiveByName(String(planTier));

    // Créditos: preferir carteira; fallback em coluna legado do tenant.
    const walletAvail = await tryGetCreditsWalletBalance(tenantId);
    const aiCreditsRemaining = walletAvail ?? (tenant as any)?.creditos_ia_restantes ?? 0;

    return {
      tenantId,
      tenantName: (tenant as any)?.name,
      subscriptionStatus,
      planTier,
      aiCreditsRemaining,
      studentLimitBase: (planEff as any)?.max_students ?? 0,
      studentLimitExtra: 0 as any,
      studentsActive: studentsCount ?? 0,
      renewalDatePlan: (tenant as any)?.data_renovacao_plano ?? undefined,
      renewalDateCredits: (sub as any)?.next_billing ?? undefined,
    };
  },

  // =========================
  // PRICING / LANDING (CEO)
  // =========================
  async getEffectivePlans(): Promise<any[]> {
    const { data, error } = await supabase
      .from('v_plans_effective')
      .select('*')
      .order('display_order', { ascending: true });
    if (error) throw error;
    return data ?? [];
  },

  async updatePlan(name: 'FREE' | 'PRO' | 'MASTER', patch: Partial<any>): Promise<void> {
    const normalized = String(name).toUpperCase();
    const allowed = [
      'monthly_price',
      'annual_price',
      'promo_monthly_price',
      'promo_annual_price',
      'promo_active',
      'promo_ends_at',
      'max_students',
      'monthly_credits',
      'includes_evolution',
      'is_recommended',
      'display_order',
      'tagline',
      'features',
    ] as const;

    const safe: Record<string, any> = {};
    for (const k of allowed) if (k in patch) safe[k] = (patch as any)[k];

    const { error } = await supabase.from('plans').update(safe).eq('name', normalized);
    if (error) throw error;
  },

  async getLandingSettings(): Promise<any | null> {
    return await getLandingSingleton();
  },

  async updateLandingSettings(patch: Partial<any>): Promise<void> {
    const allowed = [
      'hero_title',
      'hero_subtitle',
      'promo_banner_enabled',
      'promo_banner_text',
      'promo_badge_text',
      'promo_disclaimer',
      'faq',
      'credits_faq_text',
      'credits_rules',
      'recommended_plan',
      'updated_at',
    ] as const;

    const safe: Record<string, any> = { updated_at: new Date().toISOString() };
    for (const k of allowed) if (k in patch) safe[k] = (patch as any)[k];

    const { error } = await supabase
      .from('landing_settings')
      .update(safe)
      .eq('singleton_key', 'default');
    if (error) throw error;
  },

  async createPurchaseIntent(args: { tenantId: string; userId: string; planName: string }) {
    const plan = String(args.planName || '').toUpperCase();

    return {
      ok: true,
      provider: 'KIWIFY',
      plan,
      checkoutUrl:
        plan === 'MASTER'
          ? 'https://SEU-LINK-KIWIFY-MASTER'
          : plan === 'PRO'
          ? 'https://SEU-LINK-KIWIFY-PRO'
          : 'https://SEU-LINK-KIWIFY-FREE',
      meta: args,
    };
  },
};